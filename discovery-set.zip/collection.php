<?php

require_once __DIR__ . '/config.php';

$requestedSlug = trim((string) ($_GET['collection'] ?? ''));

$collection = null;
$products = [];
$discoverySet = null;

try {

  $pdo = verdeur_db();

  if ($requestedSlug !== '') {

    $stmt = $pdo->prepare(
      'SELECT * FROM collections WHERE slug = ? AND is_active = 1 LIMIT 1'
    );

    $stmt->execute([$requestedSlug]);

    $collection = $stmt->fetch();

  }

  if ($collection) {

    $stmt = $pdo->prepare(
      'SELECT * FROM products WHERE is_active = 1 AND collection_id = ? ORDER BY sort_order'
    );

    $stmt->execute([$collection['collection_id']]);

    $products = $stmt->fetchAll();

  }

$stmtDiscovery = $pdo->prepare(
      'SELECT * FROM tester_sets WHERE is_active = 1 AND collection_id = ? ORDER BY sort_order LIMIT 1'
  );
  $stmtDiscovery->execute([$collection['collection_id']]);
  $discoverySet = $stmtDiscovery->fetch();

} catch (Throwable $e) {
  $collection = null;
  $products = [];
  $discoverySet = null;
}

if (!$collection) {
  header('Location: fragrances.php');
  exit;
}

$pageTitle = $collection['name'] . ' — Verdeur';

/* SEO overrides (consumed by includes/header.php) */
$seoType = 'collection';
$seoName = (string) $collection['name'];
$collectionDesc = trim((string) ($collection['description'] ?? ''));
$pageDescription = $collectionDesc !== ''
  ? $collectionDesc
  : 'Explore the ' . $collection['name'] . ' collection at Verdeur — an independent fragrance house.';
$canonicalUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
  . '://' . $_SERVER['HTTP_HOST']
  . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/collection/' . urlencode((string) $collection['slug']);

include('includes/header.php');
?>

  <main>

    <!-- =========================================
         01 — COLLECTION INTRO
    ========================================== -->

    <section class="collection-intro">

      <div class="collection-intro-inner">

        <p class="collection-kicker">
          <?php echo v_esc($collection['kicker'] ?? "Verdeur's Collection"); ?>
        </p>

        <h1 class="collection-title">
          <?php echo v_esc(v_upper($collection['name'])); ?>
        </h1>

        <p class="collection-subtitle">
          <?php echo v_esc($collection['subtitle'] ?? ''); ?>
        </p>

        <p class="collection-description">
          <?php echo v_esc($collection['description'] ?? ''); ?>
        </p>

        <p class="collection-count">
          <?php echo v_esc($collection['count_label'] ?? 'Verdeur Fragrances'); ?>
        </p>

      </div>

    </section>

  <!-- =========================================
     02 — COLLECTION PRODUCTS
========================================== -->

<section class="collection-products">

  <div class="collection-products-grid">

<?php foreach ($products as $product): ?>

    <article class="collection-product">

      <div class="collection-product-visual">

        <div class="product-bottle-wrap">

          <a
            href="fragrance/<?php echo v_esc($product['slug']); ?>"
            class="product-image-link"
          >
            <img
              src="<?php echo v_esc($product['image']); ?>"
              alt="<?php echo v_esc($product['name'] . ' by Verdeur'); ?>"
              loading="lazy"
              decoding="async"
            >
          </a>

          <button
            type="button"
            class="product-cart-button"
            data-product="<?php echo v_esc($product['slug']); ?>"
            aria-label="Add <?php echo v_esc($product['name']); ?> to cart"
            title="Add to cart"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M5 8h14l-1 12H6L5 8Z"></path>
              <path d="M9 8V6a3 3 0 0 1 6 0v2"></path>
              <path d="M12 11v5"></path>
              <path d="M9.5 13.5h5"></path>
            </svg>
          </button>

        </div>

      </div>


      <a
        href="fragrance/<?php echo v_esc($product['slug']); ?>"
        class="collection-product-info"
      >

        <h2 class="collection-product-name">
          <?php echo v_esc($product['name']); ?>
        </h2>

        <p class="collection-product-expression">
          <?php echo v_esc($product['expression']); ?>
        </p>

        <p class="collection-product-price">
          <?php echo v_price($product['price']); ?>
        </p>

      </a>

    </article>

<?php endforeach; ?>

<?php if ($discoverySet): ?>

    <article class="collection-product collection-product-discovery">

      <div class="collection-product-visual">

        <div class="product-bottle-wrap">

          <a
            href="discovery-set/<?php echo v_esc($discoverySet['slug']); ?>"
            class="product-image-link"
          >
            <img
              src="<?php echo v_esc($discoverySet['image']); ?>"
              alt="Verdeur Discovery Set"
            >
          </a>

          <button
            type="button"
            class="product-cart-button"
            data-product="<?php echo v_esc($discoverySet['slug']); ?>"
            aria-label="Add Discovery Set to cart"
            title="Add to cart"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M5 8h14l-1 12H6L5 8Z"></path>
              <path d="M9 8V6a3 3 0 0 1 6 0v2"></path>
              <path d="M12 11v5"></path>
              <path d="M9.5 13.5h5"></path>
            </svg>
          </button>

        </div>

      </div>


      <a
        href="discovery-set/<?php echo v_esc($discoverySet['slug']); ?>"
        class="collection-product-info"
      >

        <h2 class="collection-product-name">
          <?php echo v_esc($discoverySet['name']); ?>
        </h2>

        <p class="collection-product-expression">
          <?php echo v_esc($discoverySet['card_subtitle']); ?>
        </p>

        <p class="collection-product-price">
          <?php echo v_price($discoverySet['price']); ?>
        </p>

      </a>

    </article>

<?php endif; ?>

  </div>

</section>

  </main>

<?php include('includes/footer.php'); ?>