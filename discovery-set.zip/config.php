<?php

declare(strict_types=1);

/* Composer autoloader (PHPMailer, etc.) */
$verdeurAutoload = __DIR__ . '/vendor/autoload.php';
if (is_file($verdeurAutoload)) {
  require_once $verdeurAutoload;
}

/* =========================================
   VERDEUR — DATABASE CONFIGURATION (XAMPP)
========================================= */

define('VERDEUR_DB_HOST', 'localhost');
define('VERDEUR_DB_NAME', 'verdeur_db');
define('VERDEUR_DB_USER', 'root');
define('VERDEUR_DB_PASS', '');
define('VERDEUR_DB_CHARSET', 'utf8mb4');

/* =========================================
   VERDEUR — ORDER EMAIL (SMTP)
   Sends order confirmation to the customer
   and a notification to the admin through
   the orders@verdeur.pk CPanel mailbox.
========================================= */

define('VERDEUR_SMTP_HOST', 'mail.verdeur.pk');
define('VERDEUR_SMTP_PORT', 465);
define('VERDEUR_SMTP_USER', 'orders@verdeur.pk');
define('VERDEUR_SMTP_PASS', 'verdeur@785#');
define('VERDEUR_MAIL_FROM', 'orders@verdeur.pk');
define('VERDEUR_MAIL_FROM_NAME', 'Verdeur');
define('VERDEUR_ADMIN_EMAIL', 'verdeurfragrances@gmail.com');


function verdeur_db(): PDO {

  static $pdo = null;

  if ($pdo instanceof PDO) {
    return $pdo;
  }

  $dsn = sprintf(
    'mysql:host=%s;dbname=%s;charset=%s',
    VERDEUR_DB_HOST,
    VERDEUR_DB_NAME,
    VERDEUR_DB_CHARSET
  );

  $pdo = new PDO(
    $dsn,
    VERDEUR_DB_USER,
    VERDEUR_DB_PASS,
    [
      PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES   => false,
    ]
  );

  return $pdo;

}


function v_esc(?string $value): string {
  return htmlspecialchars(
    (string) $value,
    ENT_QUOTES,
    'UTF-8'
  );
}


function v_price(?int $price): string {
  return 'Rs. ' . number_format(
    (int) $price
  );
}


function v_upper(?string $value): string {
  return mb_strtoupper(
    (string) $value,
    'UTF-8'
  );
}


function verdeur_setting(string $key, string $default = ''): string {

  static $settings = null;

  if ($settings === null) {
    $settings = [];
    try {
      foreach (verdeur_db()->query('SELECT setting_key, setting_value FROM site_settings WHERE is_active = 1') as $row) {
        $settings[$row['setting_key']] = (string) $row['setting_value'];
      }
    } catch (Throwable $e) {
      $settings = [];
    }
  }

  return array_key_exists($key, $settings)
    ? $settings[$key]
    : $default;

}


function verdeur_socials(): array {

  return [
    'facebook'  => verdeur_setting('social_facebook'),
    'instagram' => verdeur_setting('social_instagram'),
    'tiktok'    => verdeur_setting('social_tiktok'),
  ];

}


function verdeur_legal_pages(): array {

  try {
    return verdeur_db()->query(
      'SELECT slug, title FROM legal_pages WHERE is_active = 1 ORDER BY sort_order, page_id'
    )->fetchAll();
  } catch (Throwable $e) {
    return [];
  }

}


function verdeur_collections(): array {

  try {
    return verdeur_db()->query(
      'SELECT collection_id, slug, name FROM collections WHERE is_active = 1 ORDER BY sort_order, collection_id'
    )->fetchAll();
  } catch (Throwable $e) {
    return [];
  }

}


/* =========================================
   VERDEUR — GLOBAL SECURITY HEADERS
   Sent on every page/API response.
   (Added in config.php so all entry points
   inherit them.)
========================================= */

if (!headers_sent()) {

  header('X-Content-Type-Options: nosniff');
  header('X-Frame-Options: SAMEORIGIN');
  header('Referrer-Policy: strict-origin-when-cross-origin');
  header('X-XSS-Protection: 0');
  header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

  // Limit which hosts may frame / embed the site.
  $https = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
  $host  = (string) ($_SERVER['HTTP_HOST'] ?? '');
  if ($host !== '') {
    $scheme = $https ? 'https' : 'http';
    $frameOrigin = $scheme . '://' . $host;

    // Comprehensive Content Security Policy.
    // 'unsafe-inline' for script/style is intentionally kept so the
    // admin panel's inline styles + event handlers keep working, while
    // the policy still blocks arbitrary external script/style injection.
    $csp = array_filter([
      "default-src 'self'",
      "img-src 'self' data:",
      "font-src 'self' data: https://fonts.googleapis.com https://fonts.gstatic.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "script-src 'self' 'unsafe-inline'",
      "connect-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'self' " . $frameOrigin,
    ]);
    header('Content-Security-Policy: ' . implode('; ', $csp));
  }
}