<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/analytics-helpers.php';

$pageTitle = 'Analytics & Insights — Verdeur Admin';
include(__DIR__ . '/includes/header.php');

/* ---------------------------------------------------------------
   Analytics & Insights
   Server-side SVG charts (no external CDN dependencies).
--------------------------------------------------------------- */

$allowedRanges = [7, 30, 90];
$range = (int) ($_GET['range'] ?? 30);
if (!in_array($range, $allowedRanges, true)) { $range = 30; }

$from = date('Y-m-d', strtotime('-' . ($range - 1) . ' days'));
$to   = date('Y-m-d');

$data = [
  'revenueRange' => 0,
  'ordersRange'  => 0,
  'aovRange'     => 0,
  'pendingRange' => 0,
  'revenueTop'   => 0,
  'trendRev'     => [],
  'trendCount'   => [],
  'statusRows'   => [],
  'paymentRows'  => [],
  'productRows'  => [],
  'cityRows'     => [],
  'productTable' => [],
  'weeklyLabels' => [],
  'weeklyValues' => [],
];

try {
  $pdo = verdeur_db();

  $stmt = $pdo->prepare(
    "SELECT
       COALESCE(SUM(CASE WHEN order_status != 'Cancelled' THEN total ELSE 0 END),0) rev,
       COUNT(*) orders,
       COALESCE(SUM(CASE WHEN order_status = 'Pending' THEN 1 ELSE 0 END),0) pending,
       COALESCE(SUM(CASE WHEN order_status != 'Cancelled' THEN 1 ELSE 0 END),0) non_cancelled
     FROM orders
     WHERE created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)"
  );
  $stmt->execute([$from, $to]);
  $row = $stmt->fetch(PDO::FETCH_ASSOC);

  $data['revenueRange'] = (int) $row['rev'];
  $data['ordersRange']  = (int) $row['orders'];
  $data['pendingRange'] = (int) $row['pending'];
  $data['aovRange']     = (int) $row['non_cancelled'] > 0 ? (int) round($data['revenueRange'] / (int) $row['non_cancelled']) : 0;

  /* Revenue trend by day */
  $dailyRev = vr_analytics_daily($pdo, $from, $to, 'COALESCE(SUM(total),0)', "order_status != 'Cancelled'");
  $dailyCnt = vr_analytics_daily($pdo, $from, $to);
  foreach ($dailyRev as $p) { $data['trendRev'][] = (int) $p[1]; }
  $data['trendRevLabels'] = [];
  foreach ($dailyRev as $p) { $data['trendRevLabels'][] = $p[0]; }
  foreach ($dailyCnt as $p) { $data['trendCount'][] = (int) $p[1]; }
  $data['revenueTop'] = $data['trendRev'] ? max($data['trendRev']) : 0;

  /* Status + payment breakdown */
  foreach ($pdo->query('SELECT order_status, COUNT(*) c FROM orders WHERE created_at >= ' . $pdo->quote($from) . ' AND created_at < ' . $pdo->quote(date('Y-m-d', strtotime($to . ' +1 day'))) . ' GROUP BY order_status') as $r) {
    $data['statusRows'][] = [$r['order_status'], (int) $r['c']];
  }
  foreach ($pdo->query("SELECT payment_status, COUNT(*) c FROM orders WHERE order_status != 'Cancelled' AND created_at >= " . $pdo->quote($from) . ' AND created_at < ' . $pdo->quote(date('Y-m-d', strtotime($to . ' +1 day'))) . ' GROUP BY payment_status') as $r) {
    $data['paymentRows'][] = [$r['payment_status'], (int) $r['c']];
  }

  /* Top products by quantity + revenue (range) */
  $stmtP = $pdo->prepare(
    'SELECT i.item_name label, SUM(i.quantity) qty, SUM(i.line_total) rev
     FROM order_items i
     INNER JOIN orders o ON o.order_id = i.order_id
     WHERE o.created_at >= ? AND o.created_at < ? AND o.order_status != \'Cancelled\'
     GROUP BY i.item_name
     ORDER BY qty DESC
     LIMIT 8'
  );
  $stmtP->execute([$from, date('Y-m-d', strtotime($to . ' +1 day'))]);
  $data['productTable'] = $stmtP->fetchAll();
  foreach ($data['productTable'] as $pr) {
    $data['productRows'][] = [$pr['label'], (int) $pr['qty'], 'Rs. ' . number_format((int) $pr['rev'])];
  }

  /* City breakdown (range) */
  $stmtC = $pdo->prepare(
    "SELECT customer_city label, COUNT(*) c
     FROM orders
     WHERE customer_city <> '' AND created_at >= ? AND created_at < ?
     GROUP BY customer_city
     ORDER BY c DESC
     LIMIT 6"
  );
  $stmtC->execute([$from, date('Y-m-d', strtotime($to . ' +1 day'))]);
  foreach ($stmtC->fetchAll() as $cr) {
    $data['cityRows'][] = [$cr['label'], (int) $cr['c']];
  }

  /* Weekly revenue (last ~13 weeks of the range) */
  $weekLabels = []; $weekValues = [];
  $rangeStart = new DateTime($from);
  $rangeEnd   = new DateTime($to);
  for ($wk = 0; $wk < 13; $wk++) {
    $ws = (clone $rangeStart)->modify('+' . ($wk * 7) . ' days');
    $we = (clone $ws)->modify('+6 days');
    if ($ws > $rangeEnd) { break; }
    if ($we > $rangeEnd) { $we = clone $rangeEnd; }
    $stmtW = $pdo->prepare("SELECT COALESCE(SUM(total),0) FROM orders WHERE order_status != 'Cancelled' AND created_at >= ? AND created_at < ?");
    $stmtW->execute([$ws->format('Y-m-d'), $we->modify('+1 day')->format('Y-m-d')]);
    $weekLabels[] = $ws->format('d M');
    $weekValues[] = (int) $stmtW->fetchColumn();
  }
  $data['weeklyLabels'] = $weekLabels;
  $data['weeklyValues'] = $weekValues;

} catch (Throwable $e) {
  // handle exception silently
}

function vr_pct(int $cur, int $prev): float {
  if ($prev <= 0) { return 100.0; }
  return round(100 * ($cur - $prev) / $prev, 1);
}
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Analytics &amp; Insights</h1>
    <p>Fragrance house performance for the selected period</p>
  </div>
  <div class="admin-header-actions" style="display:flex; gap:8px; align-items:center;">
    <span style="font-size:12px; color:var(--text-muted); margin-right:4px;">Period:</span>
    <?php foreach ($allowedRanges as $rr): ?>
      <a href="analytics.php?range=<?php echo $rr; ?>" class="btn <?php echo $rr === $range ? '' : 'btn-outline'; ?>" style="padding:6px 14px;"><?php echo $rr; ?>d</a>
    <?php endforeach; ?>
  </div>
</div>

<style>
  .analytics-grid { display:grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap:20px; margin-top:20px; }
  .analytics-card { background:var(--card-bg); border:1px solid var(--border); padding:20px 24px; }
  .analytics-card h3 { font-size:12px; font-weight:600; letter-spacing:.08em; text-transform:uppercase; color:var(--text-muted); margin-bottom:14px; }
  .kpi-sub { font-size:11px; color:var(--text-muted); margin-top:6px; }
  .wide { grid-column: 1 / -1; }
  .insight-box { background:#fbf6ea; border:1px solid #f0e3bd; border-radius:6px; padding:14px 16px; margin-top:20px; }
  .insight-box li { font-size:13px; line-height:1.7; color:var(--text); margin-left:16px; }
  .table-note { font-size:11px; color:var(--text-muted); margin-top:8px; }
  @media (max-width: 760px) { .analytics-grid { grid-template-columns: 1fr; } }
</style>

<div class="stats-grid" style="margin-top:0;">
  <div class="stat-card">
    <h3>Revenue</h3>
    <div class="value" style="font-size:24px;">Rs. <?php echo number_format($data['revenueRange']); ?></div>
    <div class="kpi-sub"><?php echo $range; ?>-day period (excl. cancelled)</div>
  </div>
  <div class="stat-card">
    <h3>Orders</h3>
    <div class="value" style="font-size:24px;"><?php echo number_format($data['ordersRange']); ?></div>
    <div class="kpi-sub">all statuses</div>
  </div>
  <div class="stat-card">
    <h3>Avg Order Value</h3>
    <div class="value" style="font-size:24px; color:#8e44ad;">Rs. <?php echo number_format($data['aovRange']); ?></div>
    <div class="kpi-sub">non-cancelled orders</div>
  </div>
  <div class="stat-card">
    <h3>Pending Orders</h3>
    <div class="value" style="font-size:24px; color:#f39c12;"><?php echo number_format($data['pendingRange']); ?></div>
    <div class="kpi-sub">need packing/dispatch</div>
  </div>
</div>

<div class="analytics-grid">
  <div class="analytics-card wide">
    <h3>Revenue by Day (Rs, excl. cancelled)</h3>
    <?php if (count($data['trendRev']) > 0): ?>
      <?php echo vr_svg_line($data['trendRevLabels'], $data['trendRev'], ['height'=>220, 'color'=>'#111111']); ?>
    <?php else: ?>
      <p style="color:var(--text-muted); font-size:13px;">No data for this period.</p>
    <?php endif; ?>
  </div>

  <div class="analytics-card">
    <h3>Orders per Day</h3>
    <?php echo vr_svg_bar($data['trendRevLabels'], $data['trendCount'], ['height'=>200, 'bar_color'=>'#8e44ad']); ?>
  </div>

  <div class="analytics-card">
    <h3>Weekly Revenue</h3>
    <?php echo vr_svg_bar($data['weeklyLabels'], $data['weeklyValues'], ['height'=>200, 'bar_color'=>'#c9a227']); ?>
  </div>

  <div class="analytics-card">
    <h3>Order Status</h3>
    <?php echo vr_svg_hbar($data['statusRows'], ['label_width'=>130, 'bar_color'=>'#2d3748']); ?>
  </div>

  <div class="analytics-card">
    <h3>Payment Status</h3>
    <?php echo vr_svg_hbar($data['paymentRows'], ['label_width'=>130, 'bar_color'=>'#27ae60']); ?>
  </div>

  <div class="analytics-card wide">
    <h3>Top Selling Fragrances — Last <?php echo $range; ?> Days</h3>
    <?php echo vr_svg_hbar($data['productRows'], ['label_width'=>200]); ?>
  </div>

  <div class="analytics-card">
    <h3>Orders by City</h3>
    <?php echo vr_svg_hbar($data['cityRows'], ['label_width'=>150]); ?>
  </div>

  <div class="analytics-card wide">
    <h3>Product Revenue Breakdown</h3>
    <?php if (count($data['productTable']) === 0): ?>
      <p style="color:var(--text-muted); font-size:13px;">No product sales in this period.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr><th>Fragrance</th><th style="text-align:right;">Qty</th><th style="text-align:right;">Revenue</th></tr>
        </thead>
        <tbody>
          <?php foreach ($data['productTable'] as $pr): ?>
            <tr>
              <td><?php echo htmlspecialchars($pr['label']); ?></td>
              <td style="text-align:right;"><?php echo number_format((int) $pr['qty']); ?></td>
              <td style="text-align:right;">Rs. <?php echo number_format((int) $pr['rev']); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <div class="table-note">Reflects <strong><?php echo $range; ?>-day</strong> window, excludes cancelled orders.</div>
    <?php endif; ?>
  </div>
</div>

<div class="insight-box">
  <strong>Insights</strong>
  <ul>
    <li><strong>Rs. <?php echo number_format($data['revenueRange']); ?></strong> revenue from <strong><?php echo number_format($data['ordersRange']); ?></strong> orders in the last <?php echo $range; ?> days (avg <strong>Rs. <?php echo number_format($data['aovRange']); ?></strong>/order).</li>
    <li><strong><?php echo number_format($data['pendingRange']); ?></strong> orders currently pending — <a href="orders.php?status=Pending">review them</a>.</li>
    <?php if (isset($data['productRows'][0])): ?>
      <li>Best-selling fragrance: <strong><?php echo htmlspecialchars($data['productRows'][0][0]); ?></strong>.</li>
    <?php endif; ?>
    <?php if (isset($data['cityRows'][0])): ?>
      <li>Strongest market: <strong><?php echo htmlspecialchars($data['cityRows'][0][0]); ?></strong> (<?php echo number_format($data['cityRows'][0][1]); ?> orders).</li>
    <?php endif; ?>
    <li>Orders favour <strong><?php echo isset($data['statusRows'][0]) ? htmlspecialchars($data['statusRows'][0][0]) : '—'; ?></strong> status; monitor fulfilment throughput to avoid pending backlog.</li>
  </ul>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
