<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$successMsg = '';
$errorMsg = '';

try {
  $pdo = verdeur_db();

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
      $errorMsg = 'Security validation failed (CSRF token invalid).';
    } else {
      // Save site settings
    $shipping = trim((string) ($_POST['shipping_charge'] ?? '250'));
    $email = trim((string) ($_POST['contact_email'] ?? ''));
    $phone = trim((string) ($_POST['contact_phone'] ?? ''));
    $whatsapp = trim((string) ($_POST['contact_whatsapp'] ?? ''));
    $address = trim((string) ($_POST['contact_address'] ?? ''));
    $allowCod = isset($_POST['allow_cod']) ? '1' : '0';

    $fb = trim((string) ($_POST['social_facebook'] ?? ''));
    $ig = trim((string) ($_POST['social_instagram'] ?? ''));
    $tk = trim((string) ($_POST['social_tiktok'] ?? ''));

    $upSetting = $pdo->prepare('INSERT INTO site_settings (setting_key, setting_value, is_active) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE setting_value = ?');
    $upSetting->execute(['shipping_charge', $shipping, $shipping]);
    $upSetting->execute(['contact_email', $email, $email]);
    $upSetting->execute(['contact_phone', $phone, $phone]);
    $upSetting->execute(['contact_whatsapp', $whatsapp, $whatsapp]);
    $upSetting->execute(['contact_address', $address, $address]);
    $upSetting->execute(['allow_cod', $allowCod, $allowCod]);
    $upSetting->execute(['social_facebook', $fb, $fb]);
    $upSetting->execute(['social_instagram', $ig, $ig]);
    $upSetting->execute(['social_tiktok', $tk, $tk]);

    // Handle Hero Desktop Video (.webm)
    if (isset($_FILES['hero_desktop_file']) && $_FILES['hero_desktop_file']['error'] === UPLOAD_ERR_OK) {
      $dExt = strtolower(pathinfo($_FILES['hero_desktop_file']['name'], PATHINFO_EXTENSION));
      if ($dExt === 'webm') {
        $dName = 'next-chapter-hero-desktop_' . time() . '.webm';
        $vDir = __DIR__ . '/../assets/video/';
        if (!is_dir($vDir)) { mkdir($vDir, 0755, true); }
        if (move_uploaded_file($_FILES['hero_desktop_file']['tmp_name'], $vDir . $dName)) {
          $dPath = 'assets/video/' . $dName;
          $upSetting->execute(['hero_desktop_video', $dPath, $dPath]);
        }
      } else {
        $errorMsg = 'Desktop hero video must be a .webm file.';
      }
    }

    // Handle Hero Mobile Video (.webm)
    if (isset($_FILES['hero_mobile_file']) && $_FILES['hero_mobile_file']['error'] === UPLOAD_ERR_OK) {
      $mExt = strtolower(pathinfo($_FILES['hero_mobile_file']['name'], PATHINFO_EXTENSION));
      if ($mExt === 'webm') {
        $mName = 'next-chapter-hero-mobile_' . time() . '.webm';
        $vDir = __DIR__ . '/../assets/video/';
        if (!is_dir($vDir)) { mkdir($vDir, 0755, true); }
        if (move_uploaded_file($_FILES['hero_mobile_file']['tmp_name'], $vDir . $mName)) {
          $mPath = 'assets/video/' . $mName;
          $upSetting->execute(['hero_mobile_video', $mPath, $mPath]);
        }
      } else {
        $errorMsg = 'Mobile hero video must be a .webm file.';
      }
    }

    // Save Bank 1 & Bank 2
    $banksData = [
      1 => [
        'active' => 1, // Bank 1 always active
        'name' => trim((string) ($_POST['bank1_name'] ?? 'HBL — Verdeur')),
        'bank_name' => trim((string) ($_POST['bank1_bank_name'] ?? '')),
        'title' => trim((string) ($_POST['bank1_account_title'] ?? '')),
        'number' => trim((string) ($_POST['bank1_account_number'] ?? '')),
        'iban' => trim((string) ($_POST['bank1_iban'] ?? '')),
        'branch' => trim((string) ($_POST['bank1_branch'] ?? '')),
        'file_key' => 'bank1_qr',
      ],
      2 => [
        'active' => isset($_POST['bank2_active']) ? 1 : 0,
        'name' => trim((string) ($_POST['bank2_name'] ?? 'Bank 2 — Verdeur')),
        'bank_name' => trim((string) ($_POST['bank2_bank_name'] ?? '')),
        'title' => trim((string) ($_POST['bank2_account_title'] ?? '')),
        'number' => trim((string) ($_POST['bank2_account_number'] ?? '')),
        'iban' => trim((string) ($_POST['bank2_iban'] ?? '')),
        'branch' => trim((string) ($_POST['bank2_branch'] ?? '')),
        'file_key' => 'bank2_qr',
      ],
    ];

    $existingBanks = $pdo->query('SELECT * FROM bank_accounts ORDER BY sort_order, account_id')->fetchAll();

    foreach ($banksData as $idx => $bInfo) {
      $bId = $existingBanks[$idx - 1]['account_id'] ?? 0;
      $qrImage = $existingBanks[$idx - 1]['qr_image'] ?? 'assets/images/qr.webp';

      // Handle QR file upload
      if (isset($_FILES[$bInfo['file_key']]) && $_FILES[$bInfo['file_key']]['error'] === UPLOAD_ERR_OK) {
        $qTmp = $_FILES[$bInfo['file_key']]['tmp_name'];
        $qExt = strtolower(pathinfo($_FILES[$bInfo['file_key']]['name'], PATHINFO_EXTENSION));
        if (in_array($qExt, ['jpg', 'jpeg', 'png', 'webp', 'svg'], true)) {
          $qName = 'qr_bank_' . $idx . '_' . time() . '.' . $qExt;
          $imgDir = __DIR__ . '/../assets/images/';
          if (!is_dir($imgDir)) { mkdir($imgDir, 0755, true); }
          if (move_uploaded_file($qTmp, $imgDir . $qName)) {
            $qrImage = 'assets/images/' . $qName;
          }
        }
      }

      if ($bId > 0) {
        $upB = $pdo->prepare('UPDATE bank_accounts SET name = ?, bank_name = ?, account_title = ?, account_number = ?, iban = ?, branch = ?, qr_image = ?, is_active = ? WHERE account_id = ?');
        $upB->execute([$bInfo['name'], $bInfo['bank_name'], $bInfo['title'], $bInfo['number'], $bInfo['iban'], $bInfo['branch'], $qrImage, $bInfo['active'], $bId]);
      } else {
        $insB = $pdo->prepare('INSERT INTO bank_accounts (name, bank_name, account_title, account_number, iban, branch, qr_image, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $insB->execute([$bInfo['name'], $bInfo['bank_name'], $bInfo['title'], $bInfo['number'], $bInfo['iban'], $bInfo['branch'], $qrImage, $bInfo['active'], $idx]);
      }
    }

    if ($errorMsg === '') {
      $successMsg = 'Settings and bank accounts updated successfully.';
    }
  }
}

  $settings = [];
  foreach ($pdo->query('SELECT setting_key, setting_value FROM site_settings')->fetchAll() as $row) {
    $settings[$row['setting_key']] = $row['setting_value'];
  }

  $banks = $pdo->query('SELECT * FROM bank_accounts ORDER BY sort_order, account_id')->fetchAll();
  $bank1 = $banks[0] ?? [];
  $bank2 = $banks[1] ?? [];

} catch (Throwable $e) {
  $errorMsg = 'Error: ' . $e->getMessage();
  $settings = [];
  $bank1 = [];
  $bank2 = [];
}

$pageTitle = 'Settings & Bank Accounts — Verdeur Admin';
include(__DIR__ . '/includes/header.php');
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Settings & Bank Accounts</h1>
    <p>Configure global settings, videos, contact info, COD, and bank transfers</p>
  </div>
</div>

<?php if ($successMsg !== ''): ?>
  <div style="background: rgba(46, 204, 113, 0.1); border: 1px solid rgba(46, 204, 113, 0.3); color: #38a169; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($successMsg); ?>
  </div>
<?php endif; ?>

<?php if ($errorMsg !== ''): ?>
  <div style="background: rgba(229, 62, 62, 0.1); border: 1px solid rgba(229, 62, 62, 0.3); color: #e53e3e; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($errorMsg); ?>
  </div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
  <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">
  <!-- GLOBAL SETTINGS & COD -->
  <div class="content-card">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Global Configuration & Checkout Options</h2>
    
    <div class="form-row">
      <div class="form-group">
        <label for="shipping_charge">Shipping Charge (Rs.)</label>
        <input type="number" id="shipping_charge" name="shipping_charge" value="<?php echo htmlspecialchars($settings['shipping_charge'] ?? '250'); ?>" required>
      </div>
      <div class="form-group" style="display: flex; align-items: center; padding-top: 24px;">
        <label style="display: inline-flex; align-items: center; gap: 10px; cursor: pointer; text-transform: none; font-size: 13px; font-weight: 600; color: #111;">
          <input type="checkbox" name="allow_cod" value="1" <?php echo ($settings['allow_cod'] ?? '0') === '1' ? 'checked' : ''; ?> style="width: 18px; height: 18px;"> Allow Cash on Delivery (COD) on Checkout
        </label>
      </div>
    </div>
  </div>

  <!-- HERO VIDEOS (.webm) -->
  <div class="content-card" style="margin-top: 30px;">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Homepage Hero Videos (.webm only)</h2>
    
    <div class="form-row">
      <div class="form-group">
        <label for="hero_desktop_file">Desktop Hero Video (.webm)</label>
        <input type="file" id="hero_desktop_file" name="hero_desktop_file" accept=".webm" style="padding: 10px;">
        <?php if (!empty($settings['hero_desktop_video'])): ?>
          <p style="font-size: 11px; color: var(--text-muted); margin-top: 6px;">Current: <?php echo htmlspecialchars($settings['hero_desktop_video']); ?></p>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="hero_mobile_file">Mobile Hero Video (.webm)</label>
        <input type="file" id="hero_mobile_file" name="hero_mobile_file" accept=".webm" style="padding: 10px;">
        <?php if (!empty($settings['hero_mobile_video'])): ?>
          <p style="font-size: 11px; color: var(--text-muted); margin-top: 6px;">Current: <?php echo htmlspecialchars($settings['hero_mobile_video']); ?></p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- CONTACT & COMPANY INFORMATION -->
  <div class="content-card" style="margin-top: 30px;">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Contact & Company Information</h2>
    
    <div class="form-row">
      <div class="form-group">
        <label for="contact_email">Contact Email</label>
        <input type="email" id="contact_email" name="contact_email" value="<?php echo htmlspecialchars($settings['contact_email'] ?? 'concierge@verdeur.com'); ?>">
      </div>
      <div class="form-group">
        <label for="contact_phone">Phone Number</label>
        <input type="text" id="contact_phone" name="contact_phone" value="<?php echo htmlspecialchars($settings['contact_phone'] ?? '+92 300 0000000'); ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="contact_whatsapp">WhatsApp Number</label>
        <input type="text" id="contact_whatsapp" name="contact_whatsapp" value="<?php echo htmlspecialchars($settings['contact_whatsapp'] ?? '+92 300 0000000'); ?>">
      </div>
      <div class="form-group">
        <label for="contact_address">Physical Address</label>
        <input type="text" id="contact_address" name="contact_address" value="<?php echo htmlspecialchars($settings['contact_address'] ?? 'Lahore, Pakistan'); ?>">
      </div>
    </div>

    <h3 style="font-size: 13px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin: 24px 0 16px; color: var(--text-muted);">Social Media Links</h3>
    <div class="form-row">
      <div class="form-group">
        <label for="social_facebook">Facebook URL</label>
        <input type="text" id="social_facebook" name="social_facebook" value="<?php echo htmlspecialchars($settings['social_facebook'] ?? ''); ?>">
      </div>
      <div class="form-group">
        <label for="social_instagram">Instagram URL</label>
        <input type="text" id="social_instagram" name="social_instagram" value="<?php echo htmlspecialchars($settings['social_instagram'] ?? ''); ?>">
      </div>
      <div class="form-group">
        <label for="social_tiktok">TikTok URL</label>
        <input type="text" id="social_tiktok" name="social_tiktok" value="<?php echo htmlspecialchars($settings['social_tiktok'] ?? ''); ?>">
      </div>
    </div>
  </div>

  <!-- BANK ACCOUNT 1 -->
  <div class="content-card" style="margin-top: 30px;">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Primary Bank Account (Bank 1)</h2>
    
    <div class="form-row">
      <div class="form-group">
        <label for="bank1_bank_name">Bank Name</label>
        <input type="text" id="bank1_bank_name" name="bank1_bank_name" value="<?php echo htmlspecialchars($bank1['bank_name'] ?? 'HBL'); ?>" required>
      </div>
      <div class="form-group">
        <label for="bank1_account_title">Account Title</label>
        <input type="text" id="bank1_account_title" name="bank1_account_title" value="<?php echo htmlspecialchars($bank1['account_title'] ?? 'Verdeur Fragrances'); ?>" required>
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="bank1_account_number">Account Number</label>
        <input type="text" id="bank1_account_number" name="bank1_account_number" value="<?php echo htmlspecialchars($bank1['account_number'] ?? ''); ?>" required>
      </div>
      <div class="form-group">
        <label for="bank1_iban">IBAN</label>
        <input type="text" id="bank1_iban" name="bank1_iban" value="<?php echo htmlspecialchars($bank1['iban'] ?? ''); ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="bank1_branch">Branch</label>
        <input type="text" id="bank1_branch" name="bank1_branch" value="<?php echo htmlspecialchars($bank1['branch'] ?? ''); ?>">
      </div>
      <div class="form-group">
        <label for="bank1_qr">QR Code Image (Upload)</label>
        <input type="file" id="bank1_qr" name="bank1_qr" accept="image/*" style="padding: 10px;">
        <?php if (!empty($bank1['qr_image'])): ?>
          <div style="margin-top: 8px; display: flex; align-items: center; gap: 10px;">
            <img src="../<?php echo htmlspecialchars($bank1['qr_image']); ?>" alt="" style="height: 45px; width: auto; object-fit: contain; border: 1px solid var(--border); background: #fff; padding: 2px;">
            <span style="font-size: 11px; color: var(--text-muted);">Current QR</span>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- BANK ACCOUNT 2 (Secondary / Optional) -->
  <div class="content-card" style="margin-top: 30px;">
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">
      <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase;">Secondary Bank Account (Bank 2)</h2>
      <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; font-weight: 600; color: #111;">
        <input type="checkbox" name="bank2_active" value="1" <?php echo !empty($bank2['is_active']) ? 'checked' : ''; ?> style="width: 16px; height: 16px;"> Enable Bank 2 on Checkout
      </label>
    </div>
    
    <div class="form-row">
      <div class="form-group">
        <label for="bank2_bank_name">Bank Name</label>
        <input type="text" id="bank2_bank_name" name="bank2_bank_name" value="<?php echo htmlspecialchars($bank2['bank_name'] ?? ''); ?>">
      </div>
      <div class="form-group">
        <label for="bank2_account_title">Account Title</label>
        <input type="text" id="bank2_account_title" name="bank2_account_title" value="<?php echo htmlspecialchars($bank2['account_title'] ?? ''); ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="bank2_account_number">Account Number</label>
        <input type="text" id="bank2_account_number" name="bank2_account_number" value="<?php echo htmlspecialchars($bank2['account_number'] ?? ''); ?>">
      </div>
      <div class="form-group">
        <label for="bank2_iban">IBAN</label>
        <input type="text" id="bank2_iban" name="bank2_iban" value="<?php echo htmlspecialchars($bank2['iban'] ?? ''); ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="bank2_branch">Branch</label>
        <input type="text" id="bank2_branch" name="bank2_branch" value="<?php echo htmlspecialchars($bank2['branch'] ?? ''); ?>">
      </div>
      <div class="form-group">
        <label for="bank2_qr">QR Code Image (Upload)</label>
        <input type="file" id="bank2_qr" name="bank2_qr" accept="image/*" style="padding: 10px;">
        <?php if (!empty($bank2['qr_image'])): ?>
          <div style="margin-top: 8px; display: flex; align-items: center; gap: 10px;">
            <img src="../<?php echo htmlspecialchars($bank2['qr_image']); ?>" alt="" style="height: 45px; width: auto; object-fit: contain; border: 1px solid var(--border); background: #fff; padding: 2px;">
            <span style="font-size: 11px; color: var(--text-muted);">Current QR</span>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div style="margin-top: 30px;">
    <button type="submit" class="btn">Save All Settings</button>
  </div>
</form>

<?php
include(__DIR__ . '/includes/footer.php');
?>
