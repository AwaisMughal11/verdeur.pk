<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$pageTitle = 'Tester Boxes — Verdeur Admin';

try {
  $pdo = verdeur_db();

  /* ------------------------------------------------
     AUTO-MIGRATION: ensure tester_sets has collection_id
  ------------------------------------------------ */
  $hasCollId = false;
  foreach ($pdo->query('SHOW COLUMNS FROM tester_sets')->fetchAll() as $col) {
    if ($col['Field'] === 'collection_id') {
      $hasCollId = true;
      break;
    }
  }
  if (!$hasCollId) {
    $pdo->exec('ALTER TABLE tester_sets ADD COLUMN collection_id INT UNSIGNED NULL AFTER includes');

    // Backfill collection_id from existing collection-name reference where possible
    // (only on legacy DBs that still have the `collection` text column)
    try {
      $pdo->exec(
        'UPDATE tester_sets t SET t.collection_id = (
           SELECT c.collection_id FROM collections c
           WHERE LOWER(c.name) = LOWER(TRIM(t.collection))
           LIMIT 1
         ) WHERE t.collection_id IS NULL'
      );
    } catch (Throwable $e) {
      // ignore — legacy column may be absent
    }
  }

} catch (Throwable $e) {
  $pdo = null;
}

$successMsg = '';
$errorMsg = '';
$editingId = (int) ($_GET['edit'] ?? 0);

$setForm = [
  'slug'            => '',
  'name'            => '',
  'subtitle'        => '',
  'card_subtitle'   => '',
  'price'           => 0,
  'image'           => '',
  'intro'           => '',
  'olfactory_intro' => '',
  'includes'        => '',
  'collection_id'   => 0,
  'concentration'   => '',
  'size_label'      => '',
  'sort_order'      => 0,
  'is_active'       => 1,
];

$selectedItems = []; // product_id => position

try {
  $pdo = verdeur_db();
  $collections = $pdo->query('SELECT collection_id, name, slug FROM collections ORDER BY sort_order, name')->fetchAll();

  if ($editingId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM tester_sets WHERE set_id = ? LIMIT 1');
    $stmt->execute([$editingId]);
    $ex = $stmt->fetch();
    if ($ex) {
      $setForm = $ex;
      $iStmt = $pdo->prepare(
        'SELECT tsi.product_id, tsi.position FROM tester_set_items tsi WHERE tsi.set_id = ? ORDER BY tsi.position'
      );
      $iStmt->execute([$editingId]);
      foreach ($iStmt->fetchAll() as $row) {
        $selectedItems[(int) $row['product_id']] = (int) $row['position'];
      }
    } else {
      $editingId = 0;
    }
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
      $errorMsg = 'Security validation failed (CSRF token invalid).';
    } else {
      $name           = trim((string) ($_POST['name'] ?? ''));
      $slug           = trim((string) ($_POST['slug'] ?? ''));
      $subtitle       = trim((string) ($_POST['subtitle'] ?? ''));
      $cardSubtitle   = trim((string) ($_POST['card_subtitle'] ?? ''));
      $price          = (int) ($_POST['price'] ?? 0);
      $intro          = trim((string) ($_POST['intro'] ?? ''));
      $olfactoryIntro = trim((string) ($_POST['olfactory_intro'] ?? ''));
      $includes       = trim((string) ($_POST['includes'] ?? ''));
      $collectionId   = (int) ($_POST['collection_id'] ?? 0);
      $concentration  = trim((string) ($_POST['concentration'] ?? ''));
      $sizeLabel      = trim((string) ($_POST['size_label'] ?? ''));
      $sortOrder      = (int) ($_POST['sort_order'] ?? 0);
      $isActive       = isset($_POST['is_active']) ? 1 : 0;
      $postSetId      = (int) ($_POST['set_id'] ?? 0);

      // Manually selected perfume product_ids + their positions (keyed by product id)
      $itemProductIds = [];
      $postedPositions = isset($_POST['item_position']) && is_array($_POST['item_position'])
        ? $_POST['item_position']
        : [];
      foreach ($postedPositions as $pid => $pos) {
        $pid = (int) $pid;
        if ($pid > 0) {
          $itemProductIds[$pid] = max(1, (int) $pos);
        }
      }

      if ($name === '' || $slug === '') {
        $errorMsg = 'Tester box name and slug are required.';
      } elseif ($collectionId <= 0) {
        $errorMsg = 'Please select a collection before saving.';
      } else {
        // Unique slug check
        $slugCheck = $pdo->prepare('SELECT set_id FROM tester_sets WHERE slug = ? AND set_id <> ? LIMIT 1');
        $slugCheck->execute([$slug, $postSetId]);
        if ($slugCheck->fetch()) {
          $errorMsg = 'This URL slug is already in use. Please choose a unique slug.';
        } else {
          // Handle image upload
          $imagePath = trim((string) ($_POST['image'] ?? ''));
          if (isset($_FILES['set_image']) && $_FILES['set_image']['error'] === UPLOAD_ERR_OK) {
            $tmp = $_FILES['set_image']['tmp_name'];
            $ext = strtolower(pathinfo($_FILES['set_image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'svg'], true)) {
              $fn = 'tester_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
              $uploadDir = __DIR__ . '/../assets/images/';
              if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
              }
              if (move_uploaded_file($tmp, $uploadDir . $fn)) {
                $imagePath = 'assets/images/' . $fn;
              }
            }
          }

          $pdo->beginTransaction();
          try {
            if ($postSetId > 0) {
              $up = $pdo->prepare(
                'UPDATE tester_sets SET slug = ?, name = ?, subtitle = ?, card_subtitle = ?, price = ?, image = ?, intro = ?, olfactory_intro = ?, includes = ?, collection_id = ?, concentration = ?, size_label = ?, sort_order = ?, is_active = ? WHERE set_id = ?'
              );
              $up->execute([
                $slug, $name, $subtitle, $cardSubtitle, $price, $imagePath, $intro,
                $olfactoryIntro, $includes, $collectionId, $concentration, $sizeLabel,
                $sortOrder, $isActive, $postSetId
              ]);
              $targetSetId = $postSetId;
            } else {
              $maxSort = (int) $pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM tester_sets')->fetchColumn();
              $ins = $pdo->prepare(
                'INSERT INTO tester_sets (slug, name, subtitle, card_subtitle, price, image, intro, olfactory_intro, includes, collection_id, concentration, size_label, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
              );
              $ins->execute([
                $slug, $name, $subtitle, $cardSubtitle, $price, $imagePath, $intro,
                $olfactoryIntro, $includes, $collectionId, $concentration, $sizeLabel,
                $sortOrder, $isActive
              ]);
              $targetSetId = (int) $pdo->lastInsertId();
            }

            // Replace set items (dynamic manual selection)
            $pdo->prepare('DELETE FROM tester_set_items WHERE set_id = ?')->execute([$targetSetId]);
            $insItem = $pdo->prepare('INSERT INTO tester_set_items (set_id, product_id, position) VALUES (?, ?, ?)');
            foreach ($itemProductIds as $pid => $pos) {
              $insItem->execute([$targetSetId, $pid, $pos]);
            }

            $pdo->commit();
            header('Location: tester-boxes.php?success=1');
            exit;
          } catch (Throwable $dbEx) {
            $pdo->rollBack();
            $errorMsg = 'Database error: ' . $dbEx->getMessage();
          }
        }
      }
    }
  }
} catch (Throwable $e) {
  $errorMsg = 'Database error: ' . $e->getMessage();
  $collections = [];
}

include(__DIR__ . '/includes/header.php');
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Tester Boxes</h1>
    <p>Build &amp; manage discovery / tester box sets</p>
  </div>
</div>

<?php if ($successMsg !== ''): ?>
  <div style="background: rgba(46, 204, 113, 0.1); border: 1px solid rgba(46, 204, 113, 0.3); color: #38a169; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    Tester box saved successfully.
  </div>
<?php endif; ?>

<?php if ($errorMsg !== ''): ?>
  <div style="background: rgba(229, 62, 62, 0.1); border: 1px solid rgba(229, 62, 62, 0.3); color: #e53e3e; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($errorMsg); ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1.6fr; gap: 30px; align-items: start;">

  <!-- ===================== FORM ===================== -->
  <div class="content-card">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">
      <?php echo $editingId > 0 ? 'Edit Tester Box' : 'Add Tester Box'; ?>
    </h2>

    <form method="POST" enctype="multipart/form-data" id="tester-box-form">
      <input type="hidden" name="set_id" value="<?php echo $editingId; ?>">
      <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">

      <!-- STEP 1: NAME -->
      <div class="form-group">
        <label for="tb-name">Tester Box Name *</label>
        <input type="text" id="tb-name" name="name" required value="<?php echo htmlspecialchars($setForm['name']); ?>" placeholder="e.g. Discovery Set">
      </div>

      <div class="form-group">
        <label for="tb-slug">URL Slug * (unique)</label>
        <input type="text" id="tb-slug" name="slug" required value="<?php echo htmlspecialchars($setForm['slug']); ?>" placeholder="e.g. discovery-set">
      </div>

      <!-- STEP 2: COLLECTION -->
      <div class="form-group">
        <label for="tb-collection">Collection *</label>
        <select id="tb-collection" name="collection_id" required>
          <option value="0">— Select collection —</option>
          <?php foreach ($collections as $col): ?>
            <option value="<?php echo (int) $col['collection_id']; ?>" <?php echo (int) $setForm['collection_id'] === (int) $col['collection_id'] ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($col['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- STEP 3: PERFUME SELECTION (DYNAMIC) -->
      <div class="form-group">
        <label>Perfumes from this collection (select manually)</label>
        <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 10px; text-transform: none; letter-spacing: normal;">
          Choose a collection above to load its perfumes. Tick the fragrances to include in the box; use the position field to set their order.
        </p>
        <div id="tb-perfume-list" style="border: 1px solid var(--border); background: #fafbfc; max-height: 260px; overflow-y: auto; padding: 6px;">
          <p style="font-size: 12px; color: var(--text-muted); padding: 8px;">Select a collection to see its perfumes.</p>
        </div>
      </div>

      <!-- DETAILS -->
      <hr style="border: none; border-top: 1px solid var(--border); margin: 24px 0;">

      <div class="form-row">
        <div class="form-group">
          <label for="tb-subtitle">Subtitle</label>
          <input type="text" id="tb-subtitle" name="subtitle" value="<?php echo htmlspecialchars($setForm['subtitle']); ?>">
        </div>
        <div class="form-group">
          <label for="tb-card_subtitle">Card Subtitle</label>
          <input type="text" id="tb-card_subtitle" name="card_subtitle" value="<?php echo htmlspecialchars($setForm['card_subtitle']); ?>" placeholder="e.g. Five expressions · 5 × 5ml">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="tb-price">Price (Rs.) *</label>
          <input type="number" id="tb-price" name="price" required value="<?php echo (int) $setForm['price']; ?>">
        </div>
        <div class="form-group">
          <label for="tb-sort_order">Sort Order</label>
          <input type="number" id="tb-sort_order" name="sort_order" value="<?php echo (int) $setForm['sort_order']; ?>">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label for="tb-includes">Includes</label>
          <input type="text" id="tb-includes" name="includes" value="<?php echo htmlspecialchars($setForm['includes']); ?>" placeholder="e.g. 5 × 5ml fragrances">
        </div>
        <div class="form-group">
          <label for="tb-size_label">Size Label</label>
          <input type="text" id="tb-size_label" name="size_label" value="<?php echo htmlspecialchars($setForm['size_label']); ?>" placeholder="e.g. 5 × 5ml">
        </div>
      </div>

      <div class="form-group">
        <label for="tb-concentration">Concentration</label>
        <input type="text" id="tb-concentration" name="concentration" value="<?php echo htmlspecialchars($setForm['concentration']); ?>" placeholder="e.g. Extrait de Parfum">
      </div>

      <div class="form-group">
        <label for="tb-intro">Intro / Short Description</label>
        <textarea id="tb-intro" name="intro"><?php echo htmlspecialchars($setForm['intro']); ?></textarea>
      </div>

      <div class="form-group">
        <label for="tb-olfactory_intro">Olfactory Intro (Discovery page)</label>
        <textarea id="tb-olfactory_intro" name="olfactory_intro"><?php echo htmlspecialchars($setForm['olfactory_intro']); ?></textarea>
      </div>

      <div class="form-group">
        <label for="tb-image">Box Image (Upload)</label>
        <input type="file" id="tb-image" name="set_image" accept="image/*" style="padding: 10px;">
        <input type="hidden" name="image" value="<?php echo htmlspecialchars($setForm['image']); ?>">
        <?php if (!empty($setForm['image'])): ?>
          <div style="margin-top: 10px; display: flex; align-items: center; gap: 10px;">
            <img src="../<?php echo htmlspecialchars($setForm['image']); ?>" alt="" style="height: 60px; width: auto; object-fit: contain; border: 1px solid var(--border); background: #fafbfc; padding: 2px;">
            <span style="font-size: 11px; color: var(--text-muted);">Current: <?php echo htmlspecialchars($setForm['image']); ?></span>
          </div>
        <?php endif; ?>
      </div>

      <div class="form-group" style="padding-top: 10px;">
        <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; text-transform: none; font-size: 13px; color: var(--text);">
          <input type="checkbox" name="is_active" value="1" <?php echo $setForm['is_active'] ? 'checked' : ''; ?> style="width: auto;"> Active (Visible on site)
        </label>
      </div>

      <div style="margin-top: 24px; display: flex; gap: 10px;">
        <button type="submit" class="btn"><?php echo $editingId > 0 ? 'Save Tester Box' : 'Add Tester Box'; ?></button>
        <?php if ($editingId > 0): ?>
          <a href="tester-boxes.php" class="btn btn-outline">Cancel</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- ===================== LIST ===================== -->
  <div class="content-card">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">
      All Tester Boxes
    </h2>

    <?php
    $sets = [];
    try {
      $sets = $pdo->query(
        'SELECT t.set_id, t.slug, t.name, t.price, t.image, t.is_active, c.name AS collection_name,
                (SELECT COUNT(*) FROM tester_set_items tsi WHERE tsi.set_id = t.set_id) AS item_count
         FROM tester_sets t
         LEFT JOIN collections c ON c.collection_id = t.collection_id
         ORDER BY t.sort_order, t.set_id'
      )->fetchAll();
    } catch (Throwable $e) {
      $sets = [];
    }
    ?>

    <?php if (count($sets) === 0): ?>
      <p style="color: var(--text-muted); font-size: 13px;">No tester boxes yet. Add one using the form.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Image</th>
            <th>Name / Slug</th>
            <th>Collection</th>
            <th>Perfumes</th>
            <th>Price</th>
            <th>Status</th>
            <th style="text-align: right;">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($sets as $set): ?>
            <tr>
              <td style="width: 64px;">
                <?php if (!empty($set['image'])): ?>
                  <img src="../<?php echo htmlspecialchars($set['image']); ?>" alt="" style="width: 40px; height: 52px; object-fit: contain; background: #f7fafc; padding: 2px; border: 1px solid var(--border);">
                <?php else: ?>
                  <span style="color: var(--text-muted); font-size: 11px;">No img</span>
                <?php endif; ?>
              </td>
              <td>
                <strong><?php echo htmlspecialchars($set['name']); ?></strong>
                <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars($set['slug']); ?></span>
              </td>
              <td><?php echo htmlspecialchars($set['collection_name'] ?? '—'); ?></td>
              <td><?php echo (int) $set['item_count']; ?></td>
              <td>Rs. <?php echo number_format((int) $set['price']); ?></td>
              <td>
                <?php if ($set['is_active']): ?>
                  <span class="badge badge-delivered">Active</span>
                <?php else: ?>
                  <span class="badge badge-cancelled">Inactive</span>
                <?php endif; ?>
              </td>
              <td style="text-align: right;">
                <a href="tester-boxes.php?edit=<?php echo (int) $set['set_id']; ?>" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">Edit</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<script>
(function () {
  /* Server-rendered catalog: collections with their perfumes */
  var CATALOG = <?php
    $cat = [];
    foreach ($collections as $col) {
      $prods = [];
      try {
        $ps = $pdo->prepare('SELECT product_id, name, expression FROM products WHERE collection_id = ? AND is_active = 1 ORDER BY sort_order, name');
        $ps->execute([(int) $col['collection_id']]);
        foreach ($ps->fetchAll() as $p) {
          $prods[] = ['id' => (int) $p['product_id'], 'name' => $p['name'], 'expression' => $p['expression']];
        }
      } catch (Throwable $e) {}
      $cat[] = ['id' => (int) $col['collection_id'], 'products' => $prods];
    }
    echo json_encode($cat);
  ?>;

  /* Pre-selected items: product_id => position */
  var SELECTED = <?php echo json_encode($selectedItems); ?>;

  var collectionSelect = document.getElementById('tb-collection');
  var perfumeList = document.getElementById('tb-perfume-list');
  var form = document.getElementById('tester-box-form');

  /* One hidden position input per product, kept in sync with check state.
     Only checked products submit their position (keyed by product id). */
  var posInputs = {};

  function assignNextPosition() {
    var max = 0;
    Object.keys(SELECTED).forEach(function (pid) {
      var v = parseInt(SELECTED[pid], 10);
      if (!isNaN(v) && v > max) max = v;
    });
    return max + 1;
  }

  function renderPerfumes() {
    var collId = parseInt(collectionSelect.value, 10) || 0;
    var coll = null;
    CATALOG.forEach(function (c) { if (c.id === collId) coll = c; });

    /* Remove stale hidden position inputs from any previous render */
    form.querySelectorAll('input[name^="item_position["]').forEach(function (el) { el.remove(); });

    if (!coll) {
      perfumeList.innerHTML = '<p style="font-size:12px;color:var(--text-muted);padding:8px;">Select a collection to see its perfumes.</p>';
      return;
    }

    if (!coll.products.length) {
      perfumeList.innerHTML = '<p style="font-size:12px;color:var(--text-muted);padding:8px;">This collection has no active perfumes.</p>';
      return;
    }

    var byPos = {};
    Object.keys(SELECTED).forEach(function (pid) {
      var pos = parseInt(SELECTED[pid], 10);
      if (isNaN(pos)) pos = assignNextPosition();
      byPos[pid] = pos;
    });

    var sorted = coll.products.slice().sort(function (a, b) {
      var hasA = SELECTED[a.id] !== undefined;
      var hasB = SELECTED[b.id] !== undefined;
      if (hasA !== hasB) return hasA ? -1 : 1;
      if (hasA && hasB) return (byPos[a.id] || 0) - (byPos[b.id] || 0);
      return a.name.localeCompare(b.name);
    });

    perfumeList.innerHTML = '';

    sorted.forEach(function (p) {
      var isSelected = SELECTED[p.id] !== undefined;

      var label = document.createElement('label');
      label.style.display = 'flex';
      label.style.alignItems = 'center';
      label.style.gap = '10px';
      label.style.padding = '8px 10px';
      label.style.borderBottom = '1px solid var(--border-light)';
      label.style.cursor = 'pointer';
      label.style.fontSize = '13px';

      var check = document.createElement('input');
      check.type = 'checkbox';
      check.name = 'selected_products[]';
      check.value = p.id;
      check.checked = isSelected;
      check.style.width = 'auto';

      var name = document.createElement('span');
      name.style.flex = '1';
      name.textContent = p.name;
      if (p.expression) {
        var sub = document.createElement('span');
        sub.style.display = 'block';
        sub.style.fontSize = '11px';
        sub.style.color = 'var(--text-muted)';
        sub.textContent = p.expression;
        name.appendChild(sub);
      }

      var posInput = document.createElement('input');
      posInput.type = 'number';
      posInput.min = '1';
      posInput.placeholder = 'pos';
      posInput.style.width = '56px';
      posInput.style.padding = '6px 8px';
      posInput.value = isSelected ? (byPos[p.id] || '') : '';
      posInput.style.opacity = isSelected ? '1' : '0.35';

      /* Hidden position field, keyed by product id, only present while checked */
      var hidden = null;
      function syncHidden() {
        if (hidden) hidden.remove();
        if (check.checked) {
          hidden = document.createElement('input');
          hidden.type = 'hidden';
          hidden.name = 'item_position[' + p.id + ']';
          hidden.value = (parseInt(posInput.value, 10) || '');
          form.appendChild(hidden);
        } else {
          hidden = null;
        }
      }

      check.addEventListener('change', function () {
        if (check.checked) {
          if (!posInput.value || isNaN(parseInt(posInput.value, 10))) {
            posInput.value = assignNextPosition();
          }
          SELECTED[p.id] = parseInt(posInput.value, 10);
          posInput.style.opacity = '1';
        } else {
          posInput.value = '';
          posInput.style.opacity = '0.35';
          delete SELECTED[p.id];
        }
        syncHidden();
      });

      posInput.addEventListener('input', function () {
        if (check.checked) {
          var v = parseInt(posInput.value, 10);
          if (!isNaN(v)) SELECTED[p.id] = v;
        }
        syncHidden();
      });

      posInput.addEventListener('click', function (e) {
        e.stopPropagation();
      });

      label.appendChild(check);
      label.appendChild(name);
      label.appendChild(posInput);
      perfumeList.appendChild(label);

      syncHidden();
    });
  }

  collectionSelect.addEventListener('change', renderPerfumes);
  renderPerfumes();
})();
</script>

<?php
include(__DIR__ . '/includes/footer.php');
?>
