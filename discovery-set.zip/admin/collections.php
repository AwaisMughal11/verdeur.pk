<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$successMsg = '';
$errorMsg = '';
$editingId = (int) ($_GET['edit'] ?? 0);

$collectionForm = [
  'slug' => '',
  'name' => '',
  'kicker' => '',
  'subtitle' => '',
  'description' => '',
  'count_label' => '',
  'sort_order' => 0,
  'is_active' => 1,
];

try {
  $pdo = verdeur_db();

  if ($editingId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM collections WHERE collection_id = ? LIMIT 1');
    $stmt->execute([$editingId]);
    $ex = $stmt->fetch();
    if ($ex) {
      $collectionForm = $ex;
    }
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
      $errorMsg = 'Security validation failed (CSRF token invalid).';
    } else {
      $name = trim((string) ($_POST['name'] ?? ''));
      $slug = trim((string) ($_POST['slug'] ?? ''));
      $kicker = trim((string) ($_POST['kicker'] ?? ''));
      $subtitle = trim((string) ($_POST['subtitle'] ?? ''));
      $description = trim((string) ($_POST['description'] ?? ''));
      $countLabel = trim((string) ($_POST['count_label'] ?? ''));
      $sortOrder = (int) ($_POST['sort_order'] ?? 0);
      $isActive = isset($_POST['is_active']) ? 1 : 0;
      $postEditId = (int) ($_POST['collection_id'] ?? 0);

      if ($name === '' || $slug === '') {
        $errorMsg = 'Collection name and slug are required.';
      } else {
        // Check unique slug
        $slugCheck = $pdo->prepare('SELECT collection_id FROM collections WHERE slug = ? AND collection_id <> ? LIMIT 1');
        $slugCheck->execute([$slug, $postEditId]);
        if ($slugCheck->fetch()) {
          $errorMsg = 'Collection slug already exists. Please choose a unique slug.';
        } else {
          if ($postEditId > 0) {
            $up = $pdo->prepare('UPDATE collections SET slug = ?, name = ?, kicker = ?, subtitle = ?, description = ?, count_label = ?, sort_order = ?, is_active = ? WHERE collection_id = ?');
            $up->execute([$slug, $name, $kicker, $subtitle, $description, $countLabel, $sortOrder, $isActive, $postEditId]);
            $successMsg = 'Collection updated successfully.';
          } else {
            $ins = $pdo->prepare('INSERT INTO collections (slug, name, kicker, subtitle, description, count_label, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $ins->execute([$slug, $name, $kicker, $subtitle, $description, $countLabel, $sortOrder, $isActive]);
            $successMsg = 'New collection added successfully.';
          }
          $collectionForm = ['slug' => '', 'name' => '', 'kicker' => '', 'subtitle' => '', 'description' => '', 'count_label' => '', 'sort_order' => 0, 'is_active' => 1];
          $editingId = 0;
        }
      }
    }
  }

  $collections = $pdo->query('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.collection_id = c.collection_id) AS product_count FROM collections c ORDER BY c.sort_order, c.collection_id')->fetchAll();

} catch (Throwable $e) {
  $errorMsg = 'Database error: ' . $e->getMessage();
  $collections = [];
}

$pageTitle = 'Collections — Verdeur Admin';
include(__DIR__ . '/includes/header.php');
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Collections Management</h1>
    <p>Add and manage fragrance collections</p>
  </div>
</div>

<?php if ($successMsg !== ''): ?>
  <div style="background: rgba(46, 204, 113, 0.1); border: 1px solid rgba(46, 204, 113, 0.3); color: #38a169; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($successMsg); ?>
  </div>
<?php endif; ?>

<?php if ($errorMsg !== ''): ?>
  <div style="background: rgba(229, 62, 62, 0.1); border: 1px solid rgba(229, 62, 62, 0.3); color: #e53e3e; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($errorMsg); ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 30px; align-items: start;">
  <!-- Add / Edit Form -->
  <div class="content-card">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">
      <?php echo $editingId > 0 ? 'Edit Collection' : 'Add New Collection'; ?>
    </h2>
    <form method="POST">
      <input type="hidden" name="collection_id" value="<?php echo $editingId; ?>">
      <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">

      <div class="form-group">
        <label for="name">Collection Name *</label>
        <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($collectionForm['name']); ?>">
      </div>

      <div class="form-group">
        <label for="slug">URL Slug *</label>
        <input type="text" id="slug" name="slug" required value="<?php echo htmlspecialchars($collectionForm['slug']); ?>">
      </div>

      <div class="form-group">
        <label for="kicker">Kicker</label>
        <input type="text" id="kicker" name="kicker" value="<?php echo htmlspecialchars($collectionForm['kicker']); ?>" placeholder="Verdeur's Collection">
      </div>

      <div class="form-group">
        <label for="subtitle">Subtitle</label>
        <input type="text" id="subtitle" name="subtitle" value="<?php echo htmlspecialchars($collectionForm['subtitle']); ?>">
      </div>

      <div class="form-group">
        <label for="description">Description</label>
        <textarea name="description" id="description" style="min-height: 100px;"><?php echo htmlspecialchars($collectionForm['description']); ?></textarea>
      </div>

      <div class="form-group">
        <label for="count_label">Count Label</label>
        <input type="text" id="count_label" name="count_label" value="<?php echo htmlspecialchars($collectionForm['count_label']); ?>" placeholder="5 Expressions">
      </div>

      <div class="form-group">
        <label for="sort_order">Sort Order</label>
        <input type="number" id="sort_order" name="sort_order" value="<?php echo (int) $collectionForm['sort_order']; ?>">
      </div>

      <div class="form-group" style="padding-top: 10px;">
        <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; text-transform: none; font-size: 13px; color: var(--text);">
          <input type="checkbox" name="is_active" value="1" <?php echo $collectionForm['is_active'] ? 'checked' : ''; ?> style="width: auto;"> Active
        </label>
      </div>

      <div style="margin-top: 24px; display: flex; gap: 10px;">
        <button type="submit" class="btn"><?php echo $editingId > 0 ? 'Update' : 'Add Collection'; ?></button>
        <?php if ($editingId > 0): ?>
          <a href="collections.php" class="btn btn-outline">Cancel</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Collections List -->
  <div class="content-card">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">All Collections</h2>
    <?php if (count($collections) === 0): ?>
      <p style="color: var(--text-muted); font-size: 13px;">No collections found.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Name / Slug</th>
            <th>Products</th>
            <th>Status</th>
            <th style="text-align: right;">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($collections as $col): ?>
            <tr>
              <td>
                <strong><?php echo htmlspecialchars($col['name']); ?></strong>
                <br><span style="font-size: 11px; color: var(--text-muted);">collection/<?php echo htmlspecialchars($col['slug']); ?></span>
              </td>
              <td><?php echo (int) $col['product_count']; ?> products</td>
              <td>
                <?php if ($col['is_active']): ?>
                  <span class="badge badge-delivered">Active</span>
                <?php else: ?>
                  <span class="badge badge-cancelled">Inactive</span>
                <?php endif; ?>
              </td>
              <td style="text-align: right;">
                <a href="collections.php?edit=<?php echo $col['collection_id']; ?>" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">Edit</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
