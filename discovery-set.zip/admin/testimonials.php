<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$successMsg = '';
$errorMsg = '';
$editingId = (int) ($_GET['edit'] ?? 0);

$testimonialForm = [
  'product_id'    => 0,
  'customer_name' => '',
  'quote'         => '',
  'label'         => '',
  'sort_order'    => 0,
  'is_active'     => 1,
];

try {
  $pdo = verdeur_db();

  if ($editingId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM testimonials WHERE testimonial_id = ? LIMIT 1');
    $stmt->execute([$editingId]);
    $ex = $stmt->fetch();
    if ($ex) {
      $testimonialForm = $ex;
    }
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
      $errorMsg = 'Security validation failed (CSRF token invalid).';
    } else {
      $postAction = (string) ($_POST['action'] ?? '');

      if ($postAction === 'delete') {
        $deleteId = (int) ($_POST['testimonial_id'] ?? 0);
        if ($deleteId > 0) {
          $pdo->prepare('DELETE FROM testimonials WHERE testimonial_id = ?')->execute([$deleteId]);
          $successMsg = 'Testimonial deleted successfully.';
        }
        header('Location: testimonials.php');
        exit;
      }

      $customerName = trim((string) ($_POST['customer_name'] ?? ''));
      $quote = trim((string) ($_POST['quote'] ?? ''));
      $label = trim((string) ($_POST['label'] ?? ''));
      $productId = (int) ($_POST['product_id'] ?? 0);
      $sortOrder = (int) ($_POST['sort_order'] ?? 0);
      $isActive = isset($_POST['is_active']) ? 1 : 0;
      $postEditId = (int) ($_POST['testimonial_id'] ?? 0);

      if ($customerName === '' || $quote === '') {
        $errorMsg = 'Customer name and quote are required.';
      } else {
        if ($postEditId > 0) {
          $up = $pdo->prepare('UPDATE testimonials SET product_id = ?, customer_name = ?, quote = ?, label = ?, sort_order = ?, is_active = ? WHERE testimonial_id = ?');
          $up->execute([$productId > 0 ? $productId : null, $customerName, $quote, $label, $sortOrder, $isActive, $postEditId]);
          $successMsg = 'Testimonial updated successfully.';
        } else {
          $ins = $pdo->prepare('INSERT INTO testimonials (product_id, customer_name, quote, label, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?)');
          $ins->execute([$productId > 0 ? $productId : null, $customerName, $quote, $label, $sortOrder, $isActive]);
          $successMsg = 'New testimonial added successfully.';
        }
        $testimonialForm = ['product_id' => 0, 'customer_name' => '', 'quote' => '', 'label' => '', 'sort_order' => 0, 'is_active' => 1];
        $editingId = 0;
      }
    }
  }

  $testimonials = $pdo->query(
    'SELECT t.*, p.name AS product_name
     FROM testimonials t
     LEFT JOIN products p ON p.product_id = t.product_id
     ORDER BY t.sort_order ASC, t.testimonial_id ASC'
  )->fetchAll();

  $products = $pdo->query(
    'SELECT product_id, name FROM products WHERE is_active = 1 ORDER BY name ASC'
  )->fetchAll();

} catch (Throwable $e) {
  $errorMsg = 'Database error: ' . $e->getMessage();
  $testimonials = [];
  $products = [];
}

$pageTitle = 'Testimonials — Verdeur Admin';
include(__DIR__ . '/includes/header.php');
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Testimonials Management</h1>
    <p>Add and manage client impressions on the homepage</p>
  </div>
</div>

<?php if ($successMsg !== ''): ?>
  <div style="background: rgba(46, 204, 113, 0.1); border: 1px solid rgba(46, 204, 113, 0.3); color: #38a169; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($successMsg); ?>
  </div>
<?php endif; ?>

<?php if ($errorMsg !== ''): ?>
  <div style="background: rgba(229, 62, 62, 0.1); border: 1px solid rgba(229, 62, 62, 0.3); color: #e53e3e; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($errorMsg); ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 30px; align-items: start;">
  <!-- Add / Edit Form -->
  <div class="content-card">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">
      <?php echo $editingId > 0 ? 'Edit Testimonial' : 'Add New Testimonial'; ?>
    </h2>
    <form method="POST">
      <input type="hidden" name="testimonial_id" value="<?php echo $editingId; ?>">
      <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">

      <div class="form-group">
        <label for="customer_name">Customer Name *</label>
        <input type="text" id="customer_name" name="customer_name" required value="<?php echo htmlspecialchars($testimonialForm['customer_name']); ?>">
      </div>

      <div class="form-group">
        <label for="quote">Quote *</label>
        <textarea name="quote" id="quote" required style="min-height: 110px;"><?php echo htmlspecialchars($testimonialForm['quote']); ?></textarea>
      </div>

      <div class="form-group">
        <label for="label">Fragrance / Label</label>
        <input type="text" id="label" name="label" value="<?php echo htmlspecialchars($testimonialForm['label']); ?>" placeholder="e.g. Lotus Noir">
      </div>

      <div class="form-group">
        <label for="product_id">Linked Product (optional)</label>
        <select id="product_id" name="product_id">
          <option value="0">— General (no product) —</option>
          <?php foreach ($products as $product): ?>
            <option value="<?php echo (int) $product['product_id']; ?>" <?php echo (int) $testimonialForm['product_id'] === (int) $product['product_id'] ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($product['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label for="sort_order">Sort Order</label>
        <input type="number" id="sort_order" name="sort_order" value="<?php echo (int) $testimonialForm['sort_order']; ?>">
      </div>

      <div class="form-group" style="padding-top: 10px;">
        <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; text-transform: none; font-size: 13px; color: var(--text);">
          <input type="checkbox" name="is_active" value="1" <?php echo $testimonialForm['is_active'] ? 'checked' : ''; ?> style="width: auto;"> Active
        </label>
      </div>

      <div style="margin-top: 24px; display: flex; gap: 10px;">
        <button type="submit" class="btn"><?php echo $editingId > 0 ? 'Update' : 'Add Testimonial'; ?></button>
        <?php if ($editingId > 0): ?>
          <a href="testimonials.php" class="btn btn-outline">Cancel</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Testimonials List -->
  <div class="content-card">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">All Testimonials</h2>
    <?php if (count($testimonials) === 0): ?>
      <p style="color: var(--text-muted); font-size: 13px;">No testimonials found.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Customer / Quote</th>
            <th>Product</th>
            <th>Status</th>
            <th style="text-align: right;">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($testimonials as $testimonial): ?>
            <tr>
              <td>
                <strong><?php echo htmlspecialchars($testimonial['customer_name']); ?></strong>
                <br><span style="font-size: 12px; color: var(--text-muted);"><?php echo htmlspecialchars(mb_strimwidth($testimonial['quote'], 0, 90, '…')); ?></span>
              </td>
              <td>
                <?php if (!empty($testimonial['label'])): ?>
                  <strong><?php echo htmlspecialchars($testimonial['label']); ?></strong>
                  <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars($testimonial['product_name'] ?? 'General'); ?></span>
                <?php else: ?>
                  <span style="color: var(--text-muted);"><?php echo htmlspecialchars($testimonial['product_name'] ?? 'General'); ?></span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($testimonial['is_active']): ?>
                  <span class="badge badge-delivered">Active</span>
                <?php else: ?>
                  <span class="badge badge-cancelled">Inactive</span>
                <?php endif; ?>
              </td>
              <td style="text-align: right;">
                <div style="display: inline-flex; gap: 6px; align-items: center;">
                  <a href="testimonials.php?edit=<?php echo $testimonial['testimonial_id']; ?>" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">Edit</a>
                  <form method="POST" style="display: inline;">
                    <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">
                    <input type="hidden" name="testimonial_id" value="<?php echo $testimonial['testimonial_id']; ?>">
                    <button type="submit" name="action" value="delete" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px; color: #e53e3e;" onclick="return confirm('Delete this testimonial?');">Delete</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>