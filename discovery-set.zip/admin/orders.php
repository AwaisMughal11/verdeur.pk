<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$pageTitle = 'Orders — Verdeur Admin';
include(__DIR__ . '/includes/header.php');

$statusFilter = trim((string) ($_GET['status'] ?? ''));
$search = trim((string) ($_GET['q'] ?? ''));

try {
  $pdo = verdeur_db();

  $sql = 'SELECT order_id, order_number, customer_name, customer_phone,
                 customer_city, customer_province, total, payment_method,
                 payment_status, order_status, created_at
          FROM orders WHERE 1=1';
  $params = [];

  if ($statusFilter !== '') {
    $sql .= ' AND order_status = ?';
    $params[] = $statusFilter;
  }

  if ($search !== '') {
    $sql .= ' AND (order_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ? OR customer_city LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like);
  }

  $sql .= ' ORDER BY created_at DESC';

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $orders = $stmt->fetchAll();

} catch (Throwable $e) {
  $orders = [];
}

/* ---------------------------------------------
   DIAGNOSTIC: show real table columns on CPanel
   Usage:  admin/orders.php?debug=columns
   Helps confirm the deployed DB schema matches
   what the code expects (fixes empty columns).
--------------------------------------------- */
if ((string) ($_GET['debug'] ?? '') === 'columns') {
  $expected = [
    'orders'   => ['order_id','order_number','customer_name','customer_phone','customer_email','customer_address','customer_city','customer_province','customer_notes','subtotal','shipping','total','payment_method','order_status','payment_status','bank_account_id','created_at'],
    'products' => ['product_id','slug','collection_id','name','expression','price','image','meta','family','best_for','top_notes','heart_notes','base_notes','home_description','conclusion','accent','featured','sort_order','is_active'],
  ];
  $missing = [];
  try {
    foreach (['orders', 'products'] as $tbl) {
      $cols = $pdo->query('SHOW COLUMNS FROM `' . $tbl . '`')->fetchAll(PDO::FETCH_COLUMN);
      $missing[$tbl] = array_values(array_diff($expected[$tbl], $cols));
    }
  } catch (Throwable $e) {
    $missing = ['error' => $e->getMessage()];
  }
  echo '<div class="content-card" style="margin-bottom:20px;padding:16px 22px;">';
  echo '<h3 style="font-size:13px;margin-bottom:12px;">DB schema check (orders / products)</h3>';
  if (isset($missing['error'])) {
    echo '<p style="color:#c0392b;font-size:12px;">' . htmlspecialchars($missing['error']) . '</p>';
  } else {
    foreach (['orders' => 'orders table', 'products' => 'products table'] as $tbl => $label) {
      echo '<p style="font-size:12px;margin:8px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ';
      if ($missing[$tbl]) {
        echo '<span style="color:#c0392b;">MISSING columns → ' . htmlspecialchars(implode(', ', $missing[$tbl])) . '</span>';
      } else {
        echo '<span style="color:#27ae60;">All expected columns present.</span>';
      }
      echo '</p>';
    }
  }
  echo '<p style="font-size:11px;color:#999;margin-top:10px;">Fix: recreate/alter the ' . htmlspecialchars('orders') . ' and ' . htmlspecialchars('products') . ' tables to match db/install.php (or add the missing columns above).</p>';
  echo '</div>';
}
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Customer Orders</h1>
    <p>Manage and update customer orders</p>
  </div>
</div>

<div class="content-card" style="margin-bottom: 20px; padding: 20px 28px;">
  <form method="GET" style="display: flex; gap: 15px; flex-wrap: wrap; align-items: center;">
    <div style="flex: 1; min-width: 220px;">
      <input type="text" name="q" placeholder="Search by order #, name, phone, city..." value="<?php echo htmlspecialchars($search); ?>" style="width: 100%; padding: 12px 16px; background: #fafbfc; border: 1px solid var(--border); color: var(--text); font-family: inherit; font-size: 13px; outline: none;">
    </div>
    <div>
      <select name="status" style="padding: 12px 16px; background: #fafbfc; border: 1px solid var(--border); color: var(--text); font-family: inherit; font-size: 13px; outline: none;">
        <option value="">All Statuses</option>
        <option value="Pending" <?php echo $statusFilter === 'Pending' ? 'selected' : ''; ?>>Pending</option>
        <option value="Confirmed" <?php echo $statusFilter === 'Confirmed' ? 'selected' : ''; ?>>Confirmed</option>
        <option value="Shipped" <?php echo $statusFilter === 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
        <option value="Delivered" <?php echo $statusFilter === 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
        <option value="Cancelled" <?php echo $statusFilter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
      </select>
    </div>
    <div>
      <button type="submit" class="btn" style="padding: 12px 20px;">Filter</button>
      <?php if ($statusFilter !== '' || $search !== ''): ?>
        <a href="orders.php" class="btn btn-outline" style="padding: 11px 16px; margin-left: 8px;">Reset</a>
      <?php endif; ?>
    </div>
  </form>
</div>

<div class="content-card">
  <?php if (count($orders) === 0): ?>
    <p style="color: var(--text-muted); font-size: 13px;">No orders found.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Order #</th>
          <th>Customer</th>
          <th>Location</th>
          <th>Total</th>
          <th>Payment</th>
          <th>Status</th>
          <th>Date</th>
          <th style="text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $order):
          $orderStatus   = (string) ($order['order_status'] ?? '');
          $statusClass   = 'badge-' . strtolower($orderStatus);
          $paymentMethod = (string) ($order['payment_method'] ?? '');
          $paymentStatus = (string) ($order['payment_status'] ?? '');
          $orderTotal    = (int) ($order['total'] ?? 0);
          $orderId       = (int) ($order['order_id'] ?? 0);
          $createdAt     = (string) ($order['created_at'] ?? '');
          $orderDate     = $createdAt !== '' ? date('d M Y, H:i', strtotime($createdAt)) : '—';
        ?>
          <tr>
            <td><strong><?php echo htmlspecialchars((string) ($order['order_number'] ?? '')); ?></strong></td>
            <td>
              <?php echo htmlspecialchars((string) ($order['customer_name'] ?? '')); ?>
              <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars((string) ($order['customer_phone'] ?? '')); ?></span>
            </td>
            <td>
              <?php echo htmlspecialchars((string) ($order['customer_city'] ?? '')); ?>
              <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars((string) ($order['customer_province'] ?? '')); ?></span>
            </td>
            <td>Rs. <?php echo number_format($orderTotal); ?></td>
            <td>
              <span class="badge" style="background: rgba(0,0,0,0.03);"><?php echo htmlspecialchars($paymentMethod); ?></span>
              <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars($paymentStatus); ?></span>
            </td>
            <td><span class="badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($orderStatus); ?></span></td>
            <td style="font-size: 12px; color: var(--text-muted);"><?php echo $orderDate; ?></td>
            <td style="text-align: right;">
              <a href="order-detail.php?id=<?php echo $orderId; ?>" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">Details</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
