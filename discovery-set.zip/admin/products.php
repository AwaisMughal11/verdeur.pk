<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$pageTitle = 'Products — Verdeur Admin';
include(__DIR__ . '/includes/header.php');

$successMsg = '';
if (isset($_GET['success'])) {
  $successMsg = 'Product saved successfully.';
}

$search = trim((string) ($_GET['q'] ?? ''));
$colFilter = (int) ($_GET['collection'] ?? 0);

try {
  $pdo = verdeur_db();
  $collections = $pdo->query('SELECT collection_id, name FROM collections ORDER BY sort_order')->fetchAll();

  $sql = 'SELECT p.product_id, p.name, p.expression, p.slug, p.image,
                 p.price, p.featured, p.is_active, c.name AS collection_name
     FROM products p
     JOIN collections c ON c.collection_id = p.collection_id
     WHERE 1=1';
  $params = [];

  if ($search !== '') {
    $sql .= ' AND (p.name LIKE ? OR p.expression LIKE ? OR p.slug LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
  }

  if ($colFilter > 0) {
    $sql .= ' AND p.collection_id = ?';
    $params[] = $colFilter;
  }

  $sql .= ' ORDER BY c.sort_order, p.sort_order';

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $products = $stmt->fetchAll();

} catch (Throwable $e) {
  $products = [];
  $collections = [];
}
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Products</h1>
    <p>Manage fragrance catalogue</p>
  </div>
  <div class="admin-header-actions" style="display: flex; gap: 10px; flex-wrap: wrap;">
    <a href="sort-products.php" class="btn btn-outline">Reorder Products</a>
    <a href="product-form.php" class="btn">+ Add Product</a>
  </div>
</div>

<?php if ($successMsg !== ''): ?>
  <div style="background: rgba(46, 204, 113, 0.1); border: 1px solid rgba(46, 204, 113, 0.3); color: #2ecc71; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($successMsg); ?>
  </div>
<?php endif; ?>

<div class="content-card" style="margin-bottom: 20px; padding: 20px 28px;">
  <form method="GET" style="display: flex; gap: 15px; flex-wrap: wrap; align-items: center;">
    <div style="flex: 1; min-width: 220px;">
      <input type="text" name="q" placeholder="Search by name, expression, slug..." value="<?php echo htmlspecialchars($search); ?>" style="width: 100%; padding: 12px 16px; background: #fafbfc; border: 1px solid var(--border); color: var(--text); font-family: inherit; font-size: 13px; outline: none;">
    </div>
    <div>
      <select name="collection" style="padding: 12px 16px; background: #fafbfc; border: 1px solid var(--border); color: var(--text); font-family: inherit; font-size: 13px; outline: none;">
        <option value="0">All Collections</option>
        <?php foreach ($collections as $c): ?>
          <option value="<?php echo $c['collection_id']; ?>" <?php echo $colFilter === (int) $c['collection_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['name']); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <button type="submit" class="btn" style="padding: 12px 20px;">Filter</button>
      <?php if ($search !== '' || $colFilter > 0): ?>
        <a href="products.php" class="btn btn-outline" style="padding: 11px 16px; margin-left: 8px;">Reset</a>
      <?php endif; ?>
    </div>
  </form>
</div>

<div class="content-card">
  <?php if (count($products) === 0): ?>
    <p style="color: var(--text-muted); font-size: 13px;">No products found.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Image</th>
          <th>Name / Expression</th>
          <th>Collection</th>
          <th>Price</th>
          <th>Featured</th>
          <th>Status</th>
          <th style="text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $product):
          $productId     = (int) ($product['product_id'] ?? 0);
          $productPrice  = (int) ($product['price'] ?? 0);
          $productImage  = (string) ($product['image'] ?? '');
          $productName   = (string) ($product['name'] ?? '');
          $productExpr   = (string) ($product['expression'] ?? '');
          $collectionName= (string) ($product['collection_name'] ?? '');
          $isFeatured    = (int) ($product['featured'] ?? 0);
          $isActive      = (int) ($product['is_active'] ?? 0);
        ?>
          <tr>
            <td style="width: 60px;">
              <?php if ($productImage !== ''): ?>
                <img src="../<?php echo htmlspecialchars($productImage); ?>" alt="" style="width: 36px; height: 50px; object-fit: contain; background: #f7fafc; padding: 2px; border: 1px solid var(--border);">
              <?php else: ?>
                <span style="color: var(--text-muted); font-size: 11px;">No img</span>
              <?php endif; ?>
            </td>
            <td>
              <strong><?php echo htmlspecialchars($productName); ?></strong>
              <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars($productExpr); ?></span>
            </td>
            <td><?php echo htmlspecialchars($collectionName); ?></td>
            <td>Rs. <?php echo number_format($productPrice); ?></td>
            <td>
              <?php if ($isFeatured): ?>
                <span class="badge" style="background: rgba(0,0,0,0.05);">Featured</span>
              <?php else: ?>
                <span style="color: var(--text-muted); font-size: 11px;">—</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($isActive): ?>
                <span class="badge badge-delivered">Active</span>
              <?php else: ?>
                <span class="badge badge-cancelled">Inactive</span>
              <?php endif; ?>
            </td>
            <td style="text-align: right;">
              <a href="product-form.php?id=<?php echo $productId; ?>" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">Edit</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
