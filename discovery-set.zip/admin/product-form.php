<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$productId = (int) ($_GET['id'] ?? 0);
$isEditing = $productId > 0;
$errorMsg = '';

$product = [
  'slug' => '',
  'collection_id' => 1,
  'name' => '',
  'expression' => '',
  'price' => 0,
  'image' => '',
  'meta' => '',
  'family' => '',
  'best_for' => '',
  'top_notes' => '',
  'heart_notes' => '',
  'base_notes' => '',
  'home_description' => '',
  'conclusion' => '',
  'accent' => '#000000',
  'featured' => 0,
  'is_active' => 1,
];

$chapterDefaults = [
  1 => ['kicker' => 'Chapter I', 'title' => 'The Opening', 'copy' => '', 'image' => 'assets/images/nc-opening.webp'],
  2 => ['kicker' => 'Chapter II', 'title' => 'The Heart', 'copy' => '', 'image' => 'assets/images/nc-heart.webp'],
  3 => ['kicker' => 'Chapter III', 'title' => 'The Drydown', 'copy' => '', 'image' => 'assets/images/nc-base.webp'],
];

$chapterMap = $chapterDefaults;

try {
  $pdo = verdeur_db();
  $collections = $pdo->query('SELECT collection_id, name FROM collections ORDER BY sort_order')->fetchAll();

  if ($isEditing) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE product_id = ? LIMIT 1');
    $stmt->execute([$productId]);
    $existing = $stmt->fetch();
    if ($existing) {
      $product = $existing;
    } else {
      header('Location: products.php');
      exit;
    }

    $chStmt = $pdo->prepare('SELECT * FROM product_stories WHERE product_id = ? ORDER BY chapter_no');
    $chStmt->execute([$productId]);
    foreach ($chStmt->fetchAll() as $ch) {
      $no = (int) $ch['chapter_no'];
      if (isset($chapterMap[$no])) {
        $chapterMap[$no] = [
          'kicker' => $ch['kicker'],
          'title' => $ch['title'],
          'copy' => $ch['copy'],
          'image' => $ch['image'],
        ];
      }
    }
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
      $errorMsg = 'Security validation failed (CSRF token invalid).';
    }

    $product['slug'] = trim((string) ($_POST['slug'] ?? ''));
    $product['collection_id'] = (int) ($_POST['collection_id'] ?? 1);
    $product['name'] = trim((string) ($_POST['name'] ?? ''));
    $product['expression'] = trim((string) ($_POST['expression'] ?? ''));
    $product['price'] = (int) ($_POST['price'] ?? 0);
    $product['meta'] = trim((string) ($_POST['meta'] ?? ''));
    $product['family'] = trim((string) ($_POST['family'] ?? ''));
    $product['best_for'] = trim((string) ($_POST['best_for'] ?? ''));
    $product['top_notes'] = trim((string) ($_POST['top_notes'] ?? ''));
    $product['heart_notes'] = trim((string) ($_POST['heart_notes'] ?? ''));
    $product['base_notes'] = trim((string) ($_POST['base_notes'] ?? ''));
    $product['home_description'] = trim((string) ($_POST['home_description'] ?? ''));
    $product['conclusion'] = trim((string) ($_POST['conclusion'] ?? ''));
    $product['accent'] = trim((string) ($_POST['accent'] ?? '#000000'));
    $product['featured'] = isset($_POST['featured']) ? 1 : 0;
    $product['is_active'] = isset($_POST['is_active']) ? 1 : 0;

    // Validate unique slug
    $slugCheck = $pdo->prepare('SELECT product_id FROM products WHERE slug = ? AND product_id <> ? LIMIT 1');
    $slugCheck->execute([$product['slug'], $productId]);
    if ($slugCheck->fetch()) {
      $errorMsg = 'This URL slug is already in use by another product. Please choose a unique slug.';
    }

    // Handle main product image upload
    $imagePath = $product['image'];
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
      $fileTmp = $_FILES['product_image']['tmp_name'];
      $ext = strtolower(pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION));
      $allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg'];
      if (in_array($ext, $allowed, true)) {
        $newFileName = 'prod_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
        $uploadDir = __DIR__ . '/../assets/images/';
        if (!is_dir($uploadDir)) {
          mkdir($uploadDir, 0755, true);
        }
        if (move_uploaded_file($fileTmp, $uploadDir . $newFileName)) {
          $imagePath = 'assets/images/' . $newFileName;
        }
      }
    }
    $product['image'] = $imagePath;

    // Collect chapters POST data
    for ($i = 1; $i <= 3; $i++) {
      $chapterMap[$i]['kicker'] = trim((string) ($_POST["chapter_{$i}_kicker"] ?? $chapterMap[$i]['kicker']));
      $chapterMap[$i]['title'] = trim((string) ($_POST["chapter_{$i}_title"] ?? $chapterMap[$i]['title']));
      $chapterMap[$i]['copy'] = trim((string) ($_POST["chapter_{$i}_copy"] ?? $chapterMap[$i]['copy']));

      // Handle chapter image upload
      if (isset($_FILES["chapter_{$i}_image"]) && $_FILES["chapter_{$i}_image"]["error"] === UPLOAD_ERR_OK) {
        $cTmp = $_FILES["chapter_{$i}_image"]["tmp_name"];
        $cExt = strtolower(pathinfo($_FILES["chapter_{$i}_image"]["name"], PATHINFO_EXTENSION));
        if (in_array($cExt, ['jpg', 'jpeg', 'png', 'webp', 'svg'], true)) {
          $cFileName = 'ch_' . $i . '_' . time() . '_' . mt_rand(1000, 9999) . '.' . $cExt;
          $uploadDir = __DIR__ . '/../assets/images/';
          if (move_uploaded_file($cTmp, $uploadDir . $cFileName)) {
            $chapterMap[$i]['image'] = 'assets/images/' . $cFileName;
          }
        }
      }
    }

    if ($errorMsg === '') {
      if ($product['name'] === '' || $product['slug'] === '') {
        $errorMsg = 'Product name and slug are required.';
      } else {
        $pdo->beginTransaction();

        try {
          if ($isEditing) {
            $up = $pdo->prepare(
              'UPDATE products SET slug = ?, collection_id = ?, name = ?, expression = ?, price = ?, image = ?, meta = ?, family = ?, best_for = ?, top_notes = ?, heart_notes = ?, base_notes = ?, home_description = ?, conclusion = ?, accent = ?, featured = ?, is_active = ? WHERE product_id = ?'
            );
            $up->execute([
              $product['slug'], $product['collection_id'], $product['name'], $product['expression'], $product['price'], $product['image'], $product['meta'], $product['family'], $product['best_for'], $product['top_notes'], $product['heart_notes'], $product['base_notes'], $product['home_description'], $product['conclusion'], $product['accent'], $product['featured'], $product['is_active'], $productId
            ]);
            $targetProductId = $productId;
          } else {
            $maxSort = (int) $pdo->query('SELECT COALESCE(MAX(sort_order), 0) FROM products')->fetchColumn();
            $newSort = $maxSort + 1;

            $ins = $pdo->prepare(
              'INSERT INTO products (slug, collection_id, name, expression, price, image, meta, family, best_for, top_notes, heart_notes, base_notes, home_description, conclusion, accent, featured, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $ins->execute([
              $product['slug'], $product['collection_id'], $product['name'], $product['expression'], $product['price'], $product['image'], $product['meta'], $product['family'], $product['best_for'], $product['top_notes'], $product['heart_notes'], $product['base_notes'], $product['home_description'], $product['conclusion'], $product['accent'], $product['featured'], $newSort, $product['is_active']
            ]);
            $targetProductId = (int) $pdo->lastInsertId();
          }

          // Save / Replace product stories
          $pdo->prepare('DELETE FROM product_stories WHERE product_id = ?')->execute([$targetProductId]);
          $insStory = $pdo->prepare('INSERT INTO product_stories (product_id, chapter_no, kicker, title, copy, image) VALUES (?, ?, ?, ?, ?, ?)');
          
          for ($i = 1; $i <= 3; $i++) {
            $ch = $chapterMap[$i];
            $insStory->execute([
              $targetProductId,
              $i,
              $ch['kicker'],
              $ch['title'],
              $ch['copy'],
              $ch['image']
            ]);
          }

          $pdo->commit();
          header('Location: products.php?success=1');
          exit;

        } catch (Throwable $dbEx) {
          $pdo->rollBack();
          $errorMsg = 'Database error: ' . $dbEx->getMessage();
        }
      }
    }
  }

} catch (Throwable $e) {
  $errorMsg = 'Error: ' . $e->getMessage();
  $collections = [];
}

$pageTitle = ($isEditing ? 'Edit Product' : 'Add Product') . ' — Verdeur Admin';
include(__DIR__ . '/includes/header.php');
?>

<div class="admin-header">
  <div class="admin-title">
    <h1><?php echo $isEditing ? 'Edit Product: ' . htmlspecialchars($product['name']) : 'Add New Product'; ?></h1>
    <p>Configure fragrance details, stories & chapters</p>
  </div>
  <a href="products.php" class="btn btn-outline">← Back to Products</a>
</div>

<?php if ($errorMsg !== ''): ?>
  <div style="background: rgba(229, 62, 62, 0.1); border: 1px solid rgba(229, 62, 62, 0.3); color: #e53e3e; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($errorMsg); ?>
  </div>
<?php endif; ?>

<div class="content-card">
  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Basic Information</h2>
    
    <div class="form-row">
      <div class="form-group">
        <label for="name">Product Name *</label>
        <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($product['name']); ?>">
      </div>
      <div class="form-group">
        <label for="slug">URL Slug * (Must be unique)</label>
        <input type="text" id="slug" name="slug" required value="<?php echo htmlspecialchars($product['slug']); ?>" placeholder="e.g. pearls-and-petals">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="collection_id">Collection *</label>
        <select id="collection_id" name="collection_id">
          <?php foreach ($collections as $col): ?>
            <option value="<?php echo $col['collection_id']; ?>" <?php echo (int) $product['collection_id'] === (int) $col['collection_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($col['name']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label for="price">Price (Rs.) *</label>
        <input type="number" id="price" name="price" required value="<?php echo (int) $product['price']; ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="expression">Expression / Subtitle</label>
        <input type="text" id="expression" name="expression" value="<?php echo htmlspecialchars($product['expression']); ?>">
      </div>
      <div class="form-group">
        <label for="meta">Meta / Concentration</label>
        <input type="text" id="meta" name="meta" value="<?php echo htmlspecialchars($product['meta']); ?>">
      </div>
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="product_image">Main Product Bottle Image</label>
        <input type="file" id="product_image" name="product_image" accept="image/*" style="padding: 10px;">
        <input type="hidden" name="image" value="<?php echo htmlspecialchars($product['image']); ?>">
        <?php if (!empty($product['image'])): ?>
          <div style="margin-top: 10px; display: flex; align-items: center; gap: 10px;">
            <img src="../<?php echo htmlspecialchars($product['image']); ?>" alt="" style="height: 50px; width: auto; object-fit: contain; border: 1px solid var(--border); background: #fafbfc; padding: 2px;">
            <span style="font-size: 11px; color: var(--text-muted);">Current: <?php echo htmlspecialchars($product['image']); ?></span>
          </div>
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label for="family">Olfactory Family</label>
        <input type="text" id="family" name="family" value="<?php echo htmlspecialchars($product['family']); ?>">
      </div>
    </div>

    <div class="form-group">
      <label for="best_for">Best For</label>
      <input type="text" id="best_for" name="best_for" value="<?php echo htmlspecialchars($product['best_for']); ?>">
    </div>

    <div class="form-row">
      <div class="form-group">
        <label for="top_notes">Top Notes</label>
        <textarea name="top_notes" id="top_notes" style="min-height: 80px;"><?php echo htmlspecialchars($product['top_notes']); ?></textarea>
      </div>
      <div class="form-group">
        <label for="heart_notes">Heart Notes</label>
        <textarea name="heart_notes" id="heart_notes" style="min-height: 80px;"><?php echo htmlspecialchars($product['heart_notes']); ?></textarea>
      </div>
      <div class="form-group">
        <label for="base_notes">Base Notes</label>
        <textarea name="base_notes" id="base_notes" style="min-height: 80px;"><?php echo htmlspecialchars($product['base_notes']); ?></textarea>
      </div>
    </div>

    <div class="form-group">
      <label for="home_description">Home Description (Snippet for homepage)</label>
      <input type="text" id="home_description" name="home_description" value="<?php echo htmlspecialchars($product['home_description']); ?>">
    </div>

    <div class="form-group">
      <label for="conclusion">Conclusion / Story Paragraph</label>
      <textarea name="conclusion" id="conclusion"><?php echo htmlspecialchars($product['conclusion']); ?></textarea>
    </div>

    <!-- PRODUCT STORIES / CHAPTERS -->
    <hr style="border: none; border-top: 1px solid var(--border); margin: 35px 0 25px;">
    <h2 style="font-size: 15px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Product Story Chapters (The Opening, Heart, Drydown)</h2>

    <?php for ($i = 1; $i <= 3; $i++): 
      $ch = $chapterMap[$i];
    ?>
      <div style="background: #fafbfc; border: 1px solid var(--border); padding: 20px; margin-bottom: 20px;">
        <h3 style="font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 15px; color: #111;">
          Chapter <?php echo $i; ?>: <?php echo htmlspecialchars($ch['title']); ?>
        </h3>

        <div class="form-row">
          <div class="form-group">
            <label for="chapter_<?php echo $i; ?>_kicker">Kicker (e.g. Chapter I)</label>
            <input type="text" id="chapter_<?php echo $i; ?>_kicker" name="chapter_<?php echo $i; ?>_kicker" value="<?php echo htmlspecialchars($ch['kicker']); ?>">
          </div>
          <div class="form-group">
            <label for="chapter_<?php echo $i; ?>_title">Heading Text (e.g. The Opening)</label>
            <input type="text" id="chapter_<?php echo $i; ?>_title" name="chapter_<?php echo $i; ?>_title" value="<?php echo htmlspecialchars($ch['title']); ?>">
          </div>
        </div>

        <div class="form-group">
          <label for="chapter_<?php echo $i; ?>_copy">Paragraph Text / Story Copy</label>
          <textarea id="chapter_<?php echo $i; ?>_copy" name="chapter_<?php echo $i; ?>_copy" style="min-height: 90px;"><?php echo htmlspecialchars($ch['copy']); ?></textarea>
        </div>

        <div class="form-group">
          <label for="chapter_<?php echo $i; ?>_image">Chapter Image (Upload from Computer)</label>
          <input type="file" id="chapter_<?php echo $i; ?>_image" name="chapter_<?php echo $i; ?>_image" accept="image/*" style="padding: 8px;">
          <?php if (!empty($ch['image'])): ?>
            <div style="margin-top: 8px; display: flex; align-items: center; gap: 10px;">
              <img src="../<?php echo htmlspecialchars($ch['image']); ?>" alt="" style="height: 45px; width: auto; object-fit: contain; border: 1px solid var(--border); background: #fff; padding: 2px;">
              <span style="font-size: 11px; color: var(--text-muted);">Current: <?php echo htmlspecialchars($ch['image']); ?></span>
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endfor; ?>

    <div class="form-row" style="margin-top: 30px;">
      <div class="form-group" style="display: flex; gap: 30px; align-items: center; padding-top: 24px;">
        <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; text-transform: none; font-size: 13px; color: var(--text);">
          <input type="checkbox" name="featured" value="1" <?php echo $product['featured'] ? 'checked' : ''; ?> style="width: auto;"> Featured on Homepage
        </label>
        <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; text-transform: none; font-size: 13px; color: var(--text);">
          <input type="checkbox" name="is_active" value="1" <?php echo $product['is_active'] ? 'checked' : ''; ?> style="width: auto;"> Active (Visible on site)
        </label>
      </div>
    </div>

    <div style="margin-top: 30px;">
      <button type="submit" class="btn">Save Product & Chapters</button>
      <a href="products.php" class="btn btn-outline" style="margin-left: 10px;">Cancel</a>
    </div>
  </form>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
