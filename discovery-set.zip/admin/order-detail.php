<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$orderId = (int) ($_GET['id'] ?? 0);
$successMsg = '';
$errorMsg = '';

try {
  $pdo = verdeur_db();

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
      $errorMsg = 'Security validation failed (CSRF token invalid).';
    } else {
      $newStatus = trim((string) ($_POST['order_status'] ?? ''));
      $newPayment = trim((string) ($_POST['payment_status'] ?? ''));

      $up = $pdo->prepare('UPDATE orders SET order_status = ?, payment_status = ? WHERE order_id = ?');
      $up->execute([$newStatus, $newPayment, $orderId]);
      $successMsg = 'Order updated successfully.';
    }
  }

  $stmt = $pdo->prepare('SELECT * FROM orders WHERE order_id = ? LIMIT 1');
  $stmt->execute([$orderId]);
  $order = $stmt->fetch();

  if (!$order) {
    header('Location: orders.php');
    exit;
  }

  $itemsStmt = $pdo->prepare(
    'SELECT oi.*, p.image AS product_image 
     FROM order_items oi 
     LEFT JOIN products p ON p.product_id = oi.product_id 
     WHERE oi.order_id = ?'
  );
  $itemsStmt->execute([$orderId]);
  $items = $itemsStmt->fetchAll();

} catch (Throwable $e) {
  header('Location: orders.php');
  exit;
}

$pageTitle = 'Order ' . $order['order_number'] . ' — Verdeur Admin';
include(__DIR__ . '/includes/header.php');
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Order #<?php echo htmlspecialchars($order['order_number']); ?></h1>
    <p>Placed on <?php echo date('d M Y, H:i', strtotime($order['created_at'])); ?></p>
  </div>
  <div style="display: flex; gap: 10px; align-items: center;">
    <button type="button" onclick="window.print();" class="btn btn-outline" style="background: #fff;">🖨 Print A5 Label</button>
    <a href="orders.php" class="btn btn-outline">← Back to Orders</a>
  </div>
</div>

<?php if ($successMsg !== ''): ?>
  <div style="background: rgba(46, 204, 113, 0.1); border: 1px solid rgba(46, 204, 113, 0.3); color: #2ecc71; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($successMsg); ?>
  </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px; align-items: start;" class="no-print">

  <div>
    <!-- Order Items -->
    <div class="content-card" style="margin-bottom: 30px;">
      <h2 style="font-size: 15px; font-weight: 500; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Ordered Items</h2>
      <table>
        <thead>
          <tr>
            <th style="width: 50px;">Image</th>
            <th>Item</th>
            <th>Price</th>
            <th>Qty</th>
            <th style="text-align: right;">Total</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $item):
            $itemName   = (string) ($item['item_name'] ?? '');
            $itemMeta   = (string) ($item['item_meta'] ?? '');
            $unitPrice  = (int) ($item['unit_price'] ?? 0);
            $lineTotal  = (int) ($item['line_total'] ?? 0);
            $quantity   = (int) ($item['quantity'] ?? 1);
            $productImg = (string) ($item['product_image'] ?? '');
          ?>
            <tr>
              <td>
                <?php if ($productImg !== ''): ?>
                  <img src="../<?php echo htmlspecialchars($productImg); ?>" alt="" style="height: 48px; width: auto; max-width: 36px; object-fit: contain; background: #f7fafc; border: 1px solid var(--border); padding: 2px;">
                <?php else: ?>
                  <span style="font-size: 10px; color: var(--text-muted);">No img</span>
                <?php endif; ?>
              </td>
              <td>
                <strong><?php echo htmlspecialchars($itemName); ?></strong>
                <?php if ($itemMeta !== ''): ?>
                  <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars($itemMeta); ?></span>
                <?php endif; ?>
              </td>
              <td>Rs. <?php echo number_format($unitPrice); ?></td>
              <td><?php echo $quantity; ?></td>
              <td style="text-align: right;">Rs. <?php echo number_format($lineTotal); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <div style="margin-top: 24px; border-top: 1px solid var(--border); padding-top: 16px; display: flex; flex-direction: column; gap: 8px; font-size: 13px;">
        <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
          <span>Subtotal</span>
          <span>Rs. <?php echo number_format((int) ($order['subtotal'] ?? 0)); ?></span>
        </div>
        <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
          <span>Shipping</span>
          <span>Rs. <?php echo number_format((int) ($order['shipping'] ?? 0)); ?></span>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 16px; font-weight: 600; color: var(--text); margin-top: 8px; border-top: 1px solid var(--border); padding-top: 12px;">
          <span>Total</span>
          <span>Rs. <?php echo number_format((int) ($order['total'] ?? 0)); ?></span>
        </div>
      </div>
    </div>

    <!-- Customer Details -->
    <div class="content-card">
      <h2 style="font-size: 15px; font-weight: 500; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Customer & Delivery Details</h2>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; font-size: 13px; line-height: 1.6;">
        <div>
          <p style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 4px;">Full Name</p>
          <p style="font-weight: 500; margin-bottom: 16px;"><?php echo htmlspecialchars($order['customer_name']); ?></p>

          <p style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 4px;">Phone Number</p>
          <p style="font-weight: 500; margin-bottom: 16px;"><?php echo htmlspecialchars($order['customer_phone']); ?></p>

          <p style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 4px;">Email Address</p>
          <p style="font-weight: 500;"><?php echo htmlspecialchars($order['customer_email'] !== '' ? $order['customer_email'] : 'Not provided'); ?></p>
        </div>
        <div>
          <p style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 4px;">Delivery Address</p>
          <p style="font-weight: 500; margin-bottom: 16px;"><?php echo htmlspecialchars($order['customer_address']); ?></p>

          <p style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 4px;">City / Province</p>
          <p style="font-weight: 500; margin-bottom: 16px;"><?php echo htmlspecialchars($order['customer_city'] . ', ' . $order['customer_province']); ?></p>

          <p style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 4px;">Customer Notes</p>
          <p style="font-weight: 500;"><?php echo htmlspecialchars(!empty($order['customer_notes']) ? $order['customer_notes'] : 'None'); ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Status Management Form -->
  <div>
    <div class="content-card">
      <h2 style="font-size: 15px; font-weight: 500; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 20px;">Order Status</h2>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">
        <div class="form-group">
          <label for="order_status">Order Status</label>
          <select id="order_status" name="order_status">
            <?php foreach (['Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'] as $st): ?>
              <option value="<?php echo $st; ?>" <?php echo $order['order_status'] === $st ? 'selected' : ''; ?>><?php echo $st; ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="payment_status">Payment Status</label>
          <select id="payment_status" name="payment_status">
            <?php foreach (['Pending', 'Paid', 'Failed', 'Refunded'] as $pst): ?>
              <option value="<?php echo $pst; ?>" <?php echo $order['payment_status'] === $pst ? 'selected' : ''; ?>><?php echo $pst; ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div style="margin-top: 24px;">
          <button type="submit" class="btn" style="width: 100%;">Update Status</button>
        </div>
      </form>
    </div>

    <div class="content-card" style="margin-top: 20px;">
      <h2 style="font-size: 15px; font-weight: 500; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 16px;">Payment Method</h2>
      <p style="font-size: 13px; color: var(--text); font-weight: 500; margin-bottom: 6px;"><?php echo htmlspecialchars($order['payment_method']); ?></p>
      <p style="font-size: 12px; color: var(--text-muted);">Advance payment verified against bank account.</p>
    </div>
  </div>

</div>


<!-- ========================================================
     PRINTABLE A5 SHIPPING LABEL (Pure Black & White)
========================================================= -->
<div class="a5-shipping-label">
  <div class="a5-header">
    <div class="a5-brand">VERDEUR</div>
    <div class="a5-title">DISPATCH / SHIPPING LABEL</div>
  </div>

  <div class="a5-meta-grid">
    <div>
      <span class="a5-label">Order Number:</span>
      <span class="a5-val" style="font-size: 15px; font-weight: bold;"><?php echo htmlspecialchars($order['order_number']); ?></span>
    </div>
    <div>
      <span class="a5-label">Date:</span>
      <span class="a5-val"><?php echo date('d M Y, H:i', strtotime($order['created_at'])); ?></span>
    </div>
  </div>

  <div class="a5-box">
    <div class="a5-box-title">DELIVER TO (CONSIGNEE):</div>
    <div class="a5-val" style="font-size: 14px; font-weight: bold; margin-bottom: 4px;"><?php echo htmlspecialchars($order['customer_name']); ?></div>
    <div class="a5-val" style="margin-bottom: 4px;">Phone: <?php echo htmlspecialchars($order['customer_phone']); ?></div>
    <div class="a5-val" style="margin-bottom: 4px;">Address: <?php echo htmlspecialchars($order['customer_address']); ?></div>
    <div class="a5-val">City: <strong><?php echo htmlspecialchars($order['customer_city']); ?></strong> (<?php echo htmlspecialchars($order['customer_province']); ?>)</div>
    <?php if (!empty($order['customer_notes'])): ?>
      <div style="margin-top: 8px; font-size: 11px; border-top: 1px dashed #000; padding-top: 4px;">
        <strong>Notes:</strong> <?php echo htmlspecialchars($order['customer_notes']); ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="a5-box">
    <div class="a5-box-title">SENDER:</div>
    <div class="a5-val"><strong>Verdeur Independent Fragrance House</strong><br>Pakistan</div>
  </div>

  <div class="a5-box">
    <div class="a5-box-title">ORDER SUMMARY:</div>
    <table class="a5-table">
      <thead>
        <tr>
          <th>Item</th>
          <th style="text-align: center;">Qty</th>
          <th style="text-align: right;">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
          <tr>
            <td><?php echo htmlspecialchars($item['item_name']); ?> <?php echo $item['item_meta'] !== '' ? '(' . htmlspecialchars($item['item_meta']) . ')' : ''; ?></td>
            <td style="text-align: center;"><?php echo (int) $item['quantity']; ?></td>
            <td style="text-align: right;">Rs. <?php echo number_format((int) ($item['line_total'] ?? 0)); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="a5-footer-grid">
    <div>
      <span class="a5-label">Payment Mode:</span>
      <strong><?php echo htmlspecialchars($order['payment_method']); ?> (<?php echo htmlspecialchars($order['payment_status']); ?>)</strong>
    </div>
    <div style="text-align: right;">
      <span class="a5-label">Total Amount:</span>
      <strong style="font-size: 15px;">Rs. <?php echo number_format((int) ($order['total'] ?? 0)); ?></strong>
    </div>
  </div>

  <div style="margin-top: 20px; text-align: center; font-size: 10px; border-top: 1px solid #000; padding-top: 8px;">
    Verdeur Fragrance House — The Silent Conversation
  </div>
</div>

<style>
/* Hide label by default on screen */
.a5-shipping-label {
  display: none;
}

@media print {
  body {
    background: #ffffff !important;
    color: #000000 !important;
  }
  .no-print, .admin-sidebar, .admin-header {
    display: none !important;
  }
  .admin-main {
    margin: 0 !important;
    padding: 0 !important;
    max-width: 100% !important;
  }
  .a5-shipping-label {
    display: block !important;
    width: 148mm;
    min-height: 200mm;
    margin: 0 auto;
    background: #ffffff;
    color: #000000;
    font-family: 'Figtree', Arial, sans-serif;
    font-size: 12px;
    line-height: 1.4;
    padding: 10mm;
    box-sizing: border-box;
  }
  @page {
    size: A5 portrait;
    margin: 0;
  }
}

.a5-shipping-label {
  border: 2px solid #000;
  background: #fff;
  color: #000;
  padding: 20px;
  max-width: 550px;
  margin: 40px auto;
  font-family: 'Figtree', Arial, sans-serif;
}
.a5-header {
  border-bottom: 2px solid #000;
  padding-bottom: 10px;
  margin-bottom: 15px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.a5-brand {
  font-size: 18px;
  font-weight: bold;
  letter-spacing: 0.15em;
}
.a5-title {
  font-size: 11px;
  font-weight: bold;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  border: 1px solid #000;
  padding: 4px 8px;
}
.a5-meta-grid {
  display: flex;
  justify-content: space-between;
  margin-bottom: 15px;
  font-size: 12px;
  border-bottom: 1px solid #000;
  padding-bottom: 10px;
}
.a5-box {
  border: 1px solid #000;
  padding: 12px;
  margin-bottom: 15px;
}
.a5-box-title {
  font-size: 10px;
  font-weight: bold;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  margin-bottom: 6px;
  border-bottom: 1px solid #000;
  padding-bottom: 3px;
}
.a5-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 11px;
  margin-top: 5px;
}
.a5-table th, .a5-table td {
  border: 1px solid #000;
  padding: 6px 8px;
  text-align: left;
}
.a5-table th {
  background: #eee;
}
.a5-footer-grid {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-top: 2px solid #000;
  padding-top: 10px;
  font-size: 12px;
}
</style>

<?php
include(__DIR__ . '/includes/footer.php');
?>
