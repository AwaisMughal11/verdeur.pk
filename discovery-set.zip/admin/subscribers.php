<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$pageTitle = 'Subscribers — Verdeur Admin';
include(__DIR__ . '/includes/header.php');

try {
  $pdo = verdeur_db();
  $subscribers = $pdo->query('SELECT * FROM newsletter_subscribers ORDER BY created_at DESC')->fetchAll();
} catch (Throwable $e) {
  $subscribers = [];
}
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Newsletter Subscribers</h1>
    <p>List of all email subscribers</p>
  </div>
</div>

<div class="content-card">
  <?php if (count($subscribers) === 0): ?>
    <p style="color: var(--text-muted); font-size: 13px;">No subscribers found.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Email Address</th>
          <th>Subscribed Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($subscribers as $index => $sub): ?>
          <tr>
            <td><?php echo $index + 1; ?></td>
            <td><strong><?php echo htmlspecialchars($sub['email']); ?></strong></td>
            <td style="font-size: 12px; color: var(--text-muted);"><?php echo date('d M Y, H:i', strtotime($sub['created_at'])); ?></td>
            <td><span class="badge badge-delivered">Active</span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
