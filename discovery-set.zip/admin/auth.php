<?php

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

function verdeur_ensure_admin_table(): void {
  try {
    $pdo = verdeur_db();
    $pdo->exec(<<<SQL
      CREATE TABLE IF NOT EXISTS `admins` (
        `admin_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `username` VARCHAR(60) NOT NULL,
        `password_hash` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`admin_id`),
        UNIQUE KEY `uq_admin_username` (`username`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    SQL);

    /* Default credentials: verdeur / verdeur@785# */
    $user = 'verdeur';
    $pass = 'verdeur@785#';

    $stmt = $pdo->prepare('SELECT admin_id FROM admins WHERE username = ?');
    $stmt->execute([$user]);
    if (!$stmt->fetch()) {
      // If a legacy "admin" account exists, migrate it to the new username first.
      $legacy = $pdo->prepare('SELECT admin_id FROM admins WHERE username = ?');
      $legacy->execute(['admin']);
      $legacyRow = $legacy->fetch();
      if ($legacyRow) {
        $upd = $pdo->prepare('UPDATE admins SET username = ?, password_hash = ? WHERE admin_id = ?');
        $upd->execute([$user, password_hash($pass, PASSWORD_DEFAULT), $legacyRow['admin_id']]);
      } else {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $ins = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)');
        $ins->execute([$user, $hash]);
      }
    }
  } catch (Throwable $e) {
    // ignore or handle
  }
}

verdeur_ensure_admin_table();

function admin_is_logged_in(): bool {
  return isset($_SESSION['verdeur_admin_id']) && !empty($_SESSION['verdeur_admin_id']);
}

function admin_require_login(): void {
  if (!admin_is_logged_in()) {
    header('Location: login.php');
    exit;
  }

  /* Session inactivity timeout (30 minutes) */
  $lastActivity = (int) ($_SESSION['verdeur_admin_last_activity'] ?? 0);
  if ($lastActivity > 0 && (time() - $lastActivity) > 30 * 60) {
    admin_logout();
    header('Location: login.php');
    exit;
  }
  $_SESSION['verdeur_admin_last_activity'] = time();
}

function admin_login(string $username, string $password): bool {
  $username = trim($username);
  if ($username === '' || $password === '') {
    return false;
  }

  try {
    $pdo = verdeur_db();
    $stmt = $pdo->prepare('SELECT * FROM admins WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password_hash'])) {
      session_regenerate_id(true);
      $_SESSION['verdeur_admin_id'] = (int) $admin['admin_id'];
      $_SESSION['verdeur_admin_username'] = $admin['username'];
      $_SESSION['verdeur_admin_last_activity'] = time();
      return true;
    }
  } catch (Throwable $e) {
    return false;
  }

  return false;
}

function admin_logout(): void {
  unset($_SESSION['verdeur_admin_id'], $_SESSION['verdeur_admin_username']);
  session_destroy();
}

function admin_csrf_token(): string {
  if (empty($_SESSION['verdeur_csrf_token'])) {
    $_SESSION['verdeur_csrf_token'] = bin2hex(random_bytes(32));
  }
  return $_SESSION['verdeur_csrf_token'];
}

function admin_verify_csrf(?string $token): bool {
  return isset($_SESSION['verdeur_csrf_token']) && hash_equals($_SESSION['verdeur_csrf_token'], (string) $token);
}
