<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

if (admin_is_logged_in()) {
  header('Location: index.php');
  exit;
}

$error = '';

/* Brute-force protection: 5 failed attempts -> 10 minute lockout */
$lockKey   = 'verdeur_login_attempts';
$lockUntil = 'verdeur_login_locked_until';

if (isset($_SESSION[$lockUntil]) && time() < (int) $_SESSION[$lockUntil]) {
  $error = 'Too many failed attempts. Try again after a short wait.';
} elseif (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
  $username = trim((string) ($_POST['username'] ?? ''));
  $password = trim((string) ($_POST['password'] ?? ''));

  if (admin_login($username, $password)) {
    unset($_SESSION[$lockKey], $_SESSION[$lockUntil]);
    header('Location: index.php');
    exit;
  } else {
    $_SESSION[$lockKey] = (int) ($_SESSION[$lockKey] ?? 0) + 1;
    if ($_SESSION[$lockKey] >= 5) {
      $_SESSION[$lockUntil] = time() + (10 * 60);
      unset($_SESSION[$lockKey]);
      $error = 'Too many failed attempts. Login locked for 10 minutes.';
    } else {
      $remaining = 5 - (int) ($_SESSION[$lockKey] ?? 0);
      $error = 'Invalid username or password. ' . $remaining . ' attempt(s) remaining.';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login — Verdeur</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@300;400;500;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #f4f5f7;
      --card-bg: #ffffff;
      --border: #e2e8f0;
      --text: #1a202c;
      --text-muted: #718096;
      --accent: #111111;
      --error: #e53e3e;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: 'Figtree', sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-box {
      width: 100%;
      max-width: 400px;
      padding: 40px;
      background: var(--card-bg);
      border: 1px solid var(--border);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
    }
    .login-header {
      text-align: center;
      margin-bottom: 32px;
    }
    .login-header h1 {
      font-size: 22px;
      font-weight: 600;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      margin-bottom: 8px;
      color: #111;
    }
    .login-header p {
      font-size: 12px;
      color: var(--text-muted);
      letter-spacing: 0.1em;
      text-transform: uppercase;
    }
    .error-msg {
      background: rgba(229, 62, 62, 0.1);
      border: 1px solid rgba(229, 62, 62, 0.3);
      color: var(--error);
      padding: 12px 16px;
      font-size: 13px;
      margin-bottom: 24px;
      text-align: center;
    }
    .form-field {
      margin-bottom: 20px;
    }
    label {
      display: block;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--text-muted);
      margin-bottom: 8px;
    }
    input {
      width: 100%;
      background: #fafbfc;
      border: 1px solid var(--border);
      color: var(--text);
      padding: 14px 16px;
      font-family: inherit;
      font-size: 14px;
      outline: none;
      transition: border-color 200ms ease;
    }
    input:focus {
      border-color: var(--accent);
      background: #ffffff;
    }
    .login-btn {
      width: 100%;
      background: #111111;
      color: #ffffff;
      border: none;
      padding: 15px;
      font-family: inherit;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      cursor: pointer;
      margin-top: 10px;
      transition: opacity 200ms ease;
    }
    .login-btn:hover {
      opacity: 0.85;
    }
    .hint {
      margin-top: 20px;
      text-align: center;
      font-size: 12px;
      color: var(--text-muted);
    }
  </style>
</head>
<body>

  <div class="login-box">
    <div class="login-header">
      <h1>Verdeur</h1>
      <p>Admin Portal</p>
    </div>

    <?php if ($error !== ''): ?>
      <div class="error-msg"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-field">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required autofocus value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
      </div>

      <div class="form-field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
      </div>

      <button type="submit" class="login-btn">Sign In</button>
    </form>

    <div class="hint">
      Secured admin portal. Contact the administrator for access.
    </div>
  </div>

</body>
</html>
