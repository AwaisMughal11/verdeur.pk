<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/includes/analytics-helpers.php';

$pageTitle = 'Dashboard — Verdeur Admin';
include(__DIR__ . '/includes/header.php');

$stats = [
  'orders_total' => 0,
  'orders_pending' => 0,
  'revenue' => 0,
  'products' => 0,
  'queries' => 0,
  'subscribers' => 0,
];
$recentOrders   = [];
$statusBreakdown= [];
$paymentBreakdown = [];
$trend30        = []; // revenue trend
$trend30Count   = []; // daily order count
$topProducts    = [];
$topCities      = [];
$kpi            = ['rev_this' => 0, 'rev_last' => 0, 'ord_this' => 0, 'ord_last' => 0, 'aov_this' => 0, 'pending' => 0];

try {
  $pdo = verdeur_db();

  /* Original headline cards */
  $stats['orders_total']      = (int) $pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
  $stats['orders_pending']    = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE order_status = 'Pending'")->fetchColumn();
  $stats['revenue']           = (int) $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE order_status != 'Cancelled'")->fetchColumn();
  $stats['products']          = (int) $pdo->query('SELECT COUNT(*) FROM products WHERE is_active = 1')->fetchColumn();
  $stats['queries']           = (int) $pdo->query('SELECT COUNT(*) FROM customer_queries WHERE is_read = 0')->fetchColumn();
  $stats['subscribers']       = (int) $pdo->query('SELECT COUNT(*) FROM newsletter_subscribers WHERE is_active = 1')->fetchColumn();

  /* KPI — this month vs last month */
  $thisMonth = date('Y-m');
  $lastMonth = date('Y-m', strtotime('first day of last month'));
  $kpi['rev_this']   = (int) $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE order_status != 'Cancelled' AND DATE_FORMAT(created_at,'%Y-%m') = '$thisMonth'")->fetchColumn();
  $kpi['rev_last']   = (int) $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE order_status != 'Cancelled' AND DATE_FORMAT(created_at,'%Y-%m') = '$lastMonth'")->fetchColumn();
  $kpi['ord_this']   = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE DATE_FORMAT(created_at,'%Y-%m') = '$thisMonth'")->fetchColumn();
  $kpi['ord_last']   = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE DATE_FORMAT(created_at,'%Y-%m') = '$lastMonth'")->fetchColumn();
  $nonCancelledThis = (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE order_status != 'Cancelled' AND DATE_FORMAT(created_at,'%Y-%m') = '$thisMonth'")->fetchColumn();
  $kpi['aov_this']   = $nonCancelledThis > 0 ? (int) round($kpi['rev_this'] / $nonCancelledThis) : 0;
  $kpi['pending']    = $stats['orders_pending'];

  /* Order status & payment breakdown */
  foreach ($pdo->query("SELECT order_status, COUNT(*) c FROM orders GROUP BY order_status") as $r) {
    $statusBreakdown[$r['order_status']] = (int) $r['c'];
  }
  foreach ($pdo->query("SELECT payment_status, COUNT(*) c FROM orders WHERE order_status != 'Cancelled' GROUP BY payment_status") as $r) {
    $paymentBreakdown[$r['payment_status']] = (int) $r['c'];
  }

  /* Revenue trend — last 30 days (excl cancelled) */
  $from30 = date('Y-m-d', strtotime('-29 days'));
  $today  = date('Y-m-d');
  $trend30 = vr_analytics_daily($pdo, $from30, $today, 'COALESCE(SUM(total),0)', "order_status != 'Cancelled'");
  $trend30Count = vr_analytics_daily($pdo, $from30, $today);

  /* Top 5 products by quantity sold (all time) */
  $topProducts = $pdo->query(
    'SELECT i.item_name label, SUM(i.quantity) qty, SUM(i.line_total) rev
     FROM order_items i
     GROUP BY i.item_name
     ORDER BY qty DESC
     LIMIT 5'
  )->fetchAll();

  /* Top cities by order count */
  $topCities = $pdo->query(
    'SELECT customer_city label, COUNT(*) c
     FROM orders
     WHERE customer_city <> ""
     GROUP BY customer_city
     ORDER BY c DESC
     LIMIT 5'
  )->fetchAll();

  $recentOrders = $pdo->query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 8')->fetchAll();

} catch (Throwable $e) {
  // handle exception silently
}

/* Build rows for hbar charts */
$statusRows = [];
foreach ($statusBreakdown as $label => $n) {
  $statusRows[] = [$label, $n];
}
usort($statusRows, fn ($a, $b) => $b[1] <=> $a[1]);

$cityRows = [];
foreach ($topCities as $row) {
  $cityRows[] = [$row['label'], (int) $row['c']];
}

$productRows = [];
foreach ($topProducts as $row) {
  $productRows[] = [$row['label'], (int) $row['qty'], 'Rs. ' . number_format((int) $row['rev'])];
}

/* 30-day charts */
$trendLabels = [];
$trendValues = [];
foreach ($trend30 as $pair) { $trendLabels[] = $pair[0]; $trendValues[] = (int) $pair[1]; }
$countValues = [];
foreach ($trend30Count as $pair) { $countValues[] = (int) $pair[1]; }

function vr_pct_delta(int $cur, int $prev): string {
  if ($prev <= 0) { return 'new'; }
  $d = round(100 * ($cur - $prev) / $prev);
  return ($d >= 0 ? '+' : '') . $d . '%';
}
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Dashboard</h1>
    <p>Welcome back, <?php echo htmlspecialchars($_SESSION['verdeur_admin_username'] ?? 'Admin'); ?></p>
  </div>
  <div class="admin-header-actions" style="display:flex; gap:10px;">
    <a href="analytics.php" class="btn btn-outline">Detailed Analytics</a>
    <a href="orders.php" class="btn">View All Orders</a>
  </div>
</div>

<style>
  .analytics-grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px; margin-top:20px; }
  .analytics-card { background:var(--card-bg); border:1px solid var(--border); padding:20px 24px; }
  .analytics-card h3 { font-size:12px; font-weight:600; letter-spacing:.08em; text-transform:uppercase; color:var(--text-muted); margin-bottom:14px; }
  .kpi-sub { font-size:11px; color:var(--text-muted); margin-top:6px; }
  .kpi-up { color:#27ae60; font-weight:600; }
  .kpi-down { color:#e53e3e; font-weight:600; }
  .kpi-flat { color:var(--text-muted); }
  .insight-box { background:#fbf6ea; border:1px solid #f0e3bd; border-radius:6px; padding:14px 16px; margin-top:20px; }
  .insight-box li { font-size:13px; line-height:1.6; color:var(--text); margin-left:16px; }
</style>

<div class="stats-grid">
  <div class="stat-card">
    <h3>Revenue (this month)</h3>
    <div class="value" style="font-size:24px;">Rs. <?php echo number_format($kpi['rev_this']); ?></div>
    <div class="kpi-sub">vs last month <span class="<?php echo $kpi['rev_this'] >= $kpi['rev_last'] ? 'kpi-up' : 'kpi-down'; ?>"><?php echo vr_pct_delta($kpi['rev_this'], $kpi['rev_last']); ?></span></div>
  </div>
  <div class="stat-card">
    <h3>Orders (this month)</h3>
    <div class="value" style="font-size:24px;"><?php echo number_format($kpi['ord_this']); ?></div>
    <div class="kpi-sub">vs last month <span class="<?php echo $kpi['ord_this'] >= $kpi['ord_last'] ? 'kpi-up' : 'kpi-down'; ?>"><?php echo vr_pct_delta($kpi['ord_this'], $kpi['ord_last']); ?></span></div>
  </div>
  <div class="stat-card">
    <h3>Avg Order Value</h3>
    <div class="value" style="font-size:24px; color:#8e44ad;">Rs. <?php echo number_format($kpi['aov_this']); ?></div>
    <div class="kpi-sub">this month (non-cancelled)</div>
  </div>
  <div class="stat-card">
    <h3>Lifetime Revenue</h3>
    <div class="value" style="font-size:24px;">Rs. <?php echo number_format($stats['revenue']); ?></div>
    <div class="kpi-sub"><?php echo number_format($stats['orders_total']); ?> orders</div>
  </div>
</div>

<div class="stats-grid">
  <div class="stat-card">
    <h3>Total Orders</h3>
    <div class="value"><?php echo number_format($stats['orders_total']); ?></div>
  </div>
  <div class="stat-card">
    <h3>Pending Orders</h3>
    <div class="value" style="color: #f39c12;"><?php echo number_format($stats['orders_pending']); ?></div>
  </div>
  <div class="stat-card">
    <h3>Active Products</h3>
    <div class="value"><?php echo number_format($stats['products']); ?></div>
  </div>
  <div class="stat-card">
    <h3>Unread Queries</h3>
    <div class="value" style="color: #3498db;"><?php echo number_format($stats['queries']); ?></div>
  </div>
  <div class="stat-card">
    <h3>Subscribers</h3>
    <div class="value"><?php echo number_format($stats['subscribers']); ?></div>
  </div>
</div>

<div class="content-card" style="margin-top:20px;">
  <div class="card-header-flex">
    <h2>Recent Orders</h2>
    <a href="orders.php" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">View All</a>
  </div>

  <?php if (count($recentOrders) === 0): ?>
    <p style="color: var(--text-muted); font-size: 13px;">No orders received yet.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Order #</th>
          <th>Customer</th>
          <th>City</th>
          <th>Total</th>
          <th>Status</th>
          <th>Date</th>
          <th style="text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($recentOrders as $order): 
          $statusClass = 'badge-' . strtolower((string) ($order['order_status'] ?? ''));
          $orderDate   = (string) ($order['created_at'] ?? '');
        ?>
          <tr>
            <td><strong><?php echo htmlspecialchars((string) ($order['order_number'] ?? '')); ?></strong></td>
            <td><?php echo htmlspecialchars((string) ($order['customer_name'] ?? '')); ?><br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars((string) ($order['customer_phone'] ?? '')); ?></span></td>
            <td><?php echo htmlspecialchars((string) ($order['customer_city'] ?? '')); ?></td>
            <td>Rs. <?php echo number_format((int) ($order['total'] ?? 0)); ?></td>
            <td><span class="badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars((string) ($order['order_status'] ?? '')); ?></span></td>
            <td style="font-size: 12px; color: var(--text-muted);"><?php echo $orderDate !== '' ? date('d M Y, H:i', strtotime($orderDate)) : '—'; ?></td>
            <td style="text-align: right;">
              <a href="order-detail.php?id=<?php echo (int) ($order['order_id'] ?? 0); ?>" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">Details</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
