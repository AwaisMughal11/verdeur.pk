<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$flash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
    $flash = 'Security validation failed (CSRF token invalid).';
  } else {
    $id = (int) ($_POST['query_id'] ?? 0);
    $action = (string) ($_POST['action'] ?? '');
    try {
      $pdo = verdeur_db();
      if ($id > 0 && $action === 'mark_read') {
        $pdo->prepare('UPDATE customer_queries SET is_read = 1 WHERE query_id = ?')->execute([$id]);
        $flash = 'Inquiry marked as read.';
      } elseif ($id > 0 && $action === 'delete') {
        $pdo->prepare('DELETE FROM customer_queries WHERE query_id = ?')->execute([$id]);
        $flash = 'Inquiry deleted.';
      }
    } catch (Throwable $e) {
      $flash = 'Something went wrong.';
    }
  }
  header('Location: queries.php?msg=' . urlencode($flash));
  exit;
}

$pageTitle = 'Contact Inquiries — Verdeur Admin';
include(__DIR__ . '/includes/header.php');

$queries = [];
try {
  $queries = verdeur_db()->query('SELECT * FROM customer_queries ORDER BY created_at DESC')->fetchAll();
} catch (Throwable $e) {
  $queries = [];
}
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Contact Inquiries</h1>
    <p>Customer messages from contact page</p>
  </div>
</div>

<?php if (isset($_GET['msg']) && $_GET['msg'] !== ''): ?>
  <div class="content-card" style="padding: 16px 24px; margin-bottom: 20px; color: var(--text);">
    <?php echo htmlspecialchars(trim((string) $_GET['msg'])); ?>
  </div>
<?php endif; ?>

<div class="content-card">
  <?php if (count($queries) === 0): ?>
    <p style="color: var(--text-muted); font-size: 13px;">No customer inquiries received yet.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Customer</th>
          <th>Subject</th>
          <th>Message</th>
          <th>Date</th>
          <th>Status</th>
          <th style="text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($queries as $q): ?>
          <tr style="<?php echo !$q['is_read'] ? 'background: rgba(0,0,0,0.02); font-weight: 500;' : ''; ?>">
            <td>
              <?php echo htmlspecialchars($q['name']); ?>
              <br><span style="font-size: 11px; color: var(--text-muted); font-weight: 400;"><?php echo htmlspecialchars($q['email']); ?></span>
            </td>
            <td><?php echo htmlspecialchars($q['subject'] !== '' ? $q['subject'] : 'General Inquiry'); ?></td>
            <td style="max-width: 320px; white-space: pre-wrap; font-size: 12px; color: var(--text-muted);"><?php echo htmlspecialchars($q['message']); ?></td>
            <td style="font-size: 12px; color: var(--text-muted);"><?php echo date('d M Y, H:i', strtotime($q['created_at'])); ?></td>
            <td>
              <?php if ($q['is_read']): ?>
                <span class="badge" style="color: var(--text-muted);">Read</span>
              <?php else: ?>
                <span class="badge badge-pending">Unread</span>
              <?php endif; ?>
            </td>
            <td style="text-align: right;">
              <form method="POST" style="display: inline-flex; gap: 6px; align-items: center;">
                <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">
                <input type="hidden" name="query_id" value="<?php echo $q['query_id']; ?>">
                <?php if (!$q['is_read']): ?>
                  <button type="submit" name="action" value="mark_read" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px;">Mark Read</button>
                <?php else: ?>
                  <span style="color: var(--text-muted); font-size: 11px;">Read</span>
                <?php endif; ?>
                <button type="submit" name="action" value="delete" class="btn btn-outline" style="padding: 6px 12px; font-size: 10px; color: #e53e3e;">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
