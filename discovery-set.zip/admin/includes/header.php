<?php
declare(strict_types=1);
require_once __DIR__ . '/../auth.php';
admin_require_login();

$currentPage = basename($_SERVER['PHP_SELF']);
$adminUser = $_SESSION['verdeur_admin_username'] ?? 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($pageTitle) ? $pageTitle : 'Admin — Verdeur'; ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@300;400;500;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #f4f5f7;
      --card: #ffffff;
      --border: #e2e8f0;
      --border-light: #edf2f7;
      --text: #1a202c;
      --text-muted: #718096;
      --accent: #111111;
      --sidebar-width: 260px;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: 'Figtree', sans-serif;
      background: var(--bg);
      color: var(--text);
      display: flex;
      min-height: 100vh;
    }
    /* Sidebar */
    .admin-sidebar {
      width: var(--sidebar-width);
      background: #ffffff;
      border-right: 1px solid var(--border);
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      display: flex;
      flex-direction: column;
      z-index: 100;
    }
    .sidebar-brand {
      padding: 28px 24px;
      border-bottom: 1px solid var(--border);
    }
    .sidebar-brand h2 {
      font-size: 16px;
      font-weight: 600;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      color: #111;
    }
    .sidebar-brand span {
      display: block;
      font-size: 11px;
      color: var(--text-muted);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-top: 4px;
    }
    .sidebar-nav {
      flex: 1;
      padding: 24px 0;
      overflow-y: auto;
    }
    .nav-section-title {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      color: var(--text-muted);
      padding: 0 24px 10px;
    }
    .sidebar-link {
      display: flex;
      align-items: center;
      padding: 12px 24px;
      color: var(--text-muted);
      text-decoration: none;
      font-size: 13px;
      font-weight: 500;
      letter-spacing: 0.04em;
      transition: all 200ms ease;
      border-left: 2px solid transparent;
    }
    .sidebar-link:hover,
    .sidebar-link.active {
      color: #111111;
      background: #f7fafc;
      border-left-color: #111111;
    }
    .sidebar-footer {
      padding: 20px 24px;
      border-top: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: #fafbfc;
    }
    .admin-user {
      font-size: 13px;
      color: var(--text);
      font-weight: 500;
    }
    .logout-btn {
      color: var(--text-muted);
      text-decoration: none;
      font-size: 12px;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      transition: color 200ms ease;
    }
    .logout-btn:hover {
      color: #e53e3e;
    }
    /* Main Content */
    .admin-main {
      margin-left: var(--sidebar-width);
      flex: 1;
      padding: 40px;
      max-width: calc(100% - var(--sidebar-width));
    }
    .admin-header {
      margin-bottom: 36px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .admin-title h1 {
      font-size: 24px;
      font-weight: 500;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: #111;
    }
    .admin-title p {
      font-size: 13px;
      color: var(--text-muted);
      margin-top: 4px;
    }
    /* Cards & Tables */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin-bottom: 36px;
    }
    .stat-card {
      background: var(--card);
      border: 1px solid var(--border);
      padding: 24px;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.02);
    }
    .stat-card h3 {
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--text-muted);
      margin-bottom: 12px;
    }
    .stat-card .value {
      font-size: 28px;
      font-weight: 500;
      letter-spacing: 0.02em;
      color: #111;
    }
    .content-card {
      background: var(--card);
      border: 1px solid var(--border);
      padding: 28px;
      margin-bottom: 30px;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.02);
    }
    .card-header-flex {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 24px;
    }
    .card-header-flex h2 {
      font-size: 15px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: #111;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 13px;
    }
    th {
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--text-muted);
      padding: 12px 16px;
      border-bottom: 1px solid var(--border);
      background: #fafbfc;
    }
    td {
      padding: 16px;
      border-bottom: 1px solid var(--border);
      color: var(--text);
    }
    tr:last-child td {
      border-bottom: none;
    }
    .badge {
      display: inline-block;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      border: 1px solid var(--border);
    }
    .badge-pending { color: #d69e2e; border-color: rgba(214, 158, 46, 0.3); background: rgba(214, 158, 46, 0.08); }
    .badge-confirmed { color: #3182ce; border-color: rgba(49, 130, 206, 0.3); background: rgba(49, 130, 206, 0.08); }
    .badge-shipped { color: #805ad5; border-color: rgba(128, 90, 213, 0.3); background: rgba(128, 90, 213, 0.08); }
    .badge-delivered { color: #38a169; border-color: rgba(56, 161, 105, 0.3); background: rgba(56, 161, 105, 0.08); }
    .badge-cancelled { color: #e53e3e; border-color: rgba(229, 62, 62, 0.3); background: rgba(229, 62, 62, 0.08); }
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: #111111;
      color: #ffffff;
      padding: 10px 18px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      text-decoration: none;
      border: none;
      cursor: pointer;
      transition: opacity 200s ease;
    }
    .btn:hover {
      opacity: 0.85;
    }
    .btn-outline {
      background: transparent;
      color: #111;
      border: 1px solid var(--border);
    }
    .btn-outline:hover {
      border-color: #111;
      background: #fafbfc;
    }
    .form-row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 20px;
    }
    .form-group {
      margin-bottom: 20px;
    }
    .form-group label {
      display: block;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--text-muted);
      margin-bottom: 8px;
    }
    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      background: #fafbfc;
      border: 1px solid var(--border);
      color: var(--text);
      padding: 12px 16px;
      font-family: inherit;
      font-size: 13px;
      outline: none;
    }
    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      border-color: #111;
      background: #ffffff;
    }
    .form-group textarea {
      min-height: 120px;
      resize: vertical;
    }
  </style>
</head>
<body>

  <aside class="admin-sidebar">
    <div class="sidebar-brand">
      <h2>Verdeur</h2>
      <span>Admin Portal</span>
    </div>

    <nav class="sidebar-nav">
      <a href="index.php" class="sidebar-link <?php echo $currentPage === 'index.php' ? 'active' : ''; ?>">Dashboard</a>
      <a href="orders.php" class="sidebar-link <?php echo in_array($currentPage, ['orders.php', 'order-detail.php']) ? 'active' : ''; ?>">Orders</a>
      <a href="analytics.php" class="sidebar-link <?php echo $currentPage === 'analytics.php' ? 'active' : ''; ?>">Analytics & Insights</a>
      <a href="products.php" class="sidebar-link <?php echo in_array($currentPage, ['products.php', 'product-form.php', 'sort-products.php']) ? 'active' : ''; ?>">Products</a>
      <a href="collections.php" class="sidebar-link <?php echo $currentPage === 'collections.php' ? 'active' : ''; ?>">Collections</a>
      <a href="testimonials.php" class="sidebar-link <?php echo $currentPage === 'testimonials.php' ? 'active' : ''; ?>">Testimonials</a>
      <a href="tester-boxes.php" class="sidebar-link <?php echo $currentPage === 'tester-boxes.php' ? 'active' : ''; ?>">Tester Boxes</a>
      <a href="queries.php" class="sidebar-link <?php echo $currentPage === 'queries.php' ? 'active' : ''; ?>">Contact Inquiries</a>
      <a href="subscribers.php" class="sidebar-link <?php echo $currentPage === 'subscribers.php' ? 'active' : ''; ?>">Subscribers</a>
      <a href="settings.php" class="sidebar-link <?php echo $currentPage === 'settings.php' ? 'active' : ''; ?>">Settings & Bank</a>
      <a href="../index.php" target="_blank" class="sidebar-link">View Live Site ↗</a>
    </nav>

    <div class="sidebar-footer">
      <span class="admin-user"><?php echo htmlspecialchars($adminUser); ?></span>
      <a href="logout.php" class="logout-btn">Logout</a>
    </div>
  </aside>

  <main class="admin-main">
