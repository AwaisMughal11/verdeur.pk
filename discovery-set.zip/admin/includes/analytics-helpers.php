<?php
/**
 * VERDEUR Admin — Analytics chart helpers (server-side SVG, no CDN)
 *
 * All helpers return a self-contained inline <svg> string that renders
 * correctly as a standalone element (embedded <style>, proper font-sets,
 * no overflowing labels, and sensible empty states).
 */

declare(strict_types=1);

if (!function_exists('vr_svg_style')) {
  /**
   * Shared <style> injected into every chart so SVG text uses the
   * same font stack and sizes as the rest of the admin UI.
   */
  function vr_svg_style(): string {
    return '<style>'
      . '.vr-t{font-family:Figtree,ui-sans-serif,system-ui,sans-serif;}'
      . '.vr-tick{font-size:11px;fill:#8a93a5;}'
      . '.vr-axis{font-size:11px;fill:#8a93a5;}'
      . '.vr-val{font-size:9.5px;fill:#6b7280;font-weight:600;}'
      . '.vr-cat{font-size:11px;fill:#1a202c;font-weight:600;}'
      . '</style>';
  }
}

if (!function_exists('vr_fmt_k')) {
  /** Compact number formatter (k / L / M). */
  function vr_fmt_k(int|float $v): string {
    $v = (int) round((float) $v);
    if ($v >= 10000000) { return number_format($v / 10000000, 1) . 'Cr'; }
    if ($v >= 1000000)  { return number_format($v / 1000000, 1) . 'M'; }
    if ($v >= 100000)   { return number_format($v / 100000, 1) . 'L'; }
    if ($v >= 1000)     { return number_format($v / 1000, 0) . 'k'; }
    return (string) $v;
  }
}

if (!function_exists('vr_svg_line')) {
  /**
   * Area + line chart for a time series (e.g. daily revenue).
   *
   * @param array $labels short display labels (optional, may be sparse)
   * @param array $values numeric series
   * @param array $opts  width, height, color, fill_mode
   */
  function vr_svg_line(array $labels, array $values, array $opts = []): string {
    $width  = (int) ($opts['width'] ?? 720);
    $height = (int) ($opts['height'] ?? 220);
    $padT   = 16;
    $padR   = 10;
    $padB   = 30;
    $padL   = 52;
    $color  = (string) ($opts['color'] ?? '#111111');
    $muted  = '#8a93a5';
    $grid   = '#eef1f5';
    $fill   = (bool) ($opts['fill'] ?? true);

    $n = count($values);
    if ($n === 0 || max($values) === 0) {
      return vr_empty_chart($width, $height, (string) ($opts['empty'] ?? 'No data for this period.'));
    }

    $plotW = $width - $padL - $padR;
    $plotH = $height - $padT - $padB;
    $max   = (float) max($values);
    $max   = $max > 0 ? $max * 1.1 : 1; // headroom
    $min   = 0;

    $stepX = $n > 1 ? ($plotW / ($n - 1)) : 0;
    $px = function (int $i) use ($padL, $stepX): float { return $padL + $i * $stepX; };
    $py = function (float $v) use ($padT, $plotH, $max, $min): float {
      return $padT + $plotH - (($v - $min) / ($max - $min)) * $plotH;
    };

    $out = '<svg viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Trend chart" style="width:100%;height:auto;display:block;max-width:700px;margin:0 auto;">' . vr_svg_style();

    // horizontal grid + y ticks (0, 25, 50, 75, 100%)
    $ticks = 4;
    for ($g = 0; $g <= $ticks; $g++) {
      $pct = $g / $ticks;
      $y   = $padT + $plotH - $pct * $plotH;
      $val = $min + ($max - $min) * $pct;
      $lineY = (float) round($y);
      $out .= '<line x1="' . $padL . '" y1="' . $lineY . '" x2="' . ($width - $padR) . '" y2="' . $lineY . '" stroke="' . $grid . '" stroke-width="1"/>';
      $out .= '<text class="vr-tick vr-t" x="' . ($padL - 8) . '" y="' . ($lineY + 4) . '" text-anchor="end">' . vr_fmt_k($val) . '</text>';
    }

    // baseline
    $baseY = (float) round($py(0));

    // build path for area + line
    $pts = [];
    foreach ($values as $i => $v) {
      $pts[] = round($px($i), 1) . ',' . round($py((float) $v), 1);
    }
    $line = implode(' ', $pts);

    if ($fill && count($pts) >= 2) {
      $area = 'M' . $padL . ',' . $baseY . ' L' . implode(' L', $pts) . ' L' . round($px($n - 1), 1) . ',' . $baseY . ' Z';
      $gid  = 'g' . substr(md5(uniqid('', true)), 0, 8);
      $out .= '<defs><linearGradient id="' . $gid . '" x1="0" y1="0" x2="0" y2="1">'
            . '<stop offset="0%" stop-color="' . $color . '" stop-opacity="0.18"/>'
            . '<stop offset="100%" stop-color="' . $color . '" stop-opacity="0.01"/>'
            . '</linearGradient></defs>';
      $out .= '<path d="' . $area . '" fill="url(#' . $gid . ')"/>';
    }

    // guideline line
    $out .= '<polyline points="' . $line . '" fill="none" stroke="' . $color . '" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>';

    // dots on each point
    foreach ($values as $i => $v) {
      $out .= '<circle cx="' . round($px($i), 1) . '" cy="' . round($py((float) $v), 1) . '" r="2.5" fill="' . $color . '"/>';
    }

    // x labels: thin to avoid overlap
    $labelStep = vr_label_step(count($labels), $plotW);
    foreach ($labels as $i => $lab) {
      if ($i % $labelStep !== 0) { continue; }
      $out .= '<text class="vr-tick vr-t" x="' . round($px($i), 1) . '" y="' . ($height - 8) . '" text-anchor="middle">' . htmlspecialchars((string) $lab) . '</text>';
    }

    $out .= '</svg>';
    return $out;
  }
}

if (!function_exists('vr_svg_bar')) {
  /**
   * Vertical bar chart with value labels, gridlines and auto-thinned
   * x-axis labels (no overlapping rotated text).
   */
  function vr_svg_bar(array $labels, array $values, array $opts = []): string {
    $width   = (int) ($opts['width'] ?? 720);
    $height  = (int) ($opts['height'] ?? 240);
    $padT    = 18;
    $padR    = 10;
    $padB    = 32;
    $padL    = 48;
    $barColor      = (string) ($opts['bar_color'] ?? '#111111');
    $highlightIdx  = (int) ($opts['highlight'] ?? -1);
    $highlightColor= (string) ($opts['highlight_color'] ?? '#c9a227');
    $muted   = '#8a93a5';
    $grid    = '#eef1f5';

    $n = count($values);
    if ($n === 0 || max($values) === 0) {
      return vr_empty_chart($width, $height, (string) ($opts['empty'] ?? 'No data for this period.'));
    }

    $max   = (float) max($values);
    $plotW = $width - $padL - $padR;
    $plotH = $height - $padT - $padB;
    $slot  = $plotW / $n;
    $barW  = max(4, $slot * 0.58);
    $out = '<svg viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Bar chart" style="width:100%;height:auto;display:block;max-width:700px;margin:0 auto;">' . vr_svg_style();

    // gridlines + y ticks
    $ticks = 4;
    for ($g = 0; $g <= $ticks; $g++) {
      $y = $padT + ($plotH * $g / $ticks);
      $val = (int) round($max - ($max * $g / $ticks));
      $lineY = (float) round($y);
      $out .= '<line x1="' . $padL . '" y1="' . $lineY . '" x2="' . ($width - $padR) . '" y2="' . $lineY . '" stroke="' . $grid . '" stroke-width="1"/>';
      $out .= '<text class="vr-tick vr-t" x="' . ($padL - 8) . '" y="' . ($lineY + 4) . '" text-anchor="end">' . vr_fmt_k($val) . '</text>';
    }

    foreach ($values as $i => $v) {
      $v    = (int) $v;
      $h    = $v > 0 ? max(2, round($plotH * $v / $max)) : 1;
      $x    = $padL + ($slot * $i) + ($slot - $barW) / 2;
      $y    = $padT + $plotH - $h;
      $fill = ($i === $highlightIdx) ? $highlightColor : $barColor;
      $out .= '<rect x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($barW, 1) . '" height="' . $h . '" rx="2" fill="' . $fill . '" opacity="0.9"/>';
      if ($v > 0) {
        $out .= '<text class="vr-val vr-t" x="' . round($x + $barW / 2, 1) . '" y="' . (round($y) - 5) . '" text-anchor="middle">' . vr_fmt_k($v) . '</text>';
      }
    }

    // x labels: auto-thin to avoid overlap
    $labelStep = vr_label_step(count($labels), $plotW);
    foreach ($labels as $i => $lab) {
      if (($i % $labelStep) !== 0) { continue; }
      $cx = $padL + ($slot * $i) + $slot / 2;
      $out .= '<text class="vr-tick vr-t" x="' . round($cx, 1) . '" y="' . ($height - 7) . '" text-anchor="middle">' . htmlspecialchars((string) $lab) . '</text>';
    }

    $out .= '</svg>';
    return $out;
  }
}

if (!function_exists('vr_svg_hbar')) {
  /**
   * Horizontal bar chart for categorical top-lists (products, cities,
   * status, payment). Bar lengths proportional to the max; value +
   * percentage shown after each bar, clamped to the viewport.
   */
  function vr_svg_hbar(array $rows, array $opts = []): string {
    $width     = (int) ($opts['width'] ?? 720);
    $barH      = (int) ($opts['bar_height'] ?? 24);
    $gap       = (int) ($opts['gap'] ?? 14);
    $rowH      = $barH + $gap;
    $labelW    = (int) ($opts['label_width'] ?? 230);
    $muted     = '#8a93a5';
    $textColor = (string) ($opts['text_color'] ?? '#1a202c');
    $barColor  = (string) ($opts['bar_color'] ?? '#111111');
    $showPct   = (bool) ($opts['show_percent'] ?? true);

    $n = count($rows);
    if ($n === 0) {
      return vr_empty_chart($width, max(60, $n * $rowH + 12), 'No data for this period.');
    }

    $height = max(60, $n * $rowH + 12);
    $max = 1;
    foreach ($rows as $r) { $max = max($max, (int) $r[1]); }

    $maxValW = 0;
    foreach ($rows as $r) {
      $valLabel = isset($r[2]) && $r[2] !== '' ? (string) $r[2] : (string) $r[1];
      $pct = $showPct ? ' (' . round(100 * (int) $r[1] / $max) . '%)' : '';
      $len = strlen($valLabel . $pct) * 6.5; // approx text width
      $maxValW = max($maxValW, (int) $len);
    }

    $musW   = 30;                          // space reserved after bar for value text
    $avail  = $width - $labelW - $musW - $maxValW;
    $avail  = max(20, $avail);

    $out = '<svg viewBox="0 0 ' . $width . ' ' . $height . '" role="img" aria-label="Horizontal bar chart" style="width:100%;height:auto;display:block;max-width:700px;margin:0 auto;">' . vr_svg_style();

    foreach ($rows as $i => $r) {
      $y        = $i * $rowH;
      $label    = (string) $r[0];
      $val      = (int) $r[1];
      $valLabel = isset($r[2]) && $r[2] !== '' ? (string) $r[2] : (string) $val;
      $pct      = $showPct ? ' (' . round(100 * $val / $max) . '%)' : '';
      $barW     = $val > 0 ? max(3, round($avail * $val / $max)) : 3;

      // category label (right-aligned to the bar start) — avoids overflow
      $out .= '<text class="vr-cat vr-t" x="' . ($labelW - 8) . '" y="' . ($y + $barH / 2 + 4) . '" text-anchor="end">' . htmlspecialchars($label) . '</text>';

      $out .= '<rect x="' . $labelW . '" y="' . $y . '" width="' . $barW . '" height="' . $barH . '" rx="3" fill="' . $barColor . '" opacity="0.88"/>';

      $tx = $labelW + $barW + 8;
      $out .= '<text class="vr-tick vr-t" x="' . $tx . '" y="' . ($y + $barH / 2 + 4) . '">' . htmlspecialchars($valLabel . $pct) . '</text>';
    }

    $out .= '</svg>';
    return $out;
  }
}

if (!function_exists('vr_label_step')) {
  /** Choose x-label spacing so labels don't collide (~86px apart). */
  function vr_label_step(int $n, int $plotW): int {
    if ($n <= 1) { return 1; }
    $step = (int) ceil(86 / ($plotW / $n));
    return max(1, $step);
  }
}

if (!function_exists('vr_empty_chart')) {
  /** Friendly empty-state (no data) placeholder. */
  function vr_empty_chart(int $w, int $h, string $msg): string {
    return '<svg viewBox="0 0 ' . $w . ' ' . $h . '" role="img" style="width:100%;height:auto;display:block;max-width:700px;margin:0 auto;">'
      . vr_svg_style()
      . '<rect x="1" y="1" width="' . ($w - 2) . '" height="' . ($h - 2) . '" fill="#fbfbfc" stroke="#eceff3" stroke-width="1" rx="6"/>'
      . '<text class="vr-tick vr-t" x="' . ($w / 2) . '" y="' . ($h / 2) . '" text-anchor="middle" dominant-baseline="middle">' . htmlspecialchars($msg) . '</text>'
      . '</svg>';
  }
}

if (!function_exists('vr_analytics_daily')) {
  /**
   * Daily aggregate for a date range. Returns [ [label, value], ... ] ascending by date,
   * with every day in range filled (zeros where no data).
   */
  function vr_analytics_daily($pdo, string $from, string $to, string $select = 'COUNT(*)', string $where = ''): array {
    $w = ($where === '') ? '' : (' AND ' . $where);
    $stmt = $pdo->prepare(
      "SELECT DATE(created_at) d, $select val
       FROM orders
       WHERE created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)$w
       GROUP BY d ORDER BY d"
    );
    $stmt->execute([$from, $to]);
    $rows = $stmt->fetchAll();

    $map = [];
    foreach ($rows as $r) { $map[(string) $r['d']] = (int) $r['val']; }

    $out = [];
    $cursor = new DateTime($from);
    $end    = new DateTime($to);
    while ($cursor <= $end) {
      $key = $cursor->format('Y-m-d');
      $out[] = [$cursor->format('d M'), $map[$key] ?? 0];
      $cursor->modify('+1 day');
    }
    return $out;
  }
}