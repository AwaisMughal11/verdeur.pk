<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$successMsg = '';
$errorMsg = '';

try {
  $pdo = verdeur_db();

  // Handle Up / Down action via POST
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf($_POST['csrf_token'] ?? '')) {
      $errorMsg = 'Security validation failed (CSRF token invalid).';
    } else {
      $action = $_POST['action'] ?? '';
      $id = (int) ($_POST['id'] ?? 0);

      if (($action === 'up' || $action === 'down') && $id > 0) {
        $allProducts = $pdo->query(
          'SELECT p.product_id, p.sort_order, c.sort_order AS collection_sort 
           FROM products p 
           JOIN collections c ON c.collection_id = p.collection_id 
           ORDER BY c.sort_order, p.sort_order, p.product_id'
        )->fetchAll();

        $currentIndex = -1;
        foreach ($allProducts as $idx => $p) {
          if ((int)$p['product_id'] === $id) {
            $currentIndex = $idx;
            break;
          }
        }

        if ($currentIndex !== -1) {
          $targetIndex = $action === 'up' ? $currentIndex - 1 : $currentIndex + 1;

          if ($targetIndex >= 0 && $targetIndex < count($allProducts)) {
            $currentProd = $allProducts[$currentIndex];
            $targetProd = $allProducts[$targetIndex];

            $pdo->beginTransaction();
            $upStmt = $pdo->prepare('UPDATE products SET sort_order = ? WHERE product_id = ?');
            $upStmt->execute([$targetProd['sort_order'], $currentProd['product_id']]);
            $upStmt->execute([$currentProd['sort_order'], $targetProd['product_id']]);
            $pdo->commit();

            $successMsg = 'Sort order updated successfully.';
          }
        }
      }
    }
  }

  $products = $pdo->query(
    'SELECT p.product_id, p.name, p.expression, p.image, p.sort_order, c.name AS collection_name 
     FROM products p 
     JOIN collections c ON c.collection_id = p.collection_id 
     ORDER BY c.sort_order, p.sort_order, p.product_id'
  )->fetchAll();

} catch (Throwable $e) {
  if ($pdo && $pdo->inTransaction()) {
    $pdo->rollBack();
  }
  $errorMsg = 'Error: ' . $e->getMessage();
  $products = [];
}

$pageTitle = 'Sort Products — Verdeur Admin';
include(__DIR__ . '/includes/header.php');
?>

<div class="admin-header">
  <div class="admin-title">
    <h1>Manage Product Sorting</h1>
    <p>Use Up and Down buttons to adjust product display order securely</p>
  </div>
  <a href="products.php" class="btn btn-outline">← Back to Products</a>
</div>

<?php if ($successMsg !== ''): ?>
  <div style="background: rgba(46, 204, 113, 0.1); border: 1px solid rgba(46, 204, 113, 0.3); color: #38a169; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($successMsg); ?>
  </div>
<?php endif; ?>

<?php if ($errorMsg !== ''): ?>
  <div style="background: rgba(229, 62, 62, 0.1); border: 1px solid rgba(229, 62, 62, 0.3); color: #e53e3e; padding: 12px 16px; font-size: 13px; margin-bottom: 24px;">
    <?php echo htmlspecialchars($errorMsg); ?>
  </div>
<?php endif; ?>

<div class="content-card">
  <?php if (count($products) === 0): ?>
    <p style="color: var(--text-muted); font-size: 13px;">No products found.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th style="width: 70px;">Image</th>
          <th>Product Name</th>
          <th>Collection</th>
          <th style="text-align: right; width: 180px;">Move Order</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $index => $prod): ?>
          <tr>
            <td>
              <?php if (!empty($prod['image'])): ?>
                <img src="../<?php echo htmlspecialchars($prod['image']); ?>" alt="" style="width: 32px; height: 45px; object-fit: contain; background: #fafbfc; border: 1px solid var(--border); padding: 2px;">
              <?php else: ?>
                <span style="font-size: 10px; color: var(--text-muted);">No img</span>
              <?php endif; ?>
            </td>
            <td>
              <strong><?php echo htmlspecialchars($prod['name']); ?></strong>
              <br><span style="font-size: 11px; color: var(--text-muted);"><?php echo htmlspecialchars($prod['expression']); ?></span>
            </td>
            <td><?php echo htmlspecialchars($prod['collection_name']); ?></td>
            <td style="text-align: right; white-space: nowrap;">
              <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="up">
                <input type="hidden" name="id" value="<?php echo $prod['product_id']; ?>">
                <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">
                <button type="submit" class="btn btn-outline" style="padding: 6px 12px; font-size: 11px;" title="Move Up">↑ Up</button>
              </form>
              <form method="POST" style="display: inline; margin-left: 4px;">
                <input type="hidden" name="action" value="down">
                <input type="hidden" name="id" value="<?php echo $prod['product_id']; ?>">
                <input type="hidden" name="csrf_token" value="<?php echo admin_csrf_token(); ?>">
                <button type="submit" class="btn btn-outline" style="padding: 6px 12px; font-size: 11px;" title="Move Down">↓ Down</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php
include(__DIR__ . '/includes/footer.php');
?>
