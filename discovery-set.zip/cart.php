﻿<?php

$pageTitle = 'Cart — Verdeur';
include('includes/header.php');
?>




  <main class="vcart-page">

  <section class="vcart-section">

    <div class="vcart-inner">


      <!-- =====================================
           PAGE HEADER
      ====================================== -->

      <header class="vcart-header">

        <p class="vcart-kicker">
          Verdeur
        </p>

        <h1 class="vcart-title">
          CART
        </h1>

      </header>



      <!-- =====================================
           CART CONTENT
      ====================================== -->

      <div
        class="vcart-layout"
        id="vcart-layout"
      >


        <!-- =================================
             LEFT — CART ITEMS
        ================================== -->

        <div class="vcart-items-column">

          <div class="vcart-list-header">

            <h2>
              Your Items
            </h2>

            <p id="vcart-count">
              0 items
            </p>

          </div>


          <div
            class="vcart-items"
            id="vcart-items"
          >

          </div>

        </div>



        <!-- =================================
             RIGHT — ORDER SUMMARY
        ================================== -->

        <aside class="vcart-summary">

          <h2 class="vcart-summary-title">
            Order Summary
          </h2>


          <div class="vcart-summary-row">

            <span>
              Subtotal
            </span>

            <span id="vcart-subtotal">
              Rs. 0
            </span>

          </div>


          <div class="vcart-summary-row">

            <span>
              Shipping
            </span>

            <span id="vcart-shipping">
              Rs. 0
            </span>

          </div>


          <div class="vcart-total">

            <span>
              Total
            </span>

            <strong id="vcart-total">
              Rs. 0
            </strong>

          </div>


          <p class="vcart-payment-note">
            Orders are confirmed upon advance payment.
            Cash on Delivery is currently unavailable.
          </p>


          <a
            href="checkout.php"
            class="vcart-checkout-btn"
          >
            Proceed to Checkout
          </a>


          <a
            href="fragrances.php"
            class="vcart-continue"
          >
            Continue Shopping
          </a>

        </aside>


      </div>



      <!-- =====================================
           EMPTY CART
      ====================================== -->

      <div
        class="vcart-empty"
        id="vcart-empty"
        hidden
      >

        <p class="vcart-empty-label">
          Your cart is empty
        </p>

        <h2>
          Find an expression that stays with you.
        </h2>

        <a
          href="fragrances.php"
          class="vcart-empty-btn"
        >
          Explore Fragrances
        </a>

      </div>


    </div>

  </section>

</main>

  <!-- =========================================
     10 — FOOTER
========================================== -->

<?php include('includes/footer.php'); ?>
