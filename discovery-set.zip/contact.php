﻿<?php

$pageTitle = 'Initialé — Verdeur';
include('includes/header.php');
?>




  <main>

<main class="ct-page">

  <!-- =========================================
       CONTACT INTRO
  ========================================== -->

  <section class="ct-section">

    <div class="ct-inner">


      <!-- PAGE INTRO -->
      <header class="ct-header">

        <p class="ct-kicker">
          Verdeur
        </p>

        <h1 class="ct-title">
          CONTACT
        </h1>

        <p class="ct-intro">
          For fragrance guidance, orders or general enquiries,
          we’ll be happy to hear from you.
        </p>

      </header>



      <!-- =====================================
           CONTACT FORM
      ====================================== -->

      <form
        class="ct-form"
        id="contact-form"
        action="api/contact.php"
        method="post"
      >


        <!-- NAME + EMAIL -->
        <div class="ct-form-row">

          <div class="ct-field">

            <label for="contact-name">
              Name
            </label>

            <input
              type="text"
              id="contact-name"
              name="name"
              autocomplete="name"
              required
            >

          </div>


          <div class="ct-field">

            <label for="contact-email">
              Email
            </label>

            <input
              type="email"
              id="contact-email"
              name="email"
              autocomplete="email"
              required
            >

          </div>

        </div>



        <!-- SUBJECT -->
        <div class="ct-field">

          <label for="contact-subject">
            Subject
          </label>

          <input
            type="text"
            id="contact-subject"
            name="subject"
          >

        </div>



        <!-- MESSAGE -->
        <div class="ct-field">

          <label for="contact-message">
            Message
          </label>

          <textarea
            id="contact-message"
            name="message"
            rows="7"
            required
          ></textarea>

        </div>



        <!-- SUBMIT -->
        <button
          type="submit"
          class="ct-submit"
        >
          Send Message
        </button>


      </form>

    </div>

  </section>

</main>
 
  </main>

  <!-- =========================================
       CONTACT SUCCESS POPUP
  ========================================== -->

  <div
    class="ct-popup"
    id="contact-popup"
    role="dialog"
    aria-modal="true"
    aria-labelledby="contact-popup-title"
    hidden
  >

    <div class="ct-popup-backdrop" data-contact-popup-close></div>

    <div class="ct-popup-card">

      <button
        type="button"
        class="ct-popup-close"
        data-contact-popup-close
        aria-label="Close"
      >
        ×
      </button>

      <span class="ct-popup-icon" aria-hidden="true">✓</span>

      <h2 class="ct-popup-title" id="contact-popup-title">
        Message Sent
      </h2>

      <p class="ct-popup-text" id="contact-popup-message">
        Thank you for reaching out. Our team will get back
        to you soon.
      </p>

      <button
        type="button"
        class="ct-popup-btn"
        data-contact-popup-close
      >
        Done
      </button>

    </div>

  </div>

  <!-- =========================================
     10 — FOOTER
========================================== -->

<?php include('includes/footer.php'); ?>
