<!-- =========================================
       FOOTER
  ========================================== -->

  <footer class="site-footer">

    <div class="footer-inner">

      <!-- BRAND -->
      <div class="footer-brand">

        <a href="index.php" class="footer-logo" aria-label="Verdeur Home">

          <img
            src="assets/logo/verdeur-logo.svg"
            alt="Verdeur"
          >

        </a>

        <p class="footer-brand-copy">
          <?= nl2br(v_esc(
            verdeur_setting('footer_brand_copy', 'Independent fragrance house. Scent, expressed as something more.')
          )) ?>
        </p>

      </div>

      <!-- MENU -->
      <div class="footer-column">

        <h3 class="footer-heading">
          Menu
        </h3>

        <nav class="footer-links">

          <a href="index.php">Home</a>

          <a href="fragrances">
            Fragrances
          </a>

          <a href="story.php">
            Our Story
          </a>

          <a href="contact.php">
            Contact
          </a>

        </nav>

      </div>

      <!-- EXPLORE -->
      <div class="footer-column">

        <h3 class="footer-heading">
          Explore
        </h3>

        <nav class="footer-links">

<?php foreach (verdeur_collections() as $collection): ?>

          <a href="collection/<?php echo v_esc($collection['slug']); ?>">
            <?php echo v_esc($collection['name']); ?>
          </a>

<?php endforeach; ?>

          <a href="discovery-set">
            Discovery Set
          </a>

          <?php foreach (verdeur_legal_pages() as $page): ?>

            <a
              class="footer-legal-link"
              href="legal.php?page=<?= v_esc($page['slug']) ?>"
            >
              <?= v_esc($page['title']) ?>
            </a>

          <?php endforeach; ?>

        </nav>

      </div>

      <!-- CONTACT -->
      <div class="footer-column footer-contact">

        <h3 class="footer-heading">
          Contact
        </h3>

        <div class="footer-links">

          <a href="mailto:<?= v_esc(verdeur_setting('contact_email', 'hello@verdeur.com')) ?>">
            <?= v_esc(verdeur_setting('contact_email', 'hello@verdeur.com')) ?>
          </a>

          <a
            href="https://wa.me/<?= v_esc(verdeur_setting('whatsapp_number', '923041461111')) ?>"
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp
          </a>

        </div>

      </div>

    </div>

    <!-- LOWER FOOTER -->
    <div class="footer-bottom">

      <!-- SOCIAL ICONS -->
      <?php $verdeurSocials = verdeur_socials(); ?>

      <div class="footer-socials">

        <!-- Facebook -->
        <a
          href="<?= v_esc($verdeurSocials['facebook']) ?>"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Facebook"
        >

          <svg viewBox="0 0 24 24" aria-hidden="true">

            <path
              d="M13.5 22v-9h3l.45-3.5H13.5V7.26c0-1.01.28-1.7 1.73-1.7H17V2.43c-.31-.04-1.38-.13-2.63-.13-2.6 0-4.37 1.58-4.37 4.49V9.5H7v3.5h3v9h3.5z"
            />

          </svg>

        </a>

        <!-- Instagram -->
        <a
          href="<?= v_esc($verdeurSocials['instagram']) ?>"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Instagram"
        >

          <svg
            viewBox="0 0 24 24"
            class="footer-instagram"
            aria-hidden="true"
          >

            <rect
              x="3"
              y="3"
              width="18"
              height="18"
              rx="5"
              ry="5"
            ></rect>

            <circle
              cx="12"
              cy="12"
              r="4"
            ></circle>

            <circle
              cx="17.5"
              cy="6.5"
              r="1"
            ></circle>

          </svg>

        </a>

        <!-- TikTok -->
        <a
          href="<?= v_esc($verdeurSocials['tiktok']) ?>"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="TikTok"
        >

          <svg viewBox="0 0 24 24" aria-hidden="true">

            <path
              d="M14 3v11.2a4.4 4.4 0 1 1-3.5-4.3v3.1a1.5 1.5 0 1 0 .5 1.1V3h3zm0 0c.5 2.7 2.1 4.4 4.5 4.8v3.1c-1.8-.1-3.3-.7-4.5-1.7"
            />

          </svg>

        </a>

      </div>

      <p class="footer-copyright">
        <?= v_esc(verdeur_setting('copyright_text', '© 2026 Verdeur. All rights reserved.')) ?>
      </p>

    </div>

  </footer>

  <!-- =========================================
       FLOATING WHATSAPP
  ========================================== -->

  <a
    href="https://wa.me/<?= v_esc(verdeur_setting('whatsapp_number', '923041461111')) ?>?text=<?= v_esc(verdeur_setting('whatsapp_message', 'Hi%20Verdeur%2C%20I%20would%20like%20to%20know%20more%20about%20your%20fragrances.')) ?>"
    class="whatsapp-float"
    target="_blank"
    rel="noopener noreferrer"
    aria-label="Chat with Verdeur on WhatsApp"
  >

    <svg
      viewBox="0 0 32 32"
      aria-hidden="true"
    >
      <path
        d="M16.04 3C8.85 3 3 8.76 3 15.85c0 2.5.74 4.94 2.13 7.02L3.02 29l6.3-2.03a13.16 13.16 0 0 0 6.71 1.84h.01C23.22 28.81 29 23.05 29 15.95 29 8.86 23.22 3 16.04 3zm0 23.64a10.92 10.92 0 0 1-5.57-1.52l-.4-.24-3.74 1.2 1.23-3.62-.26-.42a10.62 10.62 0 0 1-1.68-5.72c0-5.89 4.68-10.69 10.44-10.69 5.75 0 10.42 4.8 10.42 10.69 0 5.88-4.67 10.32-10.44 10.32zm5.72-7.77c-.31-.15-1.84-.9-2.13-1-.28-.1-.49-.15-.7.15-.2.31-.8 1-.98 1.2-.18.2-.36.23-.67.08-.31-.15-1.31-.48-2.5-1.54-.92-.81-1.55-1.82-1.73-2.13-.18-.31-.02-.47.14-.63.14-.14.31-.36.46-.54.15-.18.2-.31.31-.51.1-.21.05-.39-.03-.54-.08-.15-.7-1.68-.96-2.3-.25-.61-.51-.53-.7-.54h-.59c-.21 0-.54.08-.82.39-.28.31-1.08 1.05-1.08 2.56s1.11 2.98 1.26 3.18c.15.21 2.18 3.29 5.28 4.61.74.31 1.31.5 1.76.64.74.23 1.41.2 1.94.12.59-.09 1.84-.74 2.1-1.46.26-.72.26-1.34.18-1.46-.08-.13-.28-.21-.59-.36z"
      />
    </svg>

  </a>

  <script src="js/main.min.js" defer></script>

</body>

</html>