<?php

require_once __DIR__ . '/../config.php';

$currentPage = basename($_SERVER['PHP_SELF']);
$pageTitle   = isset($pageTitle) ? $pageTitle : 'Verdeur — Independent Fragrance House';
$headerClass = isset($headerClass) ? $headerClass : 'page-header';

$verdeurBaseUrl =
  (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
  . '://'
  . $_SERVER['HTTP_HOST']
  . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\')
  . '/';

$verdeurCurrentCollection = '';

if ($currentPage === 'collection.php') {
  $verdeurCurrentCollection = trim((string) ($_GET['collection'] ?? ''));
}

$verdeurNavCollections = verdeur_collections();

function v_aria_current($file)
{
    global $currentPage;
    return $currentPage === $file ? ' aria-current="page"' : '';
}

function v_aria_current_when($condition)
{
    return $condition ? ' aria-current="page"' : '';
}

$verdeurIsFragrancesArea =
  in_array($currentPage, ['fragrances.php', 'collection.php', 'product.php', 'discovery-set.php'], true);

function v_nav_collection_active($slug)
{
    global $currentPage, $verdeurCurrentCollection;
    return $currentPage === 'collection.php' && $verdeurCurrentCollection === $slug ? ' aria-current="page"' : '';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
  >

  <meta name="google-site-verification" content="3x-gjWqKz0APsXYCWhz2bw3CQH5yLmV0ikEQ9RwovJM">

  <base href="<?php echo v_esc($verdeurBaseUrl); ?>">

  <title><?php echo $pageTitle; ?></title>

  <?php
  /* =========================================
     SEO — meta description, canonical, OG, Twitter, JSON-LD
  ========================================= */

  $seoDescription = trim((string) ($pageDescription ?? ''));
  if ($seoDescription === '') {
    $seoDescription = trim((string) verdeur_setting('seo_default_description', 'Verdeur — an independent fragrance house. Explore collection-driven perfume expressions, discovery sets and fragrance stories.'));
  }
  if ($seoDescription === '') {
    $seoDescription = 'Verdeur — an independent fragrance house. Explore collection-driven perfume expressions, discovery sets and fragrance stories.';
  }

  $https        = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
  $scheme       = $https ? 'https' : 'http';
  $host         = (string) ($_SERVER['HTTP_HOST'] ?? '');
  $requestUri   = (string) ($_SERVER['REQUEST_URI'] ?? '/');
  $canonicalUrl = isset($canonicalUrl) ? (string) $canonicalUrl : ($scheme . '://' . $host . $requestUri);
  $canonicalUrl = preg_replace('~[?&](utm_[^&=]+)=[^&]*~', '', $canonicalUrl);
  $canonicalUrl = rtrim($canonicalUrl, '?');

  $seoType   = isset($seoType) ? (string) $seoType : 'website';
  $seoImage  = (string) ($pageImage ?? '');
  if ($seoImage === '') {
    $seoImage = 'assets/images/fragrance-experience-card.webp';
  }
  if (strpos($seoImage, 'http') !== 0) {
    $seoImage = rtrim($verdeurBaseUrl, '/') . '/' . ltrim($seoImage, '/');
  }
  $seoUrl = $canonicalUrl;

  if ($seoDescription !== '') {
    echo '<meta name="description" content="' . v_esc($seoDescription) . '">' . "\n";
  }
  echo '<meta name="robots" content="index, follow, max-image-preview:large">' . "\n";
  echo '<link rel="canonical" href="' . v_esc($seoUrl) . '">' . "\n";

  $siteName = (string) verdeur_setting('seo_org_name', 'Verdeur');
  ?>

  <!-- Open Graph -->
  <meta property="og:type" content="<?php echo v_esc($seoType); ?>">
  <meta property="og:site_name" content="<?php echo v_esc($siteName); ?>">
  <meta property="og:title" content="<?php echo v_esc($pageTitle); ?>">
  <meta property="og:description" content="<?php echo v_esc($seoDescription); ?>">
  <meta property="og:url" content="<?php echo v_esc($seoUrl); ?>">
  <meta property="og:image" content="<?php echo v_esc($seoImage); ?>">
  <meta property="og:locale" content="en_US">

  <!-- Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo v_esc($pageTitle); ?>">
  <meta name="twitter:description" content="<?php echo v_esc($seoDescription); ?>">
  <meta name="twitter:image" content="<?php echo v_esc($seoImage); ?>">

  <?php if ($seoType === 'product'): ?>
    <?php if (isset($seoName) && $seoName !== ''): ?>
      <meta property="product:brand" content="<?php echo v_esc($siteName); ?>">
      <meta property="product:name" content="<?php echo v_esc($seoName); ?>">
      <?php if (isset($seoPrice) && $seoPrice !== ''): ?>
        <meta property="product:price:amount" content="<?php echo v_esc($seoPrice); ?>">
        <meta property="product:price:currency" content="PKR">
      <?php endif; ?>
      <?php if (isset($seoAvailability) && $seoAvailability !== ''): ?>
        <meta property="product:availability" content="<?php echo v_esc($seoAvailability); ?>">
      <?php endif; ?>
    <?php endif; ?>
  <?php endif; ?>

  <?php
  /* JSON-LD structured data */
  $jsonLd = [];
  if ($seoType === 'product' && isset($seoName) && $seoName !== '') {
    $jsonLd = [
      '@context' => 'https://schema.org',
      '@type'    => 'Product',
      'name'     => (string) $seoName,
      'image'    => $seoImage,
      'brand'    => ['@type' => 'Brand', 'name' => $siteName],
      'url'      => $seoUrl,
    ];
    if (isset($seoDescription) && $seoDescription !== '') {
      $jsonLd['description'] = (string) $seoDescription;
    }
    if (isset($seoPrice) && $seoPrice !== '') {
      $jsonLd['offers'] = [
        '@type'         => 'Offer',
        'price'         => (string) $seoPrice,
        'priceCurrency' => 'PKR',
        'availability'  => 'https://schema.org/InStock',
      ];
    }
  } elseif ($seoType === 'collection') {
    $jsonLd = [
      '@context'      => 'https://schema.org',
      '@type'         => 'CollectionPage',
      'name'          => (string) (isset($seoName) ? $seoName : $pageTitle),
      'description'   => $seoDescription,
      'url'           => $seoUrl,
    ];
  } else {
    $jsonLd = [
      '@context' => 'https://schema.org',
      '@type'    => 'WebSite',
      'name'     => $siteName,
      'url'      => $seoUrl,
      'potentialAction' => [
        '@type'       => 'SearchAction',
        'target'      => rtrim($seoUrl, '/') . '/fragrances',
        'query-input' => 'required name=search_term_string',
      ],
    ];
  }
  echo '<script type="application/ld+json">' . "\n" . json_encode($jsonLd, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n" . '</script>' . "\n";
  ?>

  <!-- Figtree -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link
    href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap"
    rel="stylesheet"
  >

  <link rel="preload" as="style" href="css/style.min.css">
  <link rel="stylesheet" href="css/style.min.css">

</head>

<body>

  <!-- =========================================
       HEADER
  ========================================== -->

  <header class="site-header<?php echo $headerClass ? ' ' . $headerClass : ''; ?>">

    <div class="header-inner">

      <!-- Mobile Menu Button -->

      <button
        class="menu-toggle"
        type="button"
        aria-label="Open navigation"
        aria-expanded="false"
      >
        <span></span>
        <span></span>
      </button>

      <!-- Desktop Navigation -->

      <nav class="desktop-nav" aria-label="Primary navigation">

        <a href="index.php" class="nav-link"<?php echo v_aria_current('index.php'); ?>>
          Home
        </a>

        <div class="nav-item nav-item-dropdown">

          <a href="fragrances" class="nav-link"<?php echo v_aria_current_when($verdeurIsFragrancesArea); ?>>
            Fragrances
          </a>

          <div class="nav-dropdown">

<?php foreach ($verdeurNavCollections as $navCollection): ?>

            <a
              href="collection/<?php echo v_esc($navCollection['slug']); ?>"
              class="dropdown-link"<?php echo v_nav_collection_active($navCollection['slug']); ?>
            >
              <?php echo v_esc($navCollection['name']); ?>
            </a>

<?php endforeach; ?>

          </div>

        </div>

        <a href="story.php" class="nav-link"<?php echo v_aria_current('story.php'); ?>>
          Our Story
        </a>

        <a href="contact.php" class="nav-link"<?php echo v_aria_current('contact.php'); ?>>
          Contact
        </a>

      </nav>

      <!-- Center Logo -->

      <a
        href="index.php"
        class="brand-logo"
        aria-label="Verdeur Home"
      >

        <img
          src="assets/logo/verdeur-logo.svg"
          alt="Verdeur"
        >

      </a>

      <!-- Bag -->

      <a
        href="cart.php"
        class="bag-link"
        aria-label="Shopping bag"
      >

        <svg
          viewBox="0 0 20 20"
          aria-hidden="true"
        >
          <path
            d="M3.392 6.875h13.216v8.016c0 .567-.224 1.112-.624 1.513-.4.402-.941.627-1.506.627H5.522a2.13 2.13 0 0 1-1.506-.627 2.15 2.15 0 0 1-.624-1.513zM8.818 2.969h2.333c.618 0 1.211.247 1.649.686a2.35 2.35 0 0 1 .683 1.658v1.562H6.486V5.313c0-.622.246-1.218.683-1.658a2.33 2.33 0 0 1 1.65-.686"
          />
        </svg>

        <span class="cart-count bag-count" data-cart-count>0</span>

      </a>

    </div>


    <!-- Mobile Navigation -->

    <nav
      class="mobile-nav"
      aria-label="Mobile navigation"
    >

      <a href="index.php"<?php echo v_aria_current('index.php'); ?>>
        Home
      </a>

      <div class="mobile-nav-group">

        <a
          href="fragrances"
          class="mobile-nav-parent"<?php echo v_aria_current_when($verdeurIsFragrancesArea); ?>
        >
          Fragrances
        </a>

<?php foreach ($verdeurNavCollections as $navCollection): ?>

        <a
          href="collection/<?php echo v_esc($navCollection['slug']); ?>"
          class="mobile-nav-sub"<?php echo v_nav_collection_active($navCollection['slug']); ?>
        >
          <?php echo v_esc($navCollection['name']); ?>
        </a>

<?php endforeach; ?>

      </div>

      <a href="story.php"<?php echo v_aria_current('story.php'); ?>>
        Our Story
      </a>

      <a href="contact.php"<?php echo v_aria_current('contact.php'); ?>>
        Contact
      </a>

    </nav>

  </header>

  <!-- =========================================
       CART SLIDER (DRAWER)
  ========================================== -->

  <div class="cart-slider" id="cart-slider" aria-hidden="true">

    <div class="cart-slider-backdrop" data-cart-close></div>

    <aside
      class="cart-slider-panel"
      role="dialog"
      aria-modal="true"
      aria-label="Shopping cart"
    >

      <div class="cart-slider-head">

        <h2>
          Your Bag
        </h2>

        <p class="cart-slider-count" id="cart-slider-count">
          0 items
        </p>

        <button
          type="button"
          class="cart-slider-close"
          data-cart-close
          aria-label="Close cart"
        >
          ×
        </button>

      </div>

      <div class="cart-slider-body">

        <div
          class="cart-slider-items"
          id="cart-slider-items"
        ></div>

        <div
          class="cart-slider-empty"
          id="cart-slider-empty"
          hidden
        >
          <p>
            Your bag is empty.
          </p>

          <a href="fragrances" class="cart-slider-checkout">
            Explore Fragrances
          </a>

        </div>

      </div>

      <div class="cart-slider-footer" id="cart-slider-footer">

        <div class="cart-slider-row cart-slider-subtotal">

          <span>
            Subtotal
          </span>

          <span id="cart-slider-subtotal">
            Rs. 0
          </span>

        </div>

        <a href="checkout.php" class="cart-slider-checkout">
          Proceed to Checkout
        </a>

        <a href="cart.php" class="cart-slider-view">
          View Full Cart
        </a>

      </div>

    </aside>

  </div>