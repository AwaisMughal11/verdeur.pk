<?php

require_once __DIR__ . '/config.php';

$slug = trim((string) ($_GET['page'] ?? ''));

$page = null;

if ($slug !== '') {
  try {
    $stmt = verdeur_db()->prepare(
      'SELECT slug, title, kicker, intro, content FROM legal_pages WHERE slug = ? AND is_active = 1 LIMIT 1'
    );
    $stmt->execute([$slug]);
    $page = $stmt->fetch();
  } catch (Throwable $e) {
    $page = null;
  }
}

$pageTitle = 'Legal — Verdeur';

if ($page) {
  $pageTitle = $page['title'] . ' — Verdeur';
}

$found = is_array($page);

?>

<?php include('includes/header.php'); ?>

  <main>

    <main class="policy-page">

      <?php if ($found): ?>

        <section class="policy-hero">

          <div class="policy-hero-inner">

            <p class="policy-kicker">
              <?= v_esc($page['kicker'] ?: verdeur_setting('site_name', 'Verdeur')) ?>
            </p>

            <h1 class="policy-title">
              <?= v_esc($page['title']) ?>
            </h1>

            <p class="policy-intro">
              <?= v_esc($page['intro']) ?>
            </p>

          </div>

        </section>

        <section class="policy-content">

          <div class="policy-content-inner">

            <?= $page['content'] ?>

          </div>

        </section>

      <?php else: ?>

        <section class="policy-hero">

          <div class="policy-hero-inner">

            <p class="policy-kicker">
              <?= v_esc(verdeur_setting('site_name', 'Verdeur')) ?>
            </p>

            <h1 class="policy-title">
              PAGE NOT FOUND
            </h1>

            <p class="policy-intro">
              The page you are looking for does not exist.
            </p>

          </div>

        </section>

        <section class="policy-content">

          <div class="policy-content-inner">

            <div class="policy-section">

              <h2>Not Found</h2>

              <p>
                This page may have been moved or removed. Please visit our
                <a href="index.php">home page</a> or
                <a href="contact.php">contact us</a> for help.
              </p>

            </div>

          </div>

        </section>

      <?php endif; ?>

    </main>

  </main>

<?php include('includes/footer.php'); ?>