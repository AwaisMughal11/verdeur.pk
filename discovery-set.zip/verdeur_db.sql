-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2026 at 11:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `verdeur_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password_hash`, `created_at`) VALUES
(1, 'verdeur', '$2y$10$b3v9zVy8ZbKhv7SnR5yC4ONnMaLbGMxWa3eTTSTICfizrn/Hgx6aK', '2026-09-02 07:10:11');

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `account_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `bank_name` varchar(120) NOT NULL,
  `account_title` varchar(190) NOT NULL,
  `account_number` varchar(60) NOT NULL,
  `iban` varchar(60) NOT NULL DEFAULT '',
  `branch` varchar(190) NOT NULL DEFAULT '',
  `qr_image` varchar(200) NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bank_accounts`
--

INSERT INTO `bank_accounts` (`account_id`, `name`, `bank_name`, `account_title`, `account_number`, `iban`, `branch`, `qr_image`, `is_active`, `sort_order`) VALUES
(1, 'HBL — Verdeur', 'HBL', 'Verdeur Fragran', '50037000682403', 'PK94HABB0050037000682403', 'IBB KASHMIR ROAD SIA', 'assets/images/qr.webp', 1, 1),
(2, 'Bank 2 — Verdeur', 'Jazzcash (Comming Soon)', '', '', '', '', 'assets/images/qr.webp', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `collections`
--

CREATE TABLE `collections` (
  `collection_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(60) NOT NULL,
  `name` varchar(80) NOT NULL,
  `kicker` varchar(180) NOT NULL DEFAULT '',
  `subtitle` varchar(120) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `count_label` varchar(120) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `collections`
--

INSERT INTO `collections` (`collection_id`, `slug`, `name`, `kicker`, `subtitle`, `description`, `count_label`, `sort_order`, `is_active`) VALUES
(1, 'initiale', 'Initialé', 'Verdeur\'s First Collection', 'The Beginning of Verdeur', 'Initialé brings together five fragrances, each shaped around a distinct expression of the human experience.', 'Five fragrances · Five expressions', 1, 1),
(5, 'eclat', 'ECLAT', '', '', '', '', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_queries`
--

CREATE TABLE `customer_queries` (
  `query_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `subject` varchar(190) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_queries`
--

INSERT INTO `customer_queries` (`query_id`, `name`, `email`, `subject`, `message`, `is_read`, `created_at`) VALUES
(1, 'Zainab Malik', 'zainab@example.com', 'Custom fragrance inquiry', 'Do you offer custom blending for weddings?', 1, '2026-09-02 07:15:24'),
(2, 'Usman Tariq', 'usman@example.com', 'Discovery Set delivery time', 'How many days does delivery take to Multan?', 1, '2026-09-02 07:15:24');

-- --------------------------------------------------------

--
-- Table structure for table `legal_pages`
--

CREATE TABLE `legal_pages` (
  `page_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(80) NOT NULL,
  `title` varchar(190) NOT NULL,
  `kicker` varchar(190) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `content` longtext NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `legal_pages`
--

INSERT INTO `legal_pages` (`page_id`, `slug`, `title`, `kicker`, `intro`, `content`, `sort_order`, `is_active`) VALUES
(1, 'shipping-returns', 'SHIPPING & RETURNS', 'Verdeur', 'Information about order processing, delivery and returns for purchases made through Verdeur.', '<div class=\"policy-section\"><h2>Shipping</h2><p>Verdeur delivers orders across Pakistan. A flat delivery charge of Rs. 250 applies to all orders.</p><p>Orders are prepared and dispatched after payment has been received and confirmed.</p></div><div class=\"policy-section\"><h2>Order Processing</h2><p>Once your order is confirmed, we begin preparing it for dispatch. Processing and delivery times may vary depending on your location, courier operations and public holidays.</p><p>You may be contacted if any additional information is required before your order can be dispatched.</p></div><div class=\"policy-section\"><h2>Payment</h2><p>Orders are confirmed upon advance payment. Cash on Delivery is currently unavailable.</p></div><div class=\"policy-section\"><h2>Delivery</h2><p>Please make sure the name, phone number and delivery address provided with your order are complete and accurate.</p><p>Once an order has been handed over to the courier, delivery may be affected by circumstances outside Verdeur\'s direct control.</p></div><div class=\"policy-section\"><h2>Returns &amp; Exchanges</h2><p>Due to the personal nature of fragrance products, opened or used products cannot normally be returned or exchanged.</p><p>If you receive an incorrect item, or your order arrives damaged, please contact Verdeur as soon as possible after receiving your package so that we can review the issue.</p><p>We may request photographs or other details relating to the product and packaging before arranging a replacement or other appropriate resolution.</p></div><div class=\"policy-section\"><h2>Order Changes</h2><p>If you need to make a change to your order, please contact us before it has been dispatched. Once an order has entered the shipping process, changes may no longer be possible.</p></div><div class=\"policy-section\"><h2>Need Help?</h2><p>If you have a question about an order, delivery or product received, please get in touch through our Contact page.</p></div>', 1, 1),
(2, 'privacy-policy', 'PRIVACY POLICY', 'Verdeur', 'This policy explains how Verdeur collects and uses information when you browse our website, contact us or place an order.', '<div class=\"policy-section\"><h2>Information We Collect</h2><p>When you place an order, contact us or submit information through our website, we may collect details such as your name, phone number, email address, delivery address and information relating to your order.</p><p>We may also receive information that you voluntarily provide when communicating with us regarding an enquiry, payment or customer support request.</p></div><div class=\"policy-section\"><h2>How We Use Your Information</h2><p>We use the information provided to process and fulfil orders, arrange delivery, communicate with customers, provide support and improve our services.</p><p>We may also use contact information to send updates relating specifically to an order or enquiry.</p></div><div class=\"policy-section\"><h2>Payment Information</h2><p>Information provided for payment confirmation is used only for processing and verifying the relevant order and for necessary business records.</p></div><div class=\"policy-section\"><h2>Sharing of Information</h2><p>We do not sell or rent your personal information.</p><p>Certain information may be shared with service providers where necessary to fulfil your order, such as delivery and courier services, or where required for website operations and payment processing.</p></div><div class=\"policy-section\"><h2>Cookies &amp; Website Data</h2><p>Our website may use cookies or similar technologies to help the website function correctly, understand how it is used and improve the browsing experience.</p></div><div class=\"policy-section\"><h2>Data Security</h2><p>We take reasonable steps to protect the personal information provided to us. However, no online system or method of electronic storage can be guaranteed to be completely secure.</p></div><div class=\"policy-section\"><h2>Data Retention</h2><p>Personal information may be retained for as long as reasonably necessary to fulfil orders, provide customer support, maintain business records and meet applicable legal or operational requirements.</p></div><div class=\"policy-section\"><h2>Your Information</h2><p>If you would like to ask about personal information you have provided to Verdeur, or request that information be corrected, please contact us through our Contact page.</p></div><div class=\"policy-section\"><h2>Changes to This Policy</h2><p>This Privacy Policy may be updated from time to time to reflect changes to our website, services or business practices.</p></div><div class=\"policy-section\"><h2>Contact</h2><p>For any questions relating to this Privacy Policy, please contact Verdeur through our Contact page.</p></div>', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter_subscribers`
--

CREATE TABLE `newsletter_subscribers` (
  `subscriber_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `newsletter_subscribers`
--

INSERT INTO `newsletter_subscribers` (`subscriber_id`, `email`, `is_active`, `created_at`) VALUES
(1, 'subscriber1@example.com', 1, '2026-09-02 07:15:24'),
(2, 'subscriber2@example.com', 1, '2026-09-02 07:15:24'),
(3, 'luxury.lover@example.com', 1, '2026-09-02 07:15:24');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `order_number` varchar(40) NOT NULL,
  `customer_name` varchar(120) NOT NULL,
  `customer_phone` varchar(40) NOT NULL,
  `customer_email` varchar(190) NOT NULL DEFAULT '',
  `customer_address` varchar(255) NOT NULL,
  `customer_city` varchar(80) NOT NULL,
  `customer_province` varchar(120) NOT NULL,
  `customer_notes` text DEFAULT NULL,
  `subtotal` int(11) NOT NULL DEFAULT 0,
  `shipping` int(11) NOT NULL DEFAULT 0,
  `total` int(11) NOT NULL DEFAULT 0,
  `payment_method` varchar(60) NOT NULL DEFAULT 'Bank Transfer',
  `order_status` varchar(60) NOT NULL DEFAULT 'Pending',
  `payment_status` varchar(60) NOT NULL DEFAULT 'Pending',
  `bank_account_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_number`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `customer_city`, `customer_province`, `customer_notes`, `subtotal`, `shipping`, `total`, `payment_method`, `order_status`, `payment_status`, `bank_account_id`, `created_at`) VALUES
(3, 'VRD-260904-446A', 'Abubakar Mughal', '+923312117353', 'am2825698@gmail.com', 'gujrawali gali', 'Daska', 'Punjab', NULL, 12270, 250, 12520, 'Cash on Delivery', 'Pending', 'Pending', 1, '2026-09-04 01:06:13'),
(4, 'VRD-260904-A5B5', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 5980, 250, 6230, 'HBL', 'Pending', 'Pending', 1, '2026-09-04 01:21:19'),
(5, 'VRD-260904-4B2D', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 3990, 250, 4240, 'HBL', 'Pending', 'Pending', 1, '2026-09-04 01:27:24'),
(6, 'VRD-260904-8A2D', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 5980, 250, 6230, 'HBL', 'Pending', 'Pending', 1, '2026-09-04 01:42:06'),
(7, 'VRD-260904-B2F4', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 1990, 250, 2240, 'HBL', 'Pending', 'Pending', 1, '2026-09-04 01:43:42'),
(8, 'VRD-260904-4667', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 5980, 250, 6230, 'HBL', 'Pending', 'Pending', 1, '2026-09-04 01:54:04'),
(9, 'VRD-260904-8CAD', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 7980, 250, 8230, 'HBL', 'Pending', 'Pending', 1, '2026-09-04 01:56:13'),
(10, 'VRD-260905-3746', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 3990, 250, 4240, 'Cash on Delivery', 'Pending', 'Pending', 1, '2026-09-05 03:07:59'),
(11, 'VRD-260907-CD5E', 'Muhammad Awais', '+923279897083', 'am2825698@gmail.com', 'College Road Tanki, Jamke Road Daska', 'Daska', 'Punjab', NULL, 11970, 250, 12220, 'HBL', 'Pending', 'Pending', 1, '2026-09-07 04:18:17');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `item_key` varchar(80) NOT NULL DEFAULT '',
  `item_name` varchar(190) NOT NULL,
  `item_meta` varchar(190) NOT NULL DEFAULT '',
  `unit_price` int(11) NOT NULL DEFAULT 0,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `line_total` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `product_id`, `item_key`, `item_name`, `item_meta`, `unit_price`, `quantity`, `line_total`) VALUES
(5, 3, 2, 'next-chapter', 'NEXT CHAPTER', '50ml · Extrait de Parfum', 3990, 1, 3990),
(6, 3, 5, 'rhythm-of-sandal', 'RHYTHM OF SANDAL', '50ml · Extrait de Parfum', 3990, 1, 3990),
(7, 3, NULL, 'golden-hour', 'GOLDEN HOUR', '50ml · Extrait de Parfum', 4290, 1, 4290),
(8, 4, 2, 'next-chapter', 'NEXT CHAPTER', '50ml · Extrait de Parfum', 3990, 1, 3990),
(9, 4, NULL, 'Initiale-set', 'INITIALÉ DISCOVERY SET', '5 × 5ml · Extrait de Parfum', 1990, 1, 1990),
(10, 5, 2, 'next-chapter', 'NEXT CHAPTER', '50ml · Extrait de Parfum', 3990, 1, 3990),
(11, 6, 1, 'pearls-and-petals', 'PEARLS & PETALS', '50ml · Extrait de Parfum', 3990, 1, 3990),
(12, 6, NULL, 'Initiale-set', 'INITIALÉ DISCOVERY SET', '5 × 5ml · Extrait de Parfum', 1990, 1, 1990),
(13, 7, NULL, 'Initiale-set', 'INITIALÉ DISCOVERY SET', '5 × 5ml · Extrait de Parfum', 1990, 1, 1990),
(14, 8, 2, 'next-chapter', 'NEXT CHAPTER', '50ml · Extrait de Parfum', 3990, 1, 3990),
(15, 8, NULL, 'Initiale-set', 'INITIALÉ DISCOVERY SET', '5 × 5ml · Extrait de Parfum', 1990, 1, 1990),
(16, 9, 2, 'next-chapter', 'NEXT CHAPTER', '50ml · Extrait de Parfum', 3990, 1, 3990),
(17, 9, 4, 'musc-affair', 'MUSC AFFAIR', '50ml · Extrait de Parfum', 3990, 1, 3990),
(18, 10, 2, 'next-chapter', 'NEXT CHAPTER', '50ml · Extrait de Parfum', 3990, 1, 3990),
(19, 11, 2, 'next-chapter', 'NEXT CHAPTER', '50ml · Extrait de Parfum', 3990, 2, 7980),
(20, 11, 4, 'musc-affair', 'MUSC AFFAIR', '50ml · Extrait de Parfum', 3990, 1, 3990);

-- --------------------------------------------------------

--
-- Table structure for table `order_rate_limits`
--

CREATE TABLE `order_rate_limits` (
  `rl_key` varchar(64) NOT NULL,
  `window_start` int(10) UNSIGNED NOT NULL,
  `hits` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_rate_limits`
--

INSERT INTO `order_rate_limits` (`rl_key`, `window_start`, `hits`) VALUES
('ip:28619e7c06f497606cef28fa36b6ce6d', 1788754697, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pending_emails`
--

CREATE TABLE `pending_emails` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `to_email` varchar(190) NOT NULL,
  `to_name` varchar(120) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `body_html` mediumtext NOT NULL,
  `body_text` text NOT NULL,
  `status` enum('pending','processing','sent','failed') NOT NULL DEFAULT 'pending',
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `error` varchar(500) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `sent_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pending_emails`
--

INSERT INTO `pending_emails` (`id`, `order_id`, `to_email`, `to_name`, `subject`, `body_html`, `body_text`, `status`, `attempts`, `error`, `created_at`, `sent_at`) VALUES
(2, 5, 'am2825698@gmail.com', 'Muhammad Awais', 'Order Placed — #VRD-260904-4B2D — Verdeur.pk', '\n        <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n          <h2 style=\'color:#111;\'>Thank you for your order, Muhammad Awais!</h2>\n          <p>Your order <strong>#VRD-260904-4B2D</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>\n          <div style=\'background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;\'><table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 4,240</p></div>\n          <p>You have chosen <strong>Bank Transfer</strong>. Please complete your payment to the bank account shown on our website.</p>\n          <p style=\'font-weight:bold;margin-top:18px;\'>Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.</p>\n          <p style=\'color:#777;font-size:13px;\'>If you have any other questions, reply to this email or contact us.</p>\n          <p style=\'color:#777;font-size:13px;\'>Best regards,<br>Verdeur.pk Team</p>\n        </div>', 'Your order #VRD-260904-4B2D has been placed. Total: Rs. 4,240. Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.', 'sent', 1, '', '2026-09-04 01:27:24', '2026-09-04 06:27:29'),
(3, 5, 'am2825698@gmail.com', 'Verdeur Admin', 'New Order #VRD-260904-4B2D — Verdeur.pk', '\n      <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n        <h2 style=\'color:#111;\'>New Order #VRD-260904-4B2D</h2>\n        <table style=\'width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;\'>\n          <tr><td style=\'padding:6px 8px;\'><strong>Customer:</strong></td><td style=\'padding:6px 8px;\'>Muhammad Awais</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Phone:</strong></td><td style=\'padding:6px 8px;\'>+923279897083</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Email:</strong></td><td style=\'padding:6px 8px;\'>am2825698@gmail.com</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Address:</strong></td><td style=\'padding:6px 8px;\'>College Road Tanki, Jamke Road Daska, Daska, Punjab</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Payment:</strong></td><td style=\'padding:6px 8px;\'>HBL</td></tr>\n        </table>\n        <table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 4,240</p>\n      </div>', 'New order #VRD-260904-4B2D from Muhammad Awais (+923279897083) - Rs. 4,240', 'sent', 1, '', '2026-09-04 01:27:24', '2026-09-04 06:27:35'),
(4, 6, 'am2825698@gmail.com', 'Muhammad Awais', 'Order Placed — #VRD-260904-8A2D — Verdeur.pk', '\n        <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n          <h2 style=\'color:#111;\'>Thank you for your order, Muhammad Awais!</h2>\n          <p>Your order <strong>#VRD-260904-8A2D</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>\n          <div style=\'background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;\'><table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">PEARLS &amp; PETALS<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">INITIALÉ DISCOVERY SET<br><span style=\"font-size:12px;color:#777;\">5 × 5ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 1,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 6,230</p></div>\n          <p>You have chosen <strong>Bank Transfer</strong>. Please complete your payment to the bank account shown on our website.</p>\n          <p style=\'font-weight:bold;margin-top:18px;\'>Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.</p>\n          <p style=\'color:#777;font-size:13px;\'>If you have any other questions, reply to this email or contact us.</p>\n          <p style=\'color:#777;font-size:13px;\'>Best regards,<br>Verdeur.pk Team</p>\n        </div>', 'Your order #VRD-260904-8A2D has been placed. Total: Rs. 6,230. Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.', 'sent', 1, '', '2026-09-04 01:42:06', '2026-09-04 06:42:11'),
(5, 6, 'verdeurfragrances@gmail.com', 'Verdeur Admin', 'New Order #VRD-260904-8A2D — Verdeur.pk', '\n      <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n        <h2 style=\'color:#111;\'>New Order #VRD-260904-8A2D</h2>\n        <table style=\'width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;\'>\n          <tr><td style=\'padding:6px 8px;\'><strong>Customer:</strong></td><td style=\'padding:6px 8px;\'>Muhammad Awais</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Phone:</strong></td><td style=\'padding:6px 8px;\'>+923279897083</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Email:</strong></td><td style=\'padding:6px 8px;\'>am2825698@gmail.com</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Address:</strong></td><td style=\'padding:6px 8px;\'>College Road Tanki, Jamke Road Daska, Daska, Punjab</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Payment:</strong></td><td style=\'padding:6px 8px;\'>HBL</td></tr>\n        </table>\n        <table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">PEARLS &amp; PETALS<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">INITIALÉ DISCOVERY SET<br><span style=\"font-size:12px;color:#777;\">5 × 5ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 1,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 6,230</p>\n      </div>', 'New order #VRD-260904-8A2D from Muhammad Awais (+923279897083) - Rs. 6,230', 'sent', 1, '', '2026-09-04 01:42:06', '2026-09-04 06:42:17'),
(6, 7, 'am2825698@gmail.com', 'Muhammad Awais', 'Order Placed — #VRD-260904-B2F4 — Verdeur.pk', '\n        <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n          <h2 style=\'color:#111;\'>Thank you for your order, Muhammad Awais!</h2>\n          <p>Your order <strong>#VRD-260904-B2F4</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>\n          <div style=\'background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;\'><table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">INITIALÉ DISCOVERY SET<br><span style=\"font-size:12px;color:#777;\">5 × 5ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 1,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 2,240</p></div>\n          <p>You have chosen <strong>Bank Transfer</strong>. Please complete your payment to the bank account shown on our website.</p>\n          <p style=\'font-weight:bold;margin-top:18px;\'>Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.</p>\n          <p style=\'color:#777;font-size:13px;\'>If you have any other questions, reply to this email or contact us.</p>\n          <p style=\'color:#777;font-size:13px;\'>Best regards,<br>Verdeur.pk Team</p>\n        </div>', 'Your order #VRD-260904-B2F4 has been placed. Total: Rs. 2,240. Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.', 'sent', 1, '', '2026-09-04 01:43:42', '2026-09-04 06:43:48'),
(7, 7, 'verdeurfragrances@gmail.com', 'Verdeur Admin', 'New Order #VRD-260904-B2F4 — Verdeur.pk', '\n      <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n        <h2 style=\'color:#111;\'>New Order #VRD-260904-B2F4</h2>\n        <table style=\'width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;\'>\n          <tr><td style=\'padding:6px 8px;\'><strong>Customer:</strong></td><td style=\'padding:6px 8px;\'>Muhammad Awais</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Phone:</strong></td><td style=\'padding:6px 8px;\'>+923279897083</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Email:</strong></td><td style=\'padding:6px 8px;\'>am2825698@gmail.com</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Address:</strong></td><td style=\'padding:6px 8px;\'>College Road Tanki, Jamke Road Daska, Daska, Punjab</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Payment:</strong></td><td style=\'padding:6px 8px;\'>HBL</td></tr>\n        </table>\n        <table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">INITIALÉ DISCOVERY SET<br><span style=\"font-size:12px;color:#777;\">5 × 5ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 1,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 2,240</p>\n      </div>', 'New order #VRD-260904-B2F4 from Muhammad Awais (+923279897083) - Rs. 2,240', 'sent', 1, '', '2026-09-04 01:43:42', '2026-09-04 06:43:53'),
(8, 8, 'am2825698@gmail.com', 'Muhammad Awais', 'Order Placed — #VRD-260904-4667 — Verdeur.pk', '\n        <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n          <h2 style=\'color:#111;\'>Thank you for your order, Muhammad Awais!</h2>\n          <p>Your order <strong>#VRD-260904-4667</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>\n          <div style=\'background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;\'><table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">INITIALÉ DISCOVERY SET<br><span style=\"font-size:12px;color:#777;\">5 × 5ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 1,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 6,230</p></div>\n          <p>You have chosen <strong>Bank Transfer</strong>. Please complete your payment to the bank account shown on our website.</p>\n          <p style=\'font-weight:bold;margin-top:18px;\'>Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.</p>\n          <p style=\'color:#777;font-size:13px;\'>If you have any other questions, reply to this email or contact us.</p>\n          <p style=\'color:#777;font-size:13px;\'>Best regards,<br>Verdeur.pk Team</p>\n        </div>', 'Your order #VRD-260904-4667 has been placed. Total: Rs. 6,230. Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.', 'sent', 1, '', '2026-09-04 01:54:04', '2026-09-04 06:54:09'),
(9, 8, 'verdeurfragrances@gmail.com', 'Verdeur Admin', 'New Order #VRD-260904-4667 — Verdeur.pk', '\n      <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n        <h2 style=\'color:#111;\'>New Order #VRD-260904-4667</h2>\n        <table style=\'width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;\'>\n          <tr><td style=\'padding:6px 8px;\'><strong>Customer:</strong></td><td style=\'padding:6px 8px;\'>Muhammad Awais</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Phone:</strong></td><td style=\'padding:6px 8px;\'>+923279897083</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Email:</strong></td><td style=\'padding:6px 8px;\'>am2825698@gmail.com</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Address:</strong></td><td style=\'padding:6px 8px;\'>College Road Tanki, Jamke Road Daska, Daska, Punjab</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Payment:</strong></td><td style=\'padding:6px 8px;\'>HBL</td></tr>\n        </table>\n        <table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">INITIALÉ DISCOVERY SET<br><span style=\"font-size:12px;color:#777;\">5 × 5ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 1,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 6,230</p>\n      </div>', 'New order #VRD-260904-4667 from Muhammad Awais (+923279897083) - Rs. 6,230', 'sent', 1, '', '2026-09-04 01:54:04', '2026-09-04 06:54:14'),
(10, 9, 'am2825698@gmail.com', 'Muhammad Awais', 'Order Placed — #VRD-260904-8CAD — Verdeur.pk', '\n        <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n          <h2 style=\'color:#111;\'>Thank you for your order, Muhammad Awais!</h2>\n          <p>Your order <strong>#VRD-260904-8CAD</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>\n          <div style=\'background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;\'><table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">MUSC AFFAIR<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 8,230</p></div>\n          <p>You have chosen <strong>Bank Transfer</strong>. Please complete your payment to the bank account shown on our website.</p>\n          <p style=\'font-weight:bold;margin-top:18px;\'>Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.</p>\n          <p style=\'color:#777;font-size:13px;\'>If you have any other questions, reply to this email or contact us.</p>\n          <p style=\'color:#777;font-size:13px;\'>Best regards,<br>Verdeur.pk Team</p>\n        </div>', 'Your order #VRD-260904-8CAD has been placed. Total: Rs. 8,230. Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.', 'sent', 1, '', '2026-09-04 01:56:13', '2026-09-04 06:56:18'),
(11, 9, 'verdeurfragrances@gmail.com', 'Verdeur Admin', 'New Order #VRD-260904-8CAD — Verdeur.pk', '\n      <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n        <h2 style=\'color:#111;\'>New Order #VRD-260904-8CAD</h2>\n        <table style=\'width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;\'>\n          <tr><td style=\'padding:6px 8px;\'><strong>Customer:</strong></td><td style=\'padding:6px 8px;\'>Muhammad Awais</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Phone:</strong></td><td style=\'padding:6px 8px;\'>+923279897083</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Email:</strong></td><td style=\'padding:6px 8px;\'>am2825698@gmail.com</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Address:</strong></td><td style=\'padding:6px 8px;\'>College Road Tanki, Jamke Road Daska, Daska, Punjab</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Payment:</strong></td><td style=\'padding:6px 8px;\'>HBL</td></tr>\n        </table>\n        <table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">MUSC AFFAIR<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 8,230</p>\n      </div>', 'New order #VRD-260904-8CAD from Muhammad Awais (+923279897083) - Rs. 8,230', 'sent', 1, '', '2026-09-04 01:56:13', '2026-09-04 06:56:23'),
(12, 10, 'am2825698@gmail.com', 'Muhammad Awais', 'Order Placed — #VRD-260905-3746 — Verdeur.pk', '\n        <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n          <h2 style=\'color:#111;\'>Thank you for your order, Muhammad Awais!</h2>\n          <p>Your order <strong>#VRD-260905-3746</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>\n          <div style=\'background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;\'><table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 4,240</p></div>\n          <p>You have chosen <strong>Cash on Delivery</strong>. Please keep the total amount ready at the time of delivery.</p>\n          <p style=\'font-weight:bold;margin-top:18px;\'>Please confirm: should we proceed with delivering your order to the address you provided?</p>\n          <p style=\'color:#777;font-size:13px;\'>If you have any other questions, reply to this email or contact us.</p>\n          <p style=\'color:#777;font-size:13px;\'>Best regards,<br>Verdeur.pk Team</p>\n        </div>', 'Your order #VRD-260905-3746 has been placed. Total: Rs. 4,240. Please confirm: should we proceed with delivering your order to the address you provided?', 'sent', 1, '', '2026-09-05 03:07:59', '2026-09-05 08:08:06'),
(13, 10, 'verdeurfragrances@gmail.com', 'Verdeur Admin', 'New Order #VRD-260905-3746 — Verdeur.pk', '\n      <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n        <h2 style=\'color:#111;\'>New Order #VRD-260905-3746</h2>\n        <table style=\'width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;\'>\n          <tr><td style=\'padding:6px 8px;\'><strong>Customer:</strong></td><td style=\'padding:6px 8px;\'>Muhammad Awais</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Phone:</strong></td><td style=\'padding:6px 8px;\'>+923279897083</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Email:</strong></td><td style=\'padding:6px 8px;\'>am2825698@gmail.com</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Address:</strong></td><td style=\'padding:6px 8px;\'>College Road Tanki, Jamke Road Daska, Daska, Punjab</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Payment:</strong></td><td style=\'padding:6px 8px;\'>Cash on Delivery</td></tr>\n        </table>\n        <table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 4,240</p>\n      </div>', 'New order #VRD-260905-3746 from Muhammad Awais (+923279897083) - Rs. 4,240', 'sent', 1, '', '2026-09-05 03:07:59', '2026-09-05 08:08:13'),
(14, 11, 'am2825698@gmail.com', 'Muhammad Awais', 'Order Placed — #VRD-260907-CD5E — Verdeur.pk', '\n        <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n          <h2 style=\'color:#111;\'>Thank you for your order, Muhammad Awais!</h2>\n          <p>Your order <strong>#VRD-260907-CD5E</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>\n          <div style=\'background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;\'><table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x2</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 7,980</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">MUSC AFFAIR<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 12,220</p></div>\n          <p>You have chosen <strong>Bank Transfer</strong>. Please complete your payment to the bank account shown on our website.</p>\n          <p style=\'font-weight:bold;margin-top:18px;\'>Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.</p>\n          <p style=\'color:#777;font-size:13px;\'>If you have any other questions, reply to this email or contact us.</p>\n          <p style=\'color:#777;font-size:13px;\'>Best regards,<br>Verdeur.pk Team</p>\n        </div>', 'Your order #VRD-260907-CD5E has been placed. Total: Rs. 12,220. Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.', 'sent', 1, '', '2026-09-07 04:18:17', '2026-09-07 09:18:24'),
(15, 11, 'verdeurfragrances@gmail.com', 'Verdeur Admin', 'New Order #VRD-260907-CD5E — Verdeur.pk', '\n      <div style=\'font-family:Arial,sans-serif;max-width:600px;margin:0 auto;\'>\n        <h2 style=\'color:#111;\'>New Order #VRD-260907-CD5E</h2>\n        <table style=\'width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;\'>\n          <tr><td style=\'padding:6px 8px;\'><strong>Customer:</strong></td><td style=\'padding:6px 8px;\'>Muhammad Awais</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Phone:</strong></td><td style=\'padding:6px 8px;\'>+923279897083</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Email:</strong></td><td style=\'padding:6px 8px;\'>am2825698@gmail.com</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Address:</strong></td><td style=\'padding:6px 8px;\'>College Road Tanki, Jamke Road Daska, Daska, Punjab</td></tr>\n          <tr><td style=\'padding:6px 8px;\'><strong>Payment:</strong></td><td style=\'padding:6px 8px;\'>HBL</td></tr>\n        </table>\n        <table style=\"width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;\"><thead><tr><th style=\"text-align:left;padding:8px 10px;background:#f7f7f7;\">Item</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:center;\">Qty</th><th style=\"padding:8px 10px;background:#f7f7f7;text-align:right;\">Amount</th></tr></thead><tbody><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">NEXT CHAPTER<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x2</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 7,980</td></tr><tr><td style=\"padding:8px 10px;border-bottom:1px solid #eee;\">MUSC AFFAIR<br><span style=\"font-size:12px;color:#777;\">50ml · Extrait de Parfum</span></td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:center;\">x1</td><td style=\"padding:8px 10px;border-bottom:1px solid #eee;text-align:right;\">Rs. 3,990</td></tr></tbody></table><p style=\"text-align:right;font-weight:bold;font-size:15px;\">Total: Rs. 12,220</p>\n      </div>', 'New order #VRD-260907-CD5E from Muhammad Awais (+923279897083) - Rs. 12,220', 'sent', 1, '', '2026-09-07 04:18:17', '2026-09-07 09:18:30');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(80) NOT NULL,
  `collection_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `expression` varchar(120) NOT NULL DEFAULT '',
  `price` int(11) NOT NULL DEFAULT 0,
  `image` varchar(200) NOT NULL DEFAULT '',
  `meta` varchar(120) NOT NULL DEFAULT '',
  `family` varchar(80) NOT NULL DEFAULT '',
  `best_for` varchar(255) NOT NULL DEFAULT '',
  `top_notes` text NOT NULL,
  `heart_notes` text NOT NULL,
  `base_notes` text NOT NULL,
  `home_description` varchar(255) NOT NULL DEFAULT '',
  `conclusion` text NOT NULL,
  `accent` varchar(12) NOT NULL DEFAULT '#000000',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `slug`, `collection_id`, `name`, `expression`, `price`, `image`, `meta`, `family`, `best_for`, `top_notes`, `heart_notes`, `base_notes`, `home_description`, `conclusion`, `accent`, `featured`, `sort_order`, `is_active`) VALUES
(1, 'pearls-and-petals', 1, 'PEARLS & PETALS', 'Refined Softness', 3990, 'assets/images/pp.webp', '50ml · Extrait de Parfum', 'Floral Fruity', 'Daytime, Social occasions, Elegant everyday wear', 'Pineapple, Bergamot, Lychee, Jasmine, Pink Pepper', 'Turkish Rose, Mirabelle Plum, Gardenia, Oakmoss, Freesia', 'Vanilla, Sandalwood, Amber, Musk', 'A delicate expression shaped around softness, elegance and quiet presence.', 'A composition where luminous fruit, unfolding florals and a soft warm base come together as an expression of elegance, tenderness and refined softness.', '#b44260', 1, 1, 1),
(2, 'next-chapter', 1, 'NEXT CHAPTER', 'New Beginnings', 3990, 'assets/images/nc.webp', '50ml · Extrait de Parfum', 'Fresh Aquatic', 'Daily wear, Office, Meetings, Professional environments', 'Bergamot, Grapefruit, Mandarin Orange, Marine Accords', 'Sage, Lavender, Geranium, Rosemary', 'Amberwood, Patchouli, Vetiver, Musk', 'A fresh expression of clarity, confidence and moving forward.', 'Next Chapter moves from brightness to composure and finally into grounded depth — an olfactory expression of transition, clarity and the confidence to move forward.', '#173968', 1, 2, 1),
(3, 'solitaire', 1, 'SOLITAIRE', 'Distinctive Presence', 3990, 'assets/images/st.webp', '50ml · Extrait de Parfum', 'Woody Amber', 'Evening wear, Formal occasions, Special gatherings, Signature scent seekers', 'Lavender, Cardamom, Pepper, Sweet Accords, Saffron', 'Cinnamon, Smoky Accords, Soft Florals, Patchouli, Nutmeg', 'Vanilla, Amber, Musk, Tonka Bean, Fir Resin, Cedarwood', 'An expression of individuality, character and presence without excess.', 'Solitaire expresses distinctive presence through a rich, warm composition where spices, woods, amber and sweetness create depth, individuality and a memorable olfactory signature.', '#b18a4d', 1, 3, 1),
(4, 'musc-affair', 1, 'MUSC AFFAIR', 'Intimacy', 3990, 'assets/images/ma.webp', '50ml · Extrait de Parfum', 'Musk Floral', 'Close encounters, Evening wear, Personal signature scent', 'Lily of the Valley, White Flowers, Creamy Accents', 'Powdery Vanilla, Musk', 'Sandalwood, Amber', 'A close and enveloping expression shaped around warmth and intimacy.', 'Musc Affair expresses intimacy through a soft musk composition where clean florals, powdery warmth and smooth woods create a fragrance that feels close, comforting and personal.', '#9d9fa5', 1, 4, 1),
(5, 'rhythm-of-sandal', 1, 'RHYTHM OF SANDAL', 'Stillness', 3990, 'assets/images/rs.webp', '50ml · Extrait de Parfum', 'Woody', 'Relaxed moments, Evening wear, Sandalwood lovers', 'Subtle Spice, Fresh Woods', 'Creamy Sandalwood, Soft Floral Nuances', 'Amber, Dry Woods, Musk', 'A calm expression built around warmth, balance and quiet stillness.', 'Rhythm of Sandal expresses stillness through the timeless character of sandalwood. Its creamy warmth and smooth woody depth create a sense of balance, comfort and quiet reflection.', '#725b45', 1, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_stories`
--

CREATE TABLE `product_stories` (
  `story_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `chapter_no` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `kicker` varchar(60) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `copy` text NOT NULL,
  `image` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_stories`
--

INSERT INTO `product_stories` (`story_id`, `product_id`, `chapter_no`, `kicker`, `title`, `copy`, `image`) VALUES
(1, 1, 1, '01 / The Opening', 'A BRIGHT SOFTNESS', 'Pineapple, bergamot and lychee bring a luminous fruitiness to the opening, while jasmine and pink pepper introduce a delicate floral lift and subtle contrast.', 'assets/images/nc-opening.webp'),
(2, 1, 2, '02 / The Heart', 'PETALS IN BLOOM', 'Turkish rose, gardenia and freesia unfold through the heart, softened by the delicate fruitiness of Mirabelle plum. Oakmoss adds quiet depth beneath the floral composition.', 'assets/images/nc-heart.webp'),
(3, 1, 3, '03 / The Drydown', 'SOFTLY GROUNDED', 'Vanilla and sandalwood soften the composition as it settles, while amber and musk create a smooth, warm foundation that keeps the fragrance refined and close.', 'assets/images/nc-base.webp'),
(4, 2, 1, '01 / The Opening', 'CLARITY IN MOTION', 'Bergamot, grapefruit and mandarin open the fragrance with brightness and energy. Marine accords move through the citrus, bringing an airy freshness that feels clear, open and immediately alive.', 'assets/images/nc-opening.webp'),
(5, 2, 2, '02 / The Heart', 'AROMATIC COMPOSURE', 'Sage, lavender, geranium and rosemary shape the heart with a clean aromatic structure. The freshness becomes more composed here — confident and polished without becoming rigid.', 'assets/images/nc-heart.webp'),
(6, 2, 3, '03 / The Drydown', 'GROUNDED FORWARD', 'Amberwood, patchouli and vetiver give the fragrance depth and direction, while musk smooths the composition. What begins with movement settles into a grounded, confident presence.', 'assets/images/nc-base.webp'),
(7, 3, 1, '01 / The Opening', 'SPICED CERTAINTY', 'Lavender introduces an aromatic freshness before cardamom, pepper and saffron begin to build warmth and character. Sweet accords soften the edges, creating an opening that feels confident without needing to be loud.', 'assets/images/nc-opening.webp'),
(8, 3, 2, '02 / The Heart', 'WARMTH WITH DEPTH', 'Cinnamon and nutmeg deepen the spice as smoky accords move through soft florals and patchouli. The fragrance becomes warmer, richer and more distinctive, carrying a composed sense of presence.', 'assets/images/nc-heart.webp'),
(9, 3, 3, '03 / The Drydown', 'A LASTING SIGNATURE', 'Vanilla, amber and tonka bean bring smooth sweetness into the drydown, while cedarwood, fir resin and musk create a warm woody foundation. What remains is rich, velvety and quietly memorable.', 'assets/images/nc-base.webp'),
(10, 4, 1, '01 / The Opening', 'QUIET CLOSENESS', 'Lily of the valley and white flowers open with a clean, delicate softness. Creamy accents begin to round the composition, creating an immediate sense of warmth and familiarity.', 'assets/images/nc-opening.webp'),
(11, 4, 2, '02 / The Heart', 'SOFTLY PERSONAL', 'Powdery vanilla blends into musk at the heart, giving the fragrance its velvety and intimate character. The composition stays soft and personal, drawing closer rather than projecting outward.', 'assets/images/nc-heart.webp'),
(12, 4, 3, '03 / The Drydown', 'WARMTH THAT LINGERS', 'Sandalwood and amber settle beneath the musk, adding creamy warmth and smooth depth. The drydown remains comforting, understated and close to the skin.', 'assets/images/nc-base.webp'),
(13, 5, 1, '01 / The Opening', 'A QUIET BEGINNING', 'Subtle spice meets fresh woods in an opening that feels restrained and composed. Rather than demanding attention, the fragrance begins with a soft sense of space and calm.', 'assets/images/nc-opening.webp'),
(14, 5, 2, '02 / The Heart', 'CREAMY STILLNESS', 'Creamy sandalwood becomes the center of the composition, softened by delicate floral nuances. The texture turns smooth and comforting, creating a warm sense of balance and quiet presence.', 'assets/images/nc-heart.webp'),
(15, 5, 3, '03 / The Drydown', 'GROUNDED CALM', 'Amber, dry woods and musk settle beneath the sandalwood, giving the fragrance a warm and grounded finish. The drydown remains soft, woody and quietly reflective.', 'assets/images/nc-base.webp');

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE `site_settings` (
  `setting_id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`setting_id`, `setting_key`, `setting_value`, `is_active`) VALUES
(1, 'site_name', 'Verdeur', 1),
(2, 'site_tagline', 'Scent, expressed as something more.', 1),
(3, 'shipping_charge', '250', 1),
(4, 'free_shipping_above', '0', 1),
(5, 'contact_email', 'hello@verdeur.com', 1),
(6, 'contact_phone', '+92 304 1461111', 1),
(7, 'whatsapp_number', '923041461111', 1),
(8, 'whatsapp_message', 'Hi Verdeur%2C%20I%20would%20like%20to%20know%20more%20about%20your%20fragrances.', 1),
(9, 'social_facebook', 'https://www.facebook.com/verdeurofficial', 1),
(10, 'social_instagram', 'https://www.instagram.com/verdeurofficial', 1),
(11, 'social_tiktok', 'https://www.tiktok.com/@verdeurofficial', 1),
(12, 'copyright_text', '© 2026 Verdeur. All rights reserved.', 1),
(13, 'footer_brand_copy', 'Independent fragrance house. Scent, expressed as something more.', 1),
(17, 'contact_whatsapp', '+92 304 1461111', 1),
(18, 'contact_address', 'Lahore, Pakistan', 1),
(19, 'allow_cod', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tester_sets`
--

CREATE TABLE `tester_sets` (
  `set_id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(80) NOT NULL,
  `name` varchar(120) NOT NULL,
  `subtitle` varchar(180) NOT NULL DEFAULT '',
  `card_subtitle` varchar(180) NOT NULL DEFAULT '',
  `price` int(11) NOT NULL DEFAULT 0,
  `image` varchar(200) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `olfactory_intro` text NOT NULL,
  `includes` varchar(120) NOT NULL DEFAULT '',
  `collection_id` int(10) UNSIGNED DEFAULT NULL,
  `collection` varchar(80) NOT NULL DEFAULT '',
  `concentration` varchar(80) NOT NULL DEFAULT '',
  `size_label` varchar(60) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tester_sets`
--

INSERT INTO `tester_sets` (`set_id`, `slug`, `name`, `subtitle`, `card_subtitle`, `price`, `image`, `intro`, `olfactory_intro`, `includes`, `collection_id`, `collection`, `concentration`, `size_label`, `sort_order`, `is_active`) VALUES
(1, 'Initiale-set', 'INITIALÉ DISCOVERY SET', 'Five expressions. One introduction.', 'Five expressions · 5 × 5ml', 1990, 'assets/images/tester_bottles.webp', 'Experience all five fragrances from Initialé before choosing the expression that feels most like your own.', 'Five distinct scent directions. Compare their olfactory character and discover which expression feels closest to you.', '5 × 5ml fragrances', 1, 'Initialé', 'Extrait de Parfum', '5 × 5ml', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tester_set_items`
--

CREATE TABLE `tester_set_items` (
  `item_id` int(10) UNSIGNED NOT NULL,
  `set_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tester_set_items`
--

INSERT INTO `tester_set_items` (`item_id`, `set_id`, `product_id`, `position`) VALUES
(29, 1, 1, 1),
(30, 1, 2, 2),
(31, 1, 3, 3),
(32, 1, 4, 4),
(33, 1, 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `testimonial_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `customer_name` varchar(120) NOT NULL,
  `quote` text NOT NULL,
  `label` varchar(120) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`testimonial_id`, `product_id`, `customer_name`, `quote`, `label`, `sort_order`, `is_active`, `created_at`) VALUES
(1, 2, 'Ahmed R.', 'Fresh, clean and very easy to wear. I especially liked how it stayed noticeable without becoming too heavy.', '', 1, 1, '2026-09-02 06:21:49'),
(2, 1, 'Ayesha K.', 'It feels soft and polished rather than overly sweet. Very feminine, but still elegant and easy to wear.', '', 2, 1, '2026-09-02 06:21:49'),
(3, 3, 'Hamza M.', 'Different from the usual fresh perfumes I wear. It has a strong personality and feels more mature on skin.', '', 3, 1, '2026-09-02 06:21:49'),
(4, 4, 'Sana A.', 'Warm, smooth and close to the skin in a very comforting way. It feels intimate without becoming too dense.', '', 4, 1, '2026-09-02 06:21:49'),
(5, 5, 'Ali H.', 'The sandalwood feels creamy and calm. I liked how soft and balanced it became after settling on the skin.', '', 5, 1, '2026-09-02 06:21:49'),
(6, NULL, 'Mariam S.', 'The Discovery Set made choosing much easier. Testing all five properly helped me understand which one suited me best.', 'Initialé Discovery Set', 6, 1, '2026-09-02 06:21:49'),
(7, 2, 'Usman F.', 'Received Next Chapter as a gift first and ended up looking for it again when the bottle was almost finished.', '', 7, 1, '2026-09-02 06:21:49'),
(8, 1, 'Hira N.', 'Very smooth floral fragrance. It feels refined and wearable, especially when I want something soft but noticeable.', '', 8, 1, '2026-09-02 06:21:49'),
(9, 3, 'Bilal A.', 'It develops really well after the opening. The drydown has a distinctive character that stays with you.', '', 9, 1, '2026-09-02 06:21:49'),
(10, 4, 'Zainab R.', 'It has a clean musky warmth that feels very personal. One of those fragrances you keep noticing throughout the day.', '', 10, 1, '2026-09-02 06:21:49'),
(11, 5, 'Farhan K.', 'Comforting and understated. The sandalwood gives it warmth without making it feel old-fashioned or too heavy.', '', 11, 1, '2026-09-02 06:21:49'),
(12, NULL, 'Noor M.', 'What stood out for me was that the fragrances felt different from each other rather than like variations of the same scent.', 'Verdeur', 12, 1, '2026-09-02 06:21:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `uq_admin_username` (`username`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `collections`
--
ALTER TABLE `collections`
  ADD PRIMARY KEY (`collection_id`),
  ADD UNIQUE KEY `uq_collections_slug` (`slug`);

--
-- Indexes for table `customer_queries`
--
ALTER TABLE `customer_queries`
  ADD PRIMARY KEY (`query_id`),
  ADD KEY `idx_queries_read` (`is_read`);

--
-- Indexes for table `legal_pages`
--
ALTER TABLE `legal_pages`
  ADD PRIMARY KEY (`page_id`),
  ADD UNIQUE KEY `uq_legal_pages_slug` (`slug`);

--
-- Indexes for table `newsletter_subscribers`
--
ALTER TABLE `newsletter_subscribers`
  ADD PRIMARY KEY (`subscriber_id`),
  ADD UNIQUE KEY `uq_subscribers_email` (`email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `uq_orders_number` (`order_number`),
  ADD KEY `idx_orders_order_status` (`order_status`),
  ADD KEY `idx_orders_payment_status` (`payment_status`),
  ADD KEY `idx_orders_bank` (`bank_account_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `idx_order_items_order` (`order_id`),
  ADD KEY `idx_order_items_product` (`product_id`);

--
-- Indexes for table `order_rate_limits`
--
ALTER TABLE `order_rate_limits`
  ADD PRIMARY KEY (`rl_key`);

--
-- Indexes for table `pending_emails`
--
ALTER TABLE `pending_emails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `uq_products_slug` (`slug`),
  ADD KEY `idx_products_collection` (`collection_id`);

--
-- Indexes for table `product_stories`
--
ALTER TABLE `product_stories`
  ADD PRIMARY KEY (`story_id`),
  ADD KEY `idx_stories_product` (`product_id`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `uq_settings_key` (`setting_key`);

--
-- Indexes for table `tester_sets`
--
ALTER TABLE `tester_sets`
  ADD PRIMARY KEY (`set_id`),
  ADD UNIQUE KEY `uq_tester_sets_slug` (`slug`);

--
-- Indexes for table `tester_set_items`
--
ALTER TABLE `tester_set_items`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `uq_set_product` (`set_id`,`product_id`),
  ADD KEY `idx_set_items_product` (`product_id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`testimonial_id`),
  ADD KEY `idx_testimonials_product` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `account_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `collections`
--
ALTER TABLE `collections`
  MODIFY `collection_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer_queries`
--
ALTER TABLE `customer_queries`
  MODIFY `query_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `legal_pages`
--
ALTER TABLE `legal_pages`
  MODIFY `page_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `newsletter_subscribers`
--
ALTER TABLE `newsletter_subscribers`
  MODIFY `subscriber_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `pending_emails`
--
ALTER TABLE `pending_emails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `product_stories`
--
ALTER TABLE `product_stories`
  MODIFY `story_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `setting_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=194;

--
-- AUTO_INCREMENT for table `tester_sets`
--
ALTER TABLE `tester_sets`
  MODIFY `set_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tester_set_items`
--
ALTER TABLE `tester_set_items`
  MODIFY `item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `testimonial_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_bank` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`account_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_collection` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`collection_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_stories`
--
ALTER TABLE `product_stories`
  ADD CONSTRAINT `fk_stories_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tester_set_items`
--
ALTER TABLE `tester_set_items`
  ADD CONSTRAINT `fk_set_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_set_items_set` FOREIGN KEY (`set_id`) REFERENCES `tester_sets` (`set_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD CONSTRAINT `fk_testimonials_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
