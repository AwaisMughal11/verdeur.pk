﻿<?php

$pageTitle = 'Initialé — Verdeur';
include('includes/header.php');
?>




  <main>

    
    <main class="osp-page">

  <!-- =========================================
       INTRODUCTION
  ========================================== -->

  <section class="osp-intro">

    <div class="osp-intro-inner">

      <h1 class="osp-intro-title">
        <strong>VERDEUR</strong> — A French word for greenness and vitality,<br class="osp-desktop-break">
        carrying a sense of freshness and vigor.
      </h1>

      <p class="osp-intro-copy">
        Verdeur is an independent fragrance house devoted to the
        expressive possibilities of scent. We see perfume not simply
        as something worn, but as something with the power to carry
        character, feeling and presence.
      </p>

    </div>

  </section>


  <!-- =========================================
       STORY CHAPTERS
  ========================================== -->

  <section class="osp-chapters">

    <div class="osp-chapters-inner">


      <!-- =====================================
           01 — THE SILENT CONVERSATION
      ====================================== -->

      <article class="osp-chapter">

        <div class="osp-image-wrap">

          <img
            src="assets/images/sc.webp"
            alt="The Silent Conversation"
            class="osp-image"
            loading="lazy"
            decoding="async"
          >

        </div>


        <div class="osp-content">

          <p class="osp-number">
            01
          </p>

          <h2 class="osp-title">
            The Silent Conversation
          </h2>

          <p class="osp-lead">
            Some things are understood without ever being said.
          </p>

          <p class="osp-copy">
            Scent can create an impression, awaken a feeling and remain
            in memory without using a single word. At Verdeur, we call
            this The Silent Conversation — a silent exchange carried
            through scent.
          </p>

        </div>

      </article>



      <!-- =====================================
           02 — PERFUME, FIRST.
      ====================================== -->

      <article class="osp-chapter osp-chapter-reverse">

        <div class="osp-image-wrap">

          <img
            src="assets/images/pf1.webp"
            alt="Perfume, First."
            class="osp-image"
            loading="lazy"
            decoding="async"
          >

        </div>


        <div class="osp-content">

          <p class="osp-number">
            02
          </p>

          <h2 class="osp-title">
            Perfume, First.
          </h2>

          <p class="osp-lead">
            Every fragrance begins with the way it feels.
          </p>

          <p class="osp-copy">
            Its freshness, warmth, depth, softness or presence gives
            it character. From there, an idea begins to take shape.
            At Verdeur, story is not placed over the fragrance —
            it grows from what the scent itself communicates.
          </p>

        </div>

      </article>



      <!-- =====================================
           03 — AN EXPRESSION OF ITS OWN
      ====================================== -->

      <article class="osp-chapter">

        <div class="osp-image-wrap">

          <img
            src="assets/images/eo.webp"
            alt="An Expression of Its Own"
            class="osp-image"
            loading="lazy"
            decoding="async"
          >

        </div>


        <div class="osp-content">

          <p class="osp-number">
            03
          </p>

          <h2 class="osp-title">
            An Expression of Its Own
          </h2>

          <p class="osp-lead">
            No two fragrances need to say the same thing.
          </p>

          <p class="osp-copy">
            Each Verdeur fragrance carries a character of its own —
            distinct in mood, presence and the impression it leaves
            behind.
          </p>

          <p class="osp-closing">
            Different expressions.<br>
            One language: scent.
          </p>

        </div>

      </article>


    </div>

  </section>

</main>
 
  </main>

  <!-- =========================================
     10 — FOOTER
========================================== -->

<?php include('includes/footer.php'); ?>
