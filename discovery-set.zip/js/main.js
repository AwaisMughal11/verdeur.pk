﻿/* =========================================
   VERDEUR HOMEPAGE — FINAL V1
========================================= */

/* =========================================
   MOBILE NAVIGATION
========================================= */
const header = document.querySelector(".site-header");
const menuToggle = document.querySelector(".menu-toggle");
const mobileNav = document.querySelector(".mobile-nav");

if (header && menuToggle && mobileNav) {
  const setMenuState = (isOpen) => {
    header.classList.toggle("menu-open", isOpen);
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute(
      "aria-label",
      isOpen ? "Close navigation" : "Open navigation"
    );
    document.body.style.overflow = isOpen ? "hidden" : "";
  };

  menuToggle.addEventListener("click", () => {
    setMenuState(!header.classList.contains("menu-open"));
  });

  mobileNav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => setMenuState(false));
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && header.classList.contains("menu-open")) {
      setMenuState(false);
      menuToggle.focus();
    }
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth > 900 && header.classList.contains("menu-open")) {
      setMenuState(false);
    }
  });
}

/* =========================================
   STICKY HEADER — SCROLL STATE (HOMEPAGE)
========================================= */
const siteHeader = document.querySelector(".site-header");

if (siteHeader && !siteHeader.classList.contains("page-header")) {
  const updateHeaderState = () => {
    siteHeader.classList.toggle("is-scrolled", window.scrollY > 30);
  };

  updateHeaderState();
  window.addEventListener("scroll", updateHeaderState, { passive: true });
}

/* =========================================
   NAV DROPDOWN — HEADER EXPANSION PANEL
   Measures the dropdown so the white panel
   (.site-header::after) matches its height.
========================================= */
const navHeaderEl = document.querySelector(".site-header");
const navDropdownEl = navHeaderEl?.querySelector(".nav-dropdown");

if (navHeaderEl && navDropdownEl) {
  const syncNavDropdownH = () => {
    const headerRect = navHeaderEl.getBoundingClientRect();
    const dropdownRect = navDropdownEl.getBoundingClientRect();
    const height = Math.max(0, dropdownRect.bottom + 5 - headerRect.bottom + 4);
    navHeaderEl.style.setProperty("--nav-dd-h", `${height}px`);
  };

  syncNavDropdownH();
  window.addEventListener("resize", syncNavDropdownH);
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(syncNavDropdownH);
  }
}

/* =========================================
   CLIENT IMPRESSIONS CAROUSEL
========================================= */
const reviewsSection = document.querySelector(".reviews-section");

if (reviewsSection) {
  const viewport = reviewsSection.querySelector(".reviews-viewport");
  const track = reviewsSection.querySelector(".reviews-track");
  const cards = Array.from(reviewsSection.querySelectorAll(".review-card"));
  const prevButton = reviewsSection.querySelector(".reviews-arrow-prev");
  const nextButton = reviewsSection.querySelector(".reviews-arrow-next");
  const dotsContainer = reviewsSection.querySelector(".reviews-dots");
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

  let currentIndex = 0;
  let autoPlayTimer = null;
  let touchStartX = 0;
  let resizeTimer = null;

  const getVisibleCards = () => {
    if (window.innerWidth <= 767) return 1;
    if (window.innerWidth <= 1100) return 2;
    return 3;
  };

  const getMaxIndex = () => Math.max(0, cards.length - getVisibleCards());

  const getStepWidth = () => {
    if (cards.length > 1) {
      return cards[1].offsetLeft - cards[0].offsetLeft;
    }
    return cards[0]?.getBoundingClientRect().width || 0;
  };

  const updateDots = () => {
    if (!dotsContainer) return;

    dotsContainer.querySelectorAll(".review-dot").forEach((dot, index) => {
      const isActive = index === currentIndex;
      dot.classList.toggle("active", isActive);
      dot.setAttribute("aria-current", isActive ? "true" : "false");
    });
  };

  const updateSlider = () => {
    if (!track || cards.length === 0) return;

    currentIndex = Math.min(Math.max(currentIndex, 0), getMaxIndex());
    track.style.transform = `translateX(-${currentIndex * getStepWidth()}px)`;
    updateDots();
  };

  const createDots = () => {
    if (!dotsContainer) return;

    dotsContainer.innerHTML = "";
    const totalPositions = getMaxIndex() + 1;

    for (let i = 0; i < totalPositions; i += 1) {
      const dot = document.createElement("button");
      dot.type = "button";
      dot.className = "review-dot";
      dot.setAttribute("aria-label", `Show review position ${i + 1}`);

      dot.addEventListener("click", () => {
        currentIndex = i;
        updateSlider();
        restartAutoPlay();
      });

      dotsContainer.appendChild(dot);
    }
  };

  const goNext = () => {
    currentIndex = currentIndex >= getMaxIndex() ? 0 : currentIndex + 1;
    updateSlider();
  };

  const goPrevious = () => {
    currentIndex = currentIndex <= 0 ? getMaxIndex() : currentIndex - 1;
    updateSlider();
  };

  const stopAutoPlay = () => {
    if (autoPlayTimer !== null) {
      window.clearInterval(autoPlayTimer);
      autoPlayTimer = null;
    }
  };

  const startAutoPlay = () => {
    stopAutoPlay();

    if (reduceMotion.matches || document.hidden || cards.length <= getVisibleCards()) {
      return;
    }

    autoPlayTimer = window.setInterval(goNext, 7000);
  };

  const restartAutoPlay = () => {
    stopAutoPlay();
    startAutoPlay();
  };

  prevButton?.addEventListener("click", () => {
    goPrevious();
    restartAutoPlay();
  });

  nextButton?.addEventListener("click", () => {
    goNext();
    restartAutoPlay();
  });

  reviewsSection.addEventListener("mouseenter", stopAutoPlay);
  reviewsSection.addEventListener("mouseleave", startAutoPlay);
  reviewsSection.addEventListener("focusin", stopAutoPlay);
  reviewsSection.addEventListener("focusout", startAutoPlay);

  viewport?.addEventListener(
    "touchstart",
    (event) => {
      touchStartX = event.changedTouches[0].clientX;
      stopAutoPlay();
    },
    { passive: true }
  );

  viewport?.addEventListener(
    "touchend",
    (event) => {
      const touchEndX = event.changedTouches[0].clientX;
      const swipeDistance = touchEndX - touchStartX;

      if (Math.abs(swipeDistance) > 45) {
        swipeDistance < 0 ? goNext() : goPrevious();
      }

      startAutoPlay();
    },
    { passive: true }
  );

  document.addEventListener("visibilitychange", () => {
    document.hidden ? stopAutoPlay() : startAutoPlay();
  });

  window.addEventListener("resize", () => {
    window.clearTimeout(resizeTimer);
    resizeTimer = window.setTimeout(() => {
      currentIndex = Math.min(currentIndex, getMaxIndex());
      createDots();
      updateSlider();
    }, 150);
  });

  if (typeof reduceMotion.addEventListener === "function") {
    reduceMotion.addEventListener("change", startAutoPlay);
  }

  createDots();
  updateSlider();
  startAutoPlay();
}

const productAccordions =
  document.querySelectorAll(".product-accordion");

productAccordions.forEach((accordion) => {

  const trigger =
    accordion.querySelector(
      ".product-accordion-trigger"
    );

  if (!trigger) return;

  trigger.addEventListener("click", () => {

    const isOpen =
      accordion.classList.toggle("open");

    trigger.setAttribute(
      "aria-expanded",
      isOpen ? "true" : "false"
    );

  });

});

/* =========================================
   DISCOVERY — OLFACTORY CAROUSEL
========================================= */

const olfactorySection =
  document.querySelector(".ds-olfactory");

if (olfactorySection) {

  const viewport =
    olfactorySection.querySelector(
      ".ds-olfactory-viewport"
    );

  const track =
    olfactorySection.querySelector(
      ".ds-olfactory-track"
    );

  const cards = Array.from(
    olfactorySection.querySelectorAll(
      ".ds-olfactory-item"
    )
  );

  const prev =
    olfactorySection.querySelector(
      ".ds-olfactory-prev"
    );

  const next =
    olfactorySection.querySelector(
      ".ds-olfactory-next"
    );

  const dotsContainer =
    olfactorySection.querySelector(
      ".ds-olfactory-dots"
    );


  let currentIndex = 0;
  let touchStartX = 0;


  function visibleCards() {

    if (window.innerWidth <= 767) {
      return 1;
    }

    if (window.innerWidth <= 1100) {
      return 2;
    }

    return 3;
  }


  function gapSize() {

    if (window.innerWidth <= 767) {
      return 0;
    }

    if (window.innerWidth <= 1100) {
      return 36;
    }

    return 56;
  }


  function maxIndex() {

    return Math.max(
      0,
      cards.length - visibleCards()
    );
  }


  function createDots() {

    dotsContainer.innerHTML = "";

    const total = maxIndex() + 1;


    for (let i = 0; i < total; i++) {

      const dot =
        document.createElement("button");

      dot.type = "button";

      dot.className =
        "ds-olfactory-dot";

      dot.setAttribute(
        "aria-label",
        `View fragrance ${i + 1}`
      );


      dot.addEventListener(
        "click",
        () => {

          currentIndex = i;

          updateSlider();

        }
      );


      dotsContainer.appendChild(dot);

    }

  }


  function updateDots() {

    const dots =
      dotsContainer.querySelectorAll(
        ".ds-olfactory-dot"
      );


    dots.forEach((dot, index) => {

      dot.classList.toggle(
        "active",
        index === currentIndex
      );

    });

  }


  function updateSlider() {

    currentIndex = Math.min(
      Math.max(currentIndex, 0),
      maxIndex()
    );


    const firstCard = cards[0];

    if (!firstCard) return;


    const width =
      firstCard.getBoundingClientRect().width;


    const movement =
      currentIndex *
      (width + gapSize());


    track.style.transform =
      `translateX(-${movement}px)`;


    updateDots();

  }


  function goNext() {

    currentIndex =
      currentIndex >= maxIndex()
        ? 0
        : currentIndex + 1;

    updateSlider();

  }


  function goPrev() {

    currentIndex =
      currentIndex <= 0
        ? maxIndex()
        : currentIndex - 1;

    updateSlider();

  }


  prev.addEventListener(
    "click",
    goPrev
  );


  next.addEventListener(
    "click",
    goNext
  );


  /* SWIPE */

  viewport.addEventListener(
    "touchstart",
    (event) => {

      touchStartX =
        event.changedTouches[0].screenX;

    },
    { passive: true }
  );


  viewport.addEventListener(
    "touchend",
    (event) => {

      const endX =
        event.changedTouches[0].screenX;

      const distance =
        endX - touchStartX;


      if (Math.abs(distance) > 45) {

        if (distance < 0) {
          goNext();
        } else {
          goPrev();
        }

      }

    },
    { passive: true }
  );


  /* RESIZE */

  let resizeTimer;


  window.addEventListener(
    "resize",
    () => {

      clearTimeout(resizeTimer);


      resizeTimer =
        setTimeout(() => {

          currentIndex =
            Math.min(
              currentIndex,
              maxIndex()
            );

          createDots();
          updateSlider();

        }, 150);

    }
  );


  createDots();
  updateSlider();

}

/* =========================================
   FRAGRANCES — COLLECTION FILTER
========================================= */

const fragranceCatalogue =
  document.querySelector(".fr-catalogue");

if (fragranceCatalogue) {

  const filters = Array.from(
    fragranceCatalogue.querySelectorAll(
      ".fr-filter"
    )
  );

  const products = Array.from(
    fragranceCatalogue.querySelectorAll(
      ".fr-product"
    )
  );

  const count =
    fragranceCatalogue.querySelector(
      "#fr-count"
    );


  function filterProducts(collection) {

    let visibleCount = 0;


    products.forEach((product) => {

      const productCollection =
        product.dataset.collection;


      const shouldShow =
        collection === "all" ||
        productCollection === collection;


      product.hidden = !shouldShow;


      if (shouldShow) {
        visibleCount += 1;
      }

    });


    if (count) {
      count.textContent = visibleCount;
    }

  }


  filters.forEach((button) => {

    button.addEventListener(
      "click",
      () => {

        filters.forEach((filter) => {
          filter.classList.remove("active");
        });


        button.classList.add("active");


        filterProducts(
          button.dataset.filter
        );

      }
    );

  });

}

/* =========================================
   VERDEUR — GLOBAL CART SYSTEM
========================================= */

const VERDEUR_CART_KEY = "verdeur-cart";

let VERDEUR_SHIPPING = 250;


/* =========================================
   PRODUCT CATALOG (server-backed)
   Loaded via api/products.php.
========================================= */

let VERDEUR_PRODUCTS = {};

let verdeurCatalogPromise = null;

function loadVerdeurCatalog() {

  if (verdeurCatalogPromise) {
    return verdeurCatalogPromise;
  }

  verdeurCatalogPromise = fetch("api/products.php")

    .then(function (response) {

      if (!response.ok) {
        throw new Error("Catalog request failed");
      }

      return response.json();

    })

    .then(function (data) {

      if (data && typeof data.products === "object") {
        VERDEUR_PRODUCTS = data.products;
      }

      if (data && typeof data.shipping === "number") {
        VERDEUR_SHIPPING = data.shipping;
      }

    })

    .catch(function (error) {

      console.error("Could not load Verdeur catalog:", error);

      return;

    });

  return verdeurCatalogPromise;

}



/* =========================================
   GET CART
========================================= */

function getVerdeurCart() {

  try {

    const stored =
      localStorage.getItem(
        VERDEUR_CART_KEY
      );


    if (!stored) {
      return [];
    }


    const parsed =
      JSON.parse(stored);


    return Array.isArray(parsed)
      ? parsed
      : [];

  }

  catch (error) {

    console.error(
      "Could not read Verdeur cart:",
      error
    );

    return [];

  }

}



/* =========================================
   SAVE CART
========================================= */

function saveVerdeurCart(cart) {

  localStorage.setItem(
    VERDEUR_CART_KEY,
    JSON.stringify(cart)
  );


  updateVerdeurCartCount();

  renderVerdeurCartSlider();

}



/* =========================================
   PRICE FORMAT
========================================= */

function formatVerdeurPrice(amount) {

  return (
    "Rs. " +
    Number(amount).toLocaleString("en-PK")
  );

}



/* =========================================
   ADD PRODUCT
========================================= */

function addVerdeurProduct(productId) {

  const product =
    VERDEUR_PRODUCTS[productId];


  if (!product) {

    console.warn(
      "Unknown product:",
      productId
    );

    return;

  }


  const cart =
    getVerdeurCart();


  const existing =
    cart.find(
      item =>
        item.id === productId
    );


  if (existing) {

    existing.quantity += 1;

  }

  else {

    cart.push({
      id: productId,
      quantity: 1
    });

  }


  saveVerdeurCart(cart);

  showVerdeurCartToast(
    product.name
  );

}



/* =========================================
   GLOBAL ADD TO CART CLICK
========================================= */

document.addEventListener(
  "click",
  function (event) {

    const button =
      event.target.closest(
        "[data-product]"
      );


    if (!button) {
      return;
    }


    const productId =
      button.dataset.product;


    if (
      !VERDEUR_PRODUCTS[
        productId
      ]
    ) {

      event.preventDefault();

      loadVerdeurCatalog().then(
        function () {

          if (!VERDEUR_PRODUCTS[productId]) {
            return;
          }

          addVerdeurProduct(
            productId
          );

          flashVerdeurAddButton(
            button
          );

          openVerdeurCartSlider();

        }
      );

      return;

    }


    event.preventDefault();


    if (
      button.classList.contains(
        "is-added"
      )
    ) {
      return;
    }


    addVerdeurProduct(
      productId
    );


    flashVerdeurAddButton(
      button
    );


    openVerdeurCartSlider();

  }
);



/* =========================================
   HEADER CART COUNT
========================================= */

function updateVerdeurCartCount() {

  const cart =
    getVerdeurCart();


  const totalQuantity =
    cart.reduce(
      (total, item) =>
        total + item.quantity,
      0
    );


  const counters =
    document.querySelectorAll(
      "[data-cart-count]"
    );


  counters.forEach(
    counter => {

      counter.textContent =
        totalQuantity;

    }
  );

}


/* =========================================
   CART SLIDER (DRAWER)
========================================= */

function renderVerdeurCartSlider() {

  const slider =
    document.querySelector(".cart-slider");

  if (!slider) {
    return;
  }


  const itemsContainer =
    slider.querySelector(
      "#cart-slider-items"
    );

  const emptyState =
    slider.querySelector(
      "#cart-slider-empty"
    );

  const footer =
    slider.querySelector(
      "#cart-slider-footer"
    );

  const countElement =
    slider.querySelector(
      "#cart-slider-count"
    );

  const subtotalElement =
    slider.querySelector(
      "#cart-slider-subtotal"
    );


  const cart =
    getVerdeurCart();


  const validCart =
    cart.filter(
      item =>
        VERDEUR_PRODUCTS[item.id]
    );


  if (
    validCart.length !==
    cart.length
  ) {

    saveVerdeurCart(
      validCart
    );

  }


  if (
    validCart.length === 0
  ) {

    itemsContainer.innerHTML = "";

    emptyState.hidden = false;

    footer.hidden = true;

    countElement.textContent =
      "0 items";

    subtotalElement.textContent =
      formatVerdeurPrice(0);

    return;

  }


  emptyState.hidden = true;

  footer.hidden = false;

  itemsContainer.innerHTML = "";


  let subtotal = 0;

  let quantityTotal = 0;


  validCart.forEach(
    item => {

      const product =
        VERDEUR_PRODUCTS[
          item.id
        ];


      const lineTotal =
        product.price *
        item.quantity;


      subtotal +=
        lineTotal;


      quantityTotal +=
        item.quantity;


      const row =
        document.createElement(
          "article"
        );


      row.className =
        "cart-slider-item";


      row.dataset.cartId =
        product.id;


      row.innerHTML = `

        <a
          href="${product.url}"
          class="cart-slider-item-image"
        >

          <img
            src="${product.image}"
            alt="${product.name}"
          >

        </a>

        <div class="cart-slider-item-body">

          <p class="cart-slider-item-collection">
            ${product.collection}
          </p>

          <a
            href="${product.url}"
            class="cart-slider-item-name"
          >
            ${product.name}
          </a>

          <div class="cart-slider-qty">

            <button
              type="button"
              class="cart-slider-qty-btn"
              data-cart-action="minus"
              data-cart-id="${product.id}"
              aria-label="Decrease quantity"
            >
              −
            </button>

            <span class="cart-slider-qty-num">
              ${item.quantity}
            </span>

            <button
              type="button"
              class="cart-slider-qty-btn"
              data-cart-action="plus"
              data-cart-id="${product.id}"
              aria-label="Increase quantity"
            >
              +
            </button>

          </div>

        </div>

        <div class="cart-slider-item-right">

          <button
            type="button"
            class="cart-slider-remove"
            data-cart-action="remove"
            data-cart-id="${product.id}"
          >
            Remove
          </button>

          <span class="cart-slider-item-price">
            ${formatVerdeurPrice(
              lineTotal
            )}
          </span>

        </div>

      `;


      itemsContainer.appendChild(
        row
      );

    }
  );


  countElement.textContent =
    quantityTotal === 1
      ? "1 item"
      : `${quantityTotal} items`;


  subtotalElement.textContent =
    formatVerdeurPrice(
      subtotal
    );

}


function openVerdeurCartSlider() {

  const slider =
    document.querySelector(".cart-slider");

  if (!slider) {
    return;
  }


  renderVerdeurCartSlider();


  slider.classList.add("open");

  slider.setAttribute(
    "aria-hidden",
    "false"
  );


  document.body.style.overflow =
    "hidden";

}


function closeVerdeurCartSlider() {

  const slider =
    document.querySelector(".cart-slider");

  if (!slider) {
    return;
  }


  slider.classList.remove("open");

  slider.setAttribute(
    "aria-hidden",
    "true"
  );


  document.body.style.overflow = "";

}



/* BAG ICON — OPEN SLIDER (no redirect) */

const verdeurBagLink =
  document.querySelector(".bag-link");

if (verdeurBagLink) {

  verdeurBagLink.addEventListener(
    "click",
    function (event) {

      event.preventDefault();

      openVerdeurCartSlider();

    }
  );

}



/* CLOSE — BUTTON + BACKDROP */

document.addEventListener(
  "click",
  function (event) {

    const closeTrigger =
      event.target.closest(
        "[data-cart-close]"
      );

    if (!closeTrigger) {
      return;
    }


    closeVerdeurCartSlider();

  }
);



/* CLOSE — ESCAPE KEY */

document.addEventListener(
  "keydown",
  function (event) {

    if (event.key !== "Escape") {
      return;
    }


    const slider =
      document.querySelector(".cart-slider");


    if (
      slider &&
      slider.classList.contains("open")
    ) {

      closeVerdeurCartSlider();

    }

  }
);



/* =========================================
   ADDED-TO-CART BUTTON FEEDBACK
========================================= */

function flashVerdeurAddButton(button) {

  const originalHTML =
    button.innerHTML;

  const originalDisabled =
    button.disabled;


  button.disabled = true;

  button.classList.add("is-added");

  button.textContent = "ADDED TO CART";


  setTimeout(
    () => {

      button.disabled =
        originalDisabled;

      button.classList.remove(
        "is-added"
      );

      button.innerHTML =
        originalHTML;

    },
    3000
  );

}



/* =========================================
   SMALL ADDED-TO-CART TOAST
========================================= */

function showVerdeurCartToast(
  productName
) {

  let toast =
    document.querySelector(
      ".verdeur-cart-toast"
    );


  if (!toast) {

    toast =
      document.createElement(
        "div"
      );


    toast.className =
      "verdeur-cart-toast";


    document.body.appendChild(
      toast
    );

  }


  toast.innerHTML = `
    <span>${productName}</span>
    <strong>Added to cart</strong>
  `;


  requestAnimationFrame(
    () => {

      toast.classList.add(
        "show"
      );

    }
  );


  clearTimeout(
    window.verdeurToastTimer
  );


  window.verdeurToastTimer =
    setTimeout(
      () => {

        toast.classList.remove(
          "show"
        );

      },
      1800
    );

}



/* =========================================
   CONTACT FORM (AJAX)
========================================= */

(function initVerdeurContact() {

  const form = document.getElementById(
    "contact-form"
  );

  if (!form) {
    return;
  }

  const overlay =
    document.getElementById(
      "contact-popup"
    );

  const messageEl =
    document.getElementById(
      "contact-popup-message"
    );

  const submitBtn = form.querySelector(
    "[type='submit']"
  );


  function openPopup(message) {
    if (!overlay) {
      return;
    }

    if (messageEl) {
      messageEl.textContent = message;
    }

    overlay.hidden = false;
    document.body.classList.add(
      "ct-popup-open"
    );

    const closeBtn = overlay.querySelector(
      "button[data-contact-popup-close]"
    );

    if (closeBtn) {
      closeBtn.focus();
    }
  }


  function closePopup() {
    if (overlay) {
      overlay.hidden = true;
    }

    document.body.classList.remove(
      "ct-popup-open"
    );
  }


  overlay.addEventListener(
    "click",
    (event) => {
      if (
        event.target.closest(
          "[data-contact-popup-close]"
        )
      ) {
        closePopup();
      }
    }
  );

  document.addEventListener(
    "keydown",
    (event) => {
      if (
        event.key === "Escape" &&
        overlay &&
        !overlay.hidden
      ) {
        closePopup();
      }
    }
  );


  form.addEventListener(
    "submit",
    (event) => {

      event.preventDefault();

      if (submitBtn) {
        submitBtn.disabled = true;
      }

      const formData = new FormData(form);

      const submitButtonText = submitBtn
        ? submitBtn.textContent
        : "Sending...";

      if (submitBtn) {
        submitBtn.textContent = "Sending...";
      }

      fetch(
        form.getAttribute("action") ||
        "api/contact.php",
        {
          method: "POST",
          body: formData,
          credentials: "same-origin",
        }
      )
        .then((response) =>
          response.json().then((data) => ({
            ok: response.ok && !!data.ok,
            data: data,
          }))
        )
        .then(({ data }) => {

          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent =
              submitButtonText;
          }

          if (data && data.ok) {
            form.reset();
            openPopup(
              data.message ||
              "Thank you for reaching out. We will get back to you soon."
            );
            return;
          }

          if (data && data.errors) {
            Object.keys(data.errors).forEach(
              (key) => {
                const field =
                  form.querySelector(
                    "[name='" + key + "']"
                  );

                if (field) {
                  field.setCustomValidity(
                    data.errors[key]
                  );
                  field.reportValidity();
                  field.setCustomValidity(
                    ""
                  );
                }
              }
            );
            return;
          }

          openPopup(
            (data && data.error) ||
            "Something went wrong. Please try again."
          );

        })
        .catch(() => {

          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent =
              submitButtonText;
          }

          openPopup(
            "Something went wrong. Please try again."
          );

        });

    }
  );

})();



/* =========================================
   RENDER CART PAGE
========================================= */

function renderVerdeurCart() {

  const itemsContainer =
    document.querySelector(
      "#vcart-items"
    );


  if (!itemsContainer) {
    return;
  }


  const cartLayout =
    document.querySelector(
      "#vcart-layout"
    );


  const emptyState =
    document.querySelector(
      "#vcart-empty"
    );


  const countElement =
    document.querySelector(
      "#vcart-count"
    );


  const subtotalElement =
    document.querySelector(
      "#vcart-subtotal"
    );


  const shippingElement =
    document.querySelector(
      "#vcart-shipping"
    );


  const totalElement =
    document.querySelector(
      "#vcart-total"
    );


  const cart =
    getVerdeurCart();



  /* ---------------------------------------
     REMOVE INVALID PRODUCTS
  --------------------------------------- */

  const validCart =
    cart.filter(
      item =>
        VERDEUR_PRODUCTS[item.id]
    );


  if (
    validCart.length !==
    cart.length
  ) {

    saveVerdeurCart(
      validCart
    );

  }



  /* =====================================
     EMPTY CART
  ====================================== */

if (
  validCart.length === 0
) {

  /* Remove the last rendered product */
  itemsContainer.innerHTML = "";


  /* Reset visible cart values */
  countElement.textContent =
    "0 items";

  subtotalElement.textContent =
    formatVerdeurPrice(0);

  shippingElement.textContent =
    formatVerdeurPrice(0);

  totalElement.textContent =
    formatVerdeurPrice(0);


  /* Switch to empty-cart state */
  cartLayout.hidden =
    true;

  emptyState.hidden =
    false;

  return;

}


  cartLayout.hidden =
    false;

  emptyState.hidden =
    true;



  /* =====================================
     BUILD ITEMS
  ====================================== */

  itemsContainer.innerHTML =
    "";


  let subtotal = 0;

  let quantityTotal = 0;


  validCart.forEach(
    item => {

      const product =
        VERDEUR_PRODUCTS[
          item.id
        ];


      const lineTotal =
        product.price *
        item.quantity;


      subtotal +=
        lineTotal;


      quantityTotal +=
        item.quantity;



      const article =
        document.createElement(
          "article"
        );


      article.className =
        "vcart-item";


      article.dataset.cartId =
        product.id;



      article.innerHTML = `

        <a
          href="${product.url}"
          class="vcart-item-image"
        >

          <img
            src="${product.image}"
            alt="${product.name}"
          >

        </a>


        <div class="vcart-item-info">

          <p class="vcart-collection">
            ${product.collection}
          </p>


          <a
            href="${product.url}"
            class="vcart-product-name"
          >
            ${product.name}
          </a>


          <p class="vcart-product-meta">
            ${product.meta}
          </p>


          <div class="vcart-item-controls">


            <div
              class="vcart-quantity"
            >

              <button
                type="button"
                class="vcart-qty-btn"
                data-cart-action="minus"
                data-cart-id="${product.id}"
                aria-label="Decrease quantity"
              >
                −
              </button>


              <span
                class="vcart-qty"
              >
                ${item.quantity}
              </span>


              <button
                type="button"
                class="vcart-qty-btn"
                data-cart-action="plus"
                data-cart-id="${product.id}"
                aria-label="Increase quantity"
              >
                +
              </button>

            </div>


            <button
              type="button"
              class="vcart-remove"
              data-cart-action="remove"
              data-cart-id="${product.id}"
            >
              Remove
            </button>


          </div>

        </div>


        <div
          class="vcart-item-price"
        >
          ${formatVerdeurPrice(
            lineTotal
          )}
        </div>

      `;


      itemsContainer.appendChild(
        article
      );

    }
  );



  /* =====================================
     SUMMARY
  ====================================== */

  const shipping =
    subtotal > 0
      ? VERDEUR_SHIPPING
      : 0;


  const total =
    subtotal + shipping;



  countElement.textContent =
    quantityTotal === 1
      ? "1 item"
      : `${quantityTotal} items`;


  subtotalElement.textContent =
    formatVerdeurPrice(
      subtotal
    );


  shippingElement.textContent =
    formatVerdeurPrice(
      shipping
    );


  totalElement.textContent =
    formatVerdeurPrice(
      total
    );

}



/* =========================================
   CART PAGE CONTROLS
========================================= */

document.addEventListener(
  "click",
  function (event) {

    const control =
      event.target.closest(
        "[data-cart-action]"
      );


    if (!control) {
      return;
    }


    const productId =
      control.dataset.cartId;


    const action =
      control.dataset.cartAction;


    const cart =
      getVerdeurCart();


    const item =
      cart.find(
        entry =>
          entry.id === productId
      );


    if (!item) {
      return;
    }



    /* PLUS */

    if (
      action === "plus"
    ) {

      item.quantity += 1;

    }



    /* MINUS */

    if (
      action === "minus"
    ) {

      if (
        item.quantity > 1
      ) {

        item.quantity -= 1;

      }

      else {

        const index =
          cart.findIndex(
            entry =>
              entry.id ===
              productId
          );


        cart.splice(
          index,
          1
        );

      }

    }



    /* REMOVE */

    if (
      action === "remove"
    ) {

      const index =
        cart.findIndex(
          entry =>
            entry.id ===
            productId
        );


      cart.splice(
        index,
        1
      );

    }


    saveVerdeurCart(
      cart
    );


    renderVerdeurCart();

  }
);



/* =========================================
   INITIAL LOAD
========================================= */

loadVerdeurCatalog().then(function () {

  updateVerdeurCartCount();

  renderVerdeurCart();

  renderVerdeurCartSlider();

});

/* =========================================
   VERDEUR — CHECKOUT
========================================= */

function renderVerdeurCheckout() {

  const checkoutPage =
    document.querySelector(".vcheckout-page");

  if (!checkoutPage) {
    return;
  }


  const layout =
    document.querySelector("#vcheckout-layout");

  const emptyState =
    document.querySelector("#vcheckout-empty");

  const productsContainer =
    document.querySelector("#vcheckout-items");

  const subtotalElement =
    document.querySelector("#vcheckout-subtotal");

  const shippingElement =
    document.querySelector("#vcheckout-shipping");

  const totalElement =
    document.querySelector("#vcheckout-total");


  /* Make sure checkout HTML is complete */

  if (
    !layout ||
    !productsContainer ||
    !subtotalElement ||
    !shippingElement ||
    !totalElement
  ) {

    console.warn(
      "Checkout markup is incomplete."
    );

    return;
  }


  const cart =
    getVerdeurCart();


  const validCart =
    cart.filter(
      item =>
        VERDEUR_PRODUCTS[item.id] &&
        Number(item.quantity) > 0
    );


  /* Remove any invalid old cart products */

  if (
    validCart.length !==
    cart.length
  ) {

    saveVerdeurCart(
      validCart
    );

  }



  /* =====================================
     EMPTY CHECKOUT
  ====================================== */

  if (
    validCart.length === 0
  ) {

    productsContainer.innerHTML =
      "";


    subtotalElement.textContent =
      formatVerdeurPrice(0);


    shippingElement.textContent =
      formatVerdeurPrice(0);


    totalElement.textContent =
      formatVerdeurPrice(0);


    layout.hidden =
      true;


    if (emptyState) {
      emptyState.hidden =
        false;
    }


    return;

  }



  layout.hidden =
    false;


  if (emptyState) {
    emptyState.hidden =
      true;
  }


  productsContainer.innerHTML =
    "";


  let subtotal = 0;



  /* =====================================
     BUILD ORDER SUMMARY
  ====================================== */

  validCart.forEach(
    item => {

      const product =
        VERDEUR_PRODUCTS[
          item.id
        ];


      const quantity =
        Number(
          item.quantity
        );


      const lineTotal =
        product.price *
        quantity;


      subtotal +=
        lineTotal;


      const element =
        document.createElement(
          "div"
        );


      element.className =
        "vcheckout-product";


      element.innerHTML = `

        <div class="vcheckout-product-image">

          <img
            src="${product.image}"
            alt="${product.name}"
          >

        </div>


        <div class="vcheckout-product-info">

          <p class="vcheckout-product-name">
            ${product.name}
          </p>

          <p class="vcheckout-product-meta">
            ${product.meta}<br>
            Qty ${quantity}
          </p>

        </div>


        <div class="vcheckout-product-price">

          ${formatVerdeurPrice(
            lineTotal
          )}

        </div>

      `;


      productsContainer.appendChild(
        element
      );

    }
  );



  /* =====================================
     TOTALS
  ====================================== */

  const shipping =
    subtotal > 0
      ? VERDEUR_SHIPPING
      : 0;


  const total =
    subtotal +
    shipping;


  subtotalElement.textContent =
    formatVerdeurPrice(
      subtotal
    );


  shippingElement.textContent =
    formatVerdeurPrice(
      shipping
    );


  totalElement.textContent =
    formatVerdeurPrice(
      total
    );

}



/* =========================================
   PLACE ORDER
   FRONTEND TEST LOGIC
========================================= */

const verdeurCheckoutForm =
  document.querySelector(
    "#vcheckout-form"
  );


/* =========================================
   LOADING OVERLAY
   Full-screen spinner shown while the
   order request is being processed.
========================================= */

let verdeurLoadingEl = null;

function showVerdeurLoading(message) {

  if (!verdeurLoadingEl) {

    verdeurLoadingEl =
      document.createElement("div");

    verdeurLoadingEl.className =
      "vcheckout-loading";

    verdeurLoadingEl.innerHTML =
      '<div class="vcheckout-loading-box">' +
      '<div class="vcheckout-loading-spinner"></div>' +
      '<span class="vcheckout-loading-text"></span>' +
      '</div>';

    document.body.appendChild(
      verdeurLoadingEl
    );

  }

  const textEl =
    verdeurLoadingEl.querySelector(
      ".vcheckout-loading-text"
    );

  if (textEl) {
    textEl.textContent =
      message || "Please wait...";
  }

  verdeurLoadingEl.classList.add(
    "is-visible"
  );

  document.body.style.overflow =
    "hidden";

}


function hideVerdeurLoading() {

  if (verdeurLoadingEl) {
    verdeurLoadingEl.classList.remove(
      "is-visible"
    );
  }

  document.body.style.overflow = "";

}


if (
  verdeurCheckoutForm
) {

  verdeurCheckoutForm.addEventListener(
    "submit",
    function (event) {

      event.preventDefault();



      /* ===================================
         FORM VALIDATION
      ==================================== */

      if (
        !verdeurCheckoutForm
          .checkValidity()
      ) {

        verdeurCheckoutForm
          .reportValidity();


        return;

      }



      /* ===================================
         GET CART
      ==================================== */

      const cart =
        getVerdeurCart();


      const validCart =
        cart.filter(
          item =>
            VERDEUR_PRODUCTS[
              item.id
            ] &&
            Number(
              item.quantity
            ) > 0
        );


      if (
        validCart.length === 0
      ) {

        renderVerdeurCheckout();

        return;

      }



      /* ===================================
         CUSTOMER DETAILS
      ==================================== */

      const formData =
        new FormData(
          verdeurCheckoutForm
        );


      const customer = {

        name:
          String(
            formData.get(
              "name"
            ) || ""
          ).trim(),

        phone:
          String(
            formData.get(
              "phone"
            ) || ""
          ).trim(),

        email:
          String(
            formData.get(
              "email"
            ) || ""
          ).trim(),

        address:
          String(
            formData.get(
              "address"
            ) || ""
          ).trim(),

        city:
          String(
            formData.get(
              "city"
            ) || ""
          ).trim(),

        province:
          String(
            formData.get(
              "province"
            ) || ""
          ).trim(),

        notes:
          String(
            formData.get(
              "notes"
            ) || ""
          ).trim(),

        honeypot:
          String(
            formData.get(
              "company_website"
            ) || ""
          ).trim(),

        form_started:
          String(
            formData.get(
              "form_started"
            ) || "0"
          ).trim()

      };



      /* ===================================
         ORDER ITEMS
      ==================================== */

      let subtotal = 0;


      const orderItems =
        validCart.map(
          item => {

            const product =
              VERDEUR_PRODUCTS[
                item.id
              ];


            const quantity =
              Number(
                item.quantity
              );


            const lineTotal =
              product.price *
              quantity;


            subtotal +=
              lineTotal;


            return {

              id:
                product.id,

              name:
                product.name,

              collection:
                product.collection,

              meta:
                product.meta,

              price:
                product.price,

              quantity:
                quantity,

              image:
                product.image,

              lineTotal:
                lineTotal

            };

          }
        );



      /* ===================================
         ORDER TOTAL
      ==================================== */

      const shipping =
        subtotal > 0
          ? VERDEUR_SHIPPING
          : 0;


      const total =
        subtotal +
        shipping;



      /* ===================================
         CREATE ORDER
      ==================================== */

      const resolvePaymentMethod = () => {
        const codOption = document.getElementById('vcheckout-cod-selectable');
        if (codOption && codOption.classList.contains('active')) {
          return 'Cash on Delivery';
        }
        const activeTab = document.querySelector('.vcheckout-tab.active:not(.inactive)');
        return activeTab
          ? (activeTab.getAttribute('data-bank-name') || 'Bank Transfer')
          : 'Bank Transfer';
      };

      const order = {

        orderStatus:
          "Pending",

        paymentStatus:
          "Pending",

        paymentMethod:
          resolvePaymentMethod(),

        customer:
          customer,

        items:
          orderItems,

        subtotal:
          subtotal,

        shipping:
          shipping,

        total:
          total,

        createdAt:
          new Date()
            .toISOString()

      };



      /* ===================================
         PLACE ORDER BUTTONS
      ==================================== */

      const placeButtons =
        Array.from(
          document.querySelectorAll(
            ".vcheckout-place-order"
          )
        );


      placeButtons.forEach(
        btn => {
          btn.disabled = true;
        }
      );


      showVerdeurLoading(
        "Placing your order..."
      );



      /* ===================================
         POST ORDER TO SERVER
      ==================================== */

      fetch(
        "api/orders.php",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            customer: customer,
            items: orderItems,
            payment_method: order.paymentMethod
          }),
          credentials: "same-origin"
        }
      )
        .then(
          response =>
            response
              .json()
              .then(data => ({
                ok: response.ok
                  && !!data.ok,
                data: data
              }))
        )
        .then(({ data }) => {

          placeButtons.forEach(
            btn => {
              btn.disabled = false;
            }
          );

          if (!data || !data.ok) {

            if (data && data.errors) {

              Object.keys(
                data.errors
              ).forEach(key => {

                const field =
                  verdeurCheckoutForm
                    .querySelector(
                      "[name='" +
                        key +
                        "']"
                    );

                if (field) {
                  field.setCustomValidity(
                    data.errors[key]
                  );
                  field.reportValidity();
                  field.setCustomValidity(
                    ""
                  );
                }

              });

              hideVerdeurLoading();

              return;

            }

            hideVerdeurLoading();

            window.alert(
              (data && data.error) ||
              "Something went wrong. Please try again."
            );

            return;

          }



          /* ===================================
             SAVE ORDER LOCALLY
          ==================================== */

          order.orderNumber =
            data.order_number ||
            order.orderNumber;

          order.orderStatus =
            data.order_status ||
            order.orderStatus;

          order.paymentStatus =
            data.payment_status ||
            order.paymentStatus;

          localStorage.setItem(
            "verdeur-last-order",
            JSON.stringify(
              order
            )
          );



          /* ===================================
             CLEAR CART
          ==================================== */

          saveVerdeurCart(
            []
          );



          /* ===================================
             REDIRECT
          ==================================== */

          window.location.href =
            "order-success.php";

        })
        .catch(() => {

          hideVerdeurLoading();

          placeButtons.forEach(
            btn => {
              btn.disabled = false;
            }
          );

          window.alert(
            "Something went wrong. Please try again."
          );

        });

    }
  );

}



/* =========================================
   INITIALIZE CHECKOUT
========================================= */

loadVerdeurCatalog().then(function () {

  renderVerdeurCheckout();

});


/* =========================================
   VERDEUR — NEWSLETTER
========================================= */

(function initVerdeurNewsletter() {

  const form = document.getElementById(
    "newsletter-form"
  );

  if (!form) {
    return;
  }

  const statusEl =
    document.getElementById(
      "newsletter-status"
    );

  const submitBtn = form.querySelector(
    "[type='submit']"
  );

  function showStatus(message, isError) {

    if (statusEl) {
      statusEl.textContent = message;
      statusEl.classList.toggle(
        "newsletter-status-error",
        Boolean(isError)
      );
    }

  }

  form.addEventListener(
    "submit",
    (event) => {

      event.preventDefault();

      const emailInput =
        form.querySelector("#newsletter-email");

      const email =
        emailInput
          ? String(emailInput.value || "").trim()
          : "";

      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {

        showStatus(
          "Please enter a valid email address.",
          true
        );

        if (emailInput) {
          emailInput.focus();
        }

        return;

      }

      showStatus("", false);

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "Subscribing...";
      }

      fetch("api/newsletter.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ email })
      })

        .then(function (response) {
          return response.json();
        })

        .then(function (data) {

          if (data && data.success) {
            showStatus(
              data.message || "Thank you for subscribing.",
              false
            );
            if (emailInput) {
              emailInput.value = "";
            }
          } else {

            const message =
              data && data.errors && data.errors.email
                ? data.errors.email
                : (data && data.message
                    ? data.message
                    : "Something went wrong. Please try again.");

            showStatus(message, true);

          }

        })

        .catch(function () {

          showStatus(
            "Something went wrong. Please try again.",
            true
          );

        })

        .finally(function () {

          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = "Subscribe";
          }

        });

    }
  );

})();

