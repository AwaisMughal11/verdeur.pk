﻿<?php

require_once __DIR__ . '/config.php';

$featuredProducts = [];
$discoverySet = null;
$testimonials = [];

try {

  $pdo = verdeur_db();

  $featuredProducts = $pdo->query(
    'SELECT p.slug, p.name, p.expression, p.image, p.home_description
     FROM products p
     INNER JOIN collections c ON c.collection_id = p.collection_id
     WHERE p.is_active = 1 AND p.featured = 1
     ORDER BY c.sort_order, p.sort_order'
  )->fetchAll();

  $discoverySet = $pdo->query(
    'SELECT t.*, c.name AS collection_name
     FROM tester_sets t
     LEFT JOIN collections c ON c.collection_id = t.collection_id
     WHERE t.is_active = 1
     ORDER BY t.sort_order
     LIMIT 1'
  )->fetch();

  $testimonials = $pdo->query(
    'SELECT t.customer_name, t.quote, t.label,
            p.name AS product_name
     FROM testimonials t
     LEFT JOIN products p ON p.product_id = t.product_id
     WHERE t.is_active = 1
     ORDER BY t.sort_order ASC, t.testimonial_id ASC'
  )->fetchAll();

} catch (Throwable $e) {
  $featuredProducts = [];
  $discoverySet = null;
  $testimonials = [];
}

$pageTitle = 'Verdeur — Independent Fragrance House';
$pageDescription = 'Verdeur is an independent fragrance house crafting collection-driven perfume expressions, discovery sets and scent stories. Explore Initialé, Éclat, Auréole and Vespère.';
$headerClass = '';
include('includes/header.php');
?>



  <main>

  <!-- =========================================
       02 — HERO
  ========================================== -->
  <section class="hero">

    <!-- Desktop Video -->
    <video
      class="hero-media hero-video-desktop"
      autoplay
      muted
      loop
      playsinline
      >
      <source
        src="<?php echo v_esc(verdeur_setting('hero_desktop_video', 'assets/video/next-chapter-hero-desktop.webm')); ?>"
        type="video/webm"
      >
    </video>


    <!-- Mobile Video -->
    <video
      class="hero-media hero-video-mobile"
      autoplay
      muted
      loop
      playsinline
      >
      <source
        src="<?php echo v_esc(verdeur_setting('hero_mobile_video', 'assets/video/next-chapter-hero-mobile.webm')); ?>"
        type="video/webm"
      >
    </video>


    <!-- Very subtle top shading for header readability -->
    <div class="hero-overlay"></div>

  </section>

  <!-- =========================================
     03 — MARQUEE
========================================== -->
<section class="brand-marquee" aria-label="Verdeur brand message">

  <div class="marquee-track">

    <div class="marquee-content">
      <span>The Silent Conversation — expressed through scent</span>
      <span>The Silent Conversation — expressed through scent</span>
      <span>The Silent Conversation — expressed through scent</span>
      <span>The Silent Conversation — expressed through scent</span>
    </div>

    <div class="marquee-content" aria-hidden="true">
      <span>The Silent Conversation — expressed through scent</span>
      <span>The Silent Conversation — expressed through scent</span>
      <span>The Silent Conversation — expressed through scent</span>
      <span>The Silent Conversation — expressed through scent</span>
    </div>

  </div>

</section>

<!-- =========================================
     04 — BRAND STATEMENT
========================================== -->
<section class="brand-statement">

  <p>
    Scent gives form to what words leave unspoken.
  </p>

</section>

<!-- =========================================
     05 — INITIALÉ FRAGRANCES
========================================== -->

<section class="fragrance-showcase">

<?php foreach ($featuredProducts as $index => $fragrance): ?>

  <article class="fragrance-row<?php echo $index % 2 === 1 ? ' fragrance-row-reverse' : ''; ?>">

    <div class="fragrance-visual">
      <img
        src="<?php echo v_esc($fragrance['image']); ?>"
        alt="<?php echo v_esc($fragrance['name'] . ' by Verdeur'); ?>"
        loading="lazy"
        decoding="async"
      >
    </div>

    <div class="fragrance-content">

      <h2 class="fragrance-name">
        <?php echo v_esc($fragrance['name']); ?>
      </h2>

      <p class="fragrance-expression">
        <?php echo v_esc($fragrance['expression']); ?>
      </p>

      <p class="fragrance-description">
        <?php echo v_esc($fragrance['home_description']); ?>
      </p>

      <a href="fragrance/<?php echo v_esc($fragrance['slug']); ?>" class="fragrance-link">
        Explore
      </a>

    </div>

  </article>

<?php endforeach; ?>

</section>

<!-- =========================================
     06 — DISCOVERY SET
========================================== -->

<section class="discovery-section">

  <div class="discovery-inner">

    <p class="discovery-eyebrow">
      <?php
        $setCollection = $discoverySet ? ($discoverySet['collection_name'] ?: ($discoverySet['collection'] ?? 'Initialé')) : 'Initialé';
        echo v_esc($setCollection . ' Discovery Set');
      ?>
    </p>

    <h2 class="discovery-title">
      <?php echo v_esc('Discover ' . $setCollection); ?>
    </h2>

    <p class="discovery-copy">
      <?php
        $setIntro = $discoverySet ? $discoverySet['intro'] : 'Experience all five expressions of Initialé before choosing the fragrance that feels most like your own.';
        echo v_esc($setIntro);
      ?>
    </p>

    <div class="discovery-visual">
      <img
        src="<?php echo v_esc($discoverySet ? $discoverySet['image'] : 'assets/images/tester_bottles.webp'); ?>"
        alt="Verdeur Initialé Discovery Set"
        loading="lazy"
        decoding="async"
      >
    </div>

    <p class="discovery-size">
      <?php echo v_esc($discoverySet ? $discoverySet['size_label'] : '5 × 5ml'); ?>
    </p>

    <a
      href="./discovery-set/Initiale-set"
      class="discovery-button"
    >
      Explore Discovery Set
    </a>

  </div>

</section>

<!-- =========================================
     07 — CLIENT IMPRESSIONS
========================================== -->

<section class="reviews-section">

  <div class="reviews-header">
    <h2 class="reviews-title">
      Client Impressions
    </h2>
  </div>


  <div class="reviews-slider">

    <button
      class="reviews-arrow reviews-arrow-prev"
      type="button"
      aria-label="Previous review"
    >
      ←
    </button>


    <div class="reviews-viewport">

      <div class="reviews-track">

        <?php foreach ($testimonials as $testimonial): ?>
          <?php
            $reviewFragrance = $testimonial['label'] !== ''
              ? $testimonial['label']
              : ($testimonial['product_name'] ?? 'Verdeur');
          ?>

          <article class="review-card">

            <span class="review-quote">“</span>

            <p class="review-text">
              <?= v_esc($testimonial['quote']) ?>
            </p>

            <div class="review-meta">
              <span class="review-name"><?= v_esc($testimonial['customer_name']) ?></span>
              <span class="review-fragrance"><?= v_esc($reviewFragrance) ?></span>
            </div>

          </article>

        <?php endforeach; ?>

      </div>

    </div>


    <button
      class="reviews-arrow reviews-arrow-next"
      type="button"
      aria-label="Next review"
    >
      →
    </button>

  </div>


  <div
    class="reviews-dots"
    aria-label="Review navigation"
  ></div>

</section>

<!-- =========================================
     08 — OUR STORY + BRAND UNIVERSE
========================================== -->

<section class="story-section">

  <!-- Our Story Teaser -->
  <div class="story-teaser">

    <h2 class="story-title">
      Our Story
    </h2>

    <p class="story-copy">
      Verdeur is an independent fragrance house built around the idea
      that scent can express what words often leave unspoken.
      Each fragrance is created as a distinct expression — shaped by
      character, feeling and the experience it quietly carries.
    </p>

    <a
      href="./story.php"
      class="story-button"
    >
      Discover Our Story
    </a>

  </div>


  <!-- Brand Universe Visual -->
  <div class="universe-panel">

    <img
      src="assets/images/silent-conversation-bg.webp"
      alt=""
      class="universe-background"
      loading="lazy"
      decoding="async"
    >

    <div class="universe-content">

      <img
        src="assets/logo/verdeur-logo.svg"
        alt="Verdeur"
        class="universe-logo"
      >

      <p class="universe-line">
        The Silent Conversation
      </p>

    </div>

  </div>

</section>

<!-- =========================================
     09 — FOLLOW US + NEWSLETTER
========================================== -->

<section class="connect-section">

  <div class="connect-inner">

    <!-- Follow Us -->
    <h2 class="follow-title">
      Follow Us
    </h2>


    <!-- Social Icons -->
    <div class="social-icons">

      <!-- Facebook -->
      <a
        href="<?= v_esc(verdeur_setting('social_facebook')) ?>"
        class="social-icon"
        aria-label="Facebook"
        target="_blank"
        rel="noopener noreferrer"
      >
        <svg
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            d="M13.5 22v-9h3l.45-3.5H13.5V7.26c0-1.01.28-1.7 1.73-1.7H17V2.43c-.31-.04-1.38-.13-2.63-.13-2.6 0-4.37 1.58-4.37 4.49V9.5H7v3.5h3v9h3.5z"
          />
        </svg>
      </a>


      <!-- Instagram -->
      <a
        href="<?= v_esc(verdeur_setting('social_instagram')) ?>"
        class="social-icon"
        aria-label="Instagram"
        target="_blank"
        rel="noopener noreferrer"
      >
        <svg
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <rect
            x="3"
            y="3"
            width="18"
            height="18"
            rx="5"
            ry="5"
          ></rect>

          <circle
            cx="12"
            cy="12"
            r="4"
          ></circle>

          <circle
            cx="17.5"
            cy="6.5"
            r="1"
            class="instagram-dot"
          ></circle>
        </svg>
      </a>


      <!-- TikTok -->
      <a
        href="<?= v_esc(verdeur_setting('social_tiktok')) ?>"
        class="social-icon"
        aria-label="TikTok"
        target="_blank"
        rel="noopener noreferrer"
      >
        <svg
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            d="M14 3v11.2a4.4 4.4 0 1 1-3.5-4.3v3.1a1.5 1.5 0 1 0 .5 1.1V3h3zm0 0c.5 2.7 2.1 4.4 4.5 4.8v3.1c-1.8-.1-3.3-.7-4.5-1.7"
          ></path>
        </svg>
      </a>

    </div>


    <!-- Newsletter Copy -->
    <p class="newsletter-copy">
      Follow Verdeur to discover new releases, latest news
      and stories from the house.
    </p>


    <!-- Newsletter Form -->
    <form class="newsletter-form" id="newsletter-form">

      <label
        for="newsletter-email"
        class="visually-hidden"
      >
        Email address
      </label>


      <div class="newsletter-input-wrap">

        <input
          type="email"
          id="newsletter-email"
          name="email"
          placeholder="Email address"
          required
        >

        <!-- Small mail icon -->
        <svg
          class="newsletter-icon"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <rect
            x="3"
            y="5"
            width="18"
            height="14"
            rx="1"
          ></rect>

          <path d="M3 7l9 6 9-6"></path>
        </svg>

      </div>


      <button type="submit">
        Subscribe
      </button>

    </form>

    <p class="newsletter-status" id="newsletter-status" aria-live="polite"></p>

  </div>

</section>


  </main>

  <!-- =========================================
     10 — FOOTER
========================================== -->

<?php include('includes/footer.php'); ?>
