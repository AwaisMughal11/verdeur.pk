﻿<?php

require_once __DIR__ . '/config.php';

$slug = isset($_GET['slug'])
  ? trim((string) $_GET['slug'])
  : '';

$product    = null;
$collection = null;
$chapters   = [];
$related    = [];

if ($slug !== '') {

  try {

    $pdo = verdeur_db();

    $stmt = $pdo->prepare(
      'SELECT p.*, c.name AS collection_name, c.slug AS collection_slug
       FROM products p
       INNER JOIN collections c ON c.collection_id = p.collection_id
       WHERE p.slug = ? AND p.is_active = 1
       LIMIT 1'
    );

    $stmt->execute([$slug]);
    $product = $stmt->fetch();

    if ($product) {

      $collection = $product;

      $stmt = $pdo->prepare(
        'SELECT * FROM product_stories WHERE product_id = ? ORDER BY chapter_no'
      );
      $stmt->execute([$product['product_id']]);
      $chapters = $stmt->fetchAll();

      $stmt = $pdo->prepare(
        'SELECT p.slug, p.name, p.expression, p.image, p.price, c.name AS collection_name
         FROM products p
         INNER JOIN collections c ON c.collection_id = p.collection_id
         WHERE p.is_active = 1 AND p.collection_id = ? AND p.product_id <> ?
         ORDER BY p.sort_order, p.name
         LIMIT 4'
      );
      $stmt->execute([$product['collection_id'], $product['product_id']]);
      $related = $stmt->fetchAll();

    }

  } catch (Throwable $e) {
    $product = null;
  }

}

$pageTitle = $product
  ? ($product['name'] . ' — Verdeur')
  : 'Product Not Found — Verdeur';

/* SEO overrides (consumed by includes/header.php) */
$seoType = 'product';
if ($product) {
  $seoName  = (string) $product['name'];
  $seoPrice = (string) $product['price'];
  $productMeta = trim((string) ($product['name'] . ' — ' . $product['expression']));
  if ($productMeta === '') {
    $productMeta = 'A Verdeur signature fragrance.';
  }
  $pageDescription = $productMeta . ' Available at Verdeur, an independent fragrance house.';
  $pageImage = (string) $product['image'];
  $canonicalUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/fragrance/' . urlencode((string) $product['slug']);
}

include('includes/header.php');

?>

  <main>

<?php if ($product): ?>

    <!-- =========================================
         PRODUCT â€” HERO
    ========================================== -->

    <section class="product-hero">

      <div class="product-hero-inner">


        <div class="product-hero-visual">

          <img
            src="<?php echo v_esc($product['image']); ?>"
            alt="<?php echo v_esc($product['name'] . ' by Verdeur'); ?>"
            class="product-hero-image"
            fetchpriority="high"
          >

        </div>


        <div class="product-hero-content">


          <div class="product-heading">

            <p class="product-collection">
              <?php echo v_esc($collection['collection_name'] ?? ''); ?>
            </p>

            <h1 class="product-title">
              <?php echo v_esc($product['name']); ?>
            </h1>

            <p class="product-expression">
              <?php echo v_esc($product['expression']); ?>
            </p>

            <p class="product-price">
              <?php echo v_price($product['price']); ?>
            </p>

          </div>


<?php if ($product['top_notes'] !== '' || $product['heart_notes'] !== '' || $product['base_notes'] !== ''): ?>

          <div class="product-accordion">

            <button
              type="button"
              class="product-accordion-trigger"
              aria-expanded="false"
            >

              <span>Olfactory Pyramid</span>

              <span class="accordion-icon">
                +
              </span>

            </button>


            <div class="product-accordion-content">

<?php if ($product['top_notes'] !== ''): ?>

              <div class="pyramid-row">

                <span class="pyramid-label">
                  Top Notes
                </span>

                <span class="pyramid-notes">
                  <?php echo v_esc($product['top_notes']); ?>
                </span>

              </div>

<?php endif; ?>

<?php if ($product['heart_notes'] !== ''): ?>

              <div class="pyramid-row">

                <span class="pyramid-label">
                  Heart Notes
                </span>

                <span class="pyramid-notes">
                  <?php echo v_esc($product['heart_notes']); ?>
                </span>

              </div>

<?php endif; ?>

<?php if ($product['base_notes'] !== ''): ?>

              <div class="pyramid-row">

                <span class="pyramid-label">
                  Base Notes
                </span>

                <span class="pyramid-notes">
                  <?php echo v_esc($product['base_notes']); ?>
                </span>

              </div>

<?php endif; ?>

            </div>

          </div>

<?php endif; ?>


          <div class="product-details-list">

            <div class="product-detail-row">

              <span class="product-detail-label">
                Size
              </span>

              <span class="product-detail-value">
                <?php echo v_esc($product['meta']); ?>
              </span>

            </div>

<?php if ($product['family'] !== ''): ?>

            <div class="product-detail-row">

              <span class="product-detail-label">
                Fragrance Family
              </span>

              <span class="product-detail-value">
                <?php echo v_esc($product['family']); ?>
              </span>

            </div>

<?php endif; ?>

<?php if ($product['best_for'] !== ''): ?>

            <div class="product-detail-row">

              <span class="product-detail-label">
                Best For
              </span>

              <span class="product-detail-value">
                <?php echo v_esc($product['best_for']); ?>
              </span>

            </div>

<?php endif; ?>

          </div>


          <button
            type="button"
            class="product-add-cart"
            data-product="<?php echo v_esc($product['slug']); ?>"
          >
            Add to Cart
          </button>


        </div>

      </div>

    </section>

<?php if (count($chapters) > 0): ?>

    <!-- =========================================
         PRODUCT â€” SCENT STORY
    ========================================== -->

    <section class="scent-story">

<?php foreach ($chapters as $index => $chapter): ?>

      <article class="scent-chapter<?php echo $index % 2 === 1 ? ' scent-chapter-reverse' : ''; ?>">

        <div class="scent-chapter-visual">

          <img
            src="<?php echo v_esc($chapter['image']); ?>"
            alt=""
            loading="lazy"
            decoding="async"
          >

        </div>


        <div class="scent-chapter-content">

          <p class="scent-chapter-number">
            <?php echo v_esc($chapter['kicker']); ?>
          </p>

          <h2 class="scent-chapter-title">
            <?php echo v_esc($chapter['title']); ?>
          </h2>

          <p class="scent-chapter-copy">
            <?php echo v_esc($chapter['copy']); ?>
          </p>

        </div>

      </article>

<?php endforeach; ?>

<?php if ($product['conclusion'] !== ''): ?>

      <article class="scent-conclusion">

        <div class="scent-conclusion-content">

          <p class="scent-chapter-number">
            The Expression
          </p>

          <h2 class="scent-conclusion-title">
            <?php echo v_esc($product['name']); ?>
          </h2>

          <p class="scent-conclusion-copy">
            <?php echo v_esc($product['conclusion']); ?>
          </p>

        </div>


        <div class="scent-conclusion-visual">

          <img
            src="<?php echo v_esc($product['image']); ?>"
            alt="<?php echo v_esc($product['name'] . ' by Verdeur'); ?>"
            loading="lazy"
            decoding="async"
          >

        </div>

      </article>

<?php endif; ?>

    </section>

<?php elseif ($product['conclusion'] !== ''): ?>

    <section class="scent-story">

      <article class="scent-conclusion">

        <div class="scent-conclusion-content">

          <p class="scent-chapter-number">
            The Expression
          </p>

          <h2 class="scent-conclusion-title">
            <?php echo v_esc($product['name']); ?>
          </h2>

          <p class="scent-conclusion-copy">
            <?php echo v_esc($product['conclusion']); ?>
          </p>

        </div>


        <div class="scent-conclusion-visual">

          <img
            src="<?php echo v_esc($product['image']); ?>"
            alt="<?php echo v_esc($product['name'] . ' by Verdeur'); ?>"
            loading="lazy"
            decoding="async"
          >

        </div>

      </article>

    </section>

<?php endif; ?>

<?php if (count($chapters) === 0 && $product['conclusion'] === ''): ?>

    <section class="scent-story">

      <article class="scent-conclusion">

        <div class="scent-conclusion-content">

          <p class="scent-chapter-number">
            Coming Soon
          </p>

          <h2 class="scent-conclusion-title">
            <?php echo v_esc($product['name']); ?>
          </h2>

          <p class="scent-conclusion-copy">
            Full details for this expression will be shared soon.
            Keep an eye on this page for the complete scent story.
          </p>

        </div>


        <div class="scent-conclusion-visual">

          <img
            src="<?php echo v_esc($product['image']); ?>"
            alt="<?php echo v_esc($product['name'] . ' by Verdeur'); ?>"
            loading="lazy"
            decoding="async"
          >

        </div>

      </article>

    </section>

<?php endif; ?>

<?php if (count($related) > 0): ?>

    <!-- =========================================
         OTHER EXPRESSIONS FROM THE SAME COLLECTION
    ========================================== -->

    <section class="related-products">

      <div class="related-products-inner">

        <div class="related-products-header">

          <p class="related-products-eyebrow">
            <?php echo v_esc($collection['collection_name'] ?? ''); ?>
          </p>

          <h2 class="related-products-title">
            OTHER EXPRESSIONS
          </h2>

        </div>


        <div class="related-products-grid">

<?php foreach ($related as $relatedProduct): ?>

          <article class="related-product">

            <a
              href="fragrance/<?php echo v_esc($relatedProduct['slug']); ?>"
              class="related-product-link"
            >

              <div class="related-product-visual">

                <img
                  src="<?php echo v_esc($relatedProduct['image']); ?>"
                  alt="<?php echo v_esc($relatedProduct['name'] . ' by Verdeur'); ?>"
                  loading="lazy"
                  decoding="async"
                >

              </div>


              <div class="related-product-info">

                <h3 class="related-product-name">
                  <?php echo v_esc($relatedProduct['name']); ?>
                </h3>

                <p class="related-product-expression">
                  <?php echo v_esc($relatedProduct['expression']); ?>
                </p>

                <p class="related-product-price">
                  <?php echo v_price($relatedProduct['price']); ?>
                </p>

              </div>

            </a>

          </article>

<?php endforeach; ?>

        </div>

      </div>

    </section>

<?php endif; ?>

<?php else: ?>

    <section class="fr-catalogue">

      <div class="fr-catalogue-inner">

        <header class="fr-page-header">

          <p class="fr-page-kicker">
            Verdeur
          </p>

          <h1 class="fr-page-title">
            PRODUCT NOT FOUND
          </h1>

          <p class="fr-page-intro">
            The fragrance you are looking for could not be found.
          </p>

        </header>


        <div class="fr-page-actions">

          <a href="fragrances.php" class="product-add-cart">
            Browse All Fragrances
          </a>

        </div>

      </div>

    </section>

<?php endif; ?>

  </main>

<?php include('includes/footer.php'); ?>