<?php
/**
 * VERDEUR — Collection expansion seed
 * ------------------------------------
 * Adds collections, products and database-driven tester packs.
 * Safe to re-run: skips rows whose slug already exists.
 *
 * Run:  C:\xampp\php\php.exe db\seed_collections.php
 */

require_once __DIR__ . '/../config.php';

$pdo = verdeur_db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "Starting collection seed...\n";

/* ------------------------------------------------------------
   COLLECTIONS
------------------------------------------------------------ */

$collections = [
  [
    'slug'         => 'eclat',
    'name'         => 'Éclat',
    'kicker'       => 'Radiant Light, Expressed',
    'subtitle'     => 'The Glow Between',
    'description'  => 'Éclat captures light as it moves — bright, luminous and full of soft radiance. Each fragrance in this collection turns a single spark of brilliance into a wearable expression.',
    'count_label'  => 'Six fragrances · Radiant Expressions',
    'sort_order'   => 2,
  ],
  [
    'slug'         => 'aureole',
    'name'         => 'Auréole',
    'kicker'       => 'A Circle of Golden Warmth',
    'subtitle'     => 'Warmth, Held Close',
    'description'  => 'Auréole is a halo of golden warmth — amber, honey and resin gathered around a radiant center. These fragrances glow softly and stay close to the skin.',
    'count_label'  => 'Five fragrances · Golden Expressions',
    'sort_order'   => 3,
  ],
  [
    'slug'         => 'vespere',
    'name'         => 'Vespère',
    'kicker'       => 'The Language of the Night',
    'subtitle'     => 'After Dusk',
    'description'  => 'Vespère explores the hush of evening — dark woods, spice and smoke that deepen as the light fades. Fragrances for the hours when the world turns inward.',
    'count_label'  => 'Five fragrances · Nocturnal Expressions',
    'sort_order'   => 4,
  ],
];

$colById = [];
$insCollection = $pdo->prepare(
  'INSERT IGNORE INTO collections (slug, name, kicker, subtitle, description, count_label, sort_order, is_active)
   VALUES (:slug, :name, :kicker, :subtitle, :description, :count_label, :sort_order, 1)'
);

foreach ($collections as $col) {
  // update metadata if it already exists
  $pdo->prepare('UPDATE collections SET name = :name, kicker = :kicker, subtitle = :subtitle, description = :description, count_label = :count_label, sort_order = :sort_order, is_active = 1 WHERE slug = :slug')
      ->execute([
        ':name'        => $col['name'],
        ':kicker'      => $col['kicker'],
        ':subtitle'    => $col['subtitle'],
        ':description' => $col['description'],
        ':count_label' => $col['count_label'],
        ':sort_order'  => $col['sort_order'],
        ':slug'        => $col['slug'],
      ]);

  $stmt = $pdo->prepare('SELECT collection_id FROM collections WHERE slug = ? LIMIT 1');
  $stmt->execute([$col['slug']]);
  $row = $stmt->fetch();
  if ($row) {
    $colById[$col['slug']] = (int) $row['collection_id'];
    echo '  collection: ' . $col['name'] . ' (id ' . $row['collection_id'] . ")\n";
  } else {
    $insCollection->execute([
      ':slug'        => $col['slug'],
      ':name'        => $col['name'],
      ':kicker'      => $col['kicker'],
      ':subtitle'    => $col['subtitle'],
      ':description' => $col['description'],
      ':count_label' => $col['count_label'],
      ':sort_order'  => $col['sort_order'],
    ]);
    $colById[$col['slug']] = (int) $pdo->lastInsertId();
    echo '  collection (new): ' . $col['name'] . ' (id ' . $colById[$col['slug']] . ")\n";
  }
}

// Initialé id
$initialeId = null;
$stmt = $pdo->query('SELECT collection_id FROM collections WHERE slug = "initiale" LIMIT 1');
$initialeId = (int) $stmt->fetchColumn();

/* ------------------------------------------------------------
   PRODUCTS
------------------------------------------------------------ */

$META = '50ml · Extrait de Parfum';

$products = [
  // ---------------- ÉCLAT (radiant / luminous) ----------------
  [
    'slug' => 'afterglow', 'collection' => 'eclat',
    'name' => 'AFTERGLOW', 'expression' => 'Quiet Radiance',
    'price' => 4290, 'image' => 'assets/images/nc.webp',
    'family' => 'Amber Floral',
    'best_for' => 'Cooler evenings, Dinner occasions, Special gatherings',
    'top_notes' => 'Saffron, Bergamot, Pink Pepper',
    'heart_notes' => 'Rose, Orris, Cashmere Musk',
    'base_notes' => 'Amber, Vanilla Bean, Tonka, Cedarwood',
    'home_description' => 'A warm funnel of light that keeps glowing long after the moment has passed.',
    'conclusion' => 'Afterglow is the light that lingers — saffron, rose and amber folding into a soft, radiant warmth that stays close to the skin.',
    'accent' => '#c0693f',
  ],
  [
    'slug' => 'golden-hour', 'collection' => 'eclat',
    'name' => 'GOLDEN HOUR', 'expression' => 'Luminous Warmth',
    'price' => 4290, 'image' => 'assets/images/eo.webp',
    'family' => 'Amber Vanilla',
    'best_for' => 'Golden hour walks, Evening wear, Cozy settings',
    'top_notes' => 'Bergamot, Bitter Orange, Neroli',
    'heart_notes' => 'Orange Blossom, Honey Accord, Ylang Ylang',
    'base_notes' => 'Amber, Vanilla, Tonka Bean, Musk',
    'home_description' => 'The warm, honeyed glow of the hour before the sun sets.',
    'conclusion' => 'Golden Hour catches the last warm light — bright citrus, honeyed florals and a smooth amber vanilla base that feels like dusk held still.',
    'accent' => '#d08c2f',
  ],
  [
    'slug' => 'prism-glow', 'collection' => 'eclat',
    'name' => 'PRISM GLOW', 'expression' => 'Changed Light',
    'price' => 4190, 'image' => 'assets/images/pp.webp',
    'family' => 'Fruity Floral',
    'best_for' => 'Daytime, Social occasions, Playful wear',
    'top_notes' => 'Pink Pepper, Bergamot, Cassis',
    'heart_notes' => 'Pear, Peony, Freesia',
    'base_notes' => 'White Musk, Cedarwood, Powdery Amber',
    'home_description' => 'Light that shifts and shimmers, playful and bright.',
    'conclusion' => 'Prism Glow is light broken into colour — a bright fruity floral that shifts through juicy pear, soft peony and a clean musky base.',
    'accent' => '#c94f7c',
  ],
  [
    'slug' => 'soft-shimmer', 'collection' => 'eclat',
    'name' => 'SOFT SHIMMER', 'expression' => 'Gentle Sparkle',
    'price' => 4190, 'image' => 'assets/images/pf1.webp',
    'family' => 'Floral Musk',
    'best_for' => 'Everyday wear, Work, Delicate occasions',
    'top_notes' => 'Lychee, Pear, Light Bergamot',
    'heart_notes' => 'Jasmine, White Peony, Lily of the Valley',
    'base_notes' => 'Musk, Sandalwood, Soft Amber',
    'home_description' => 'A hushed, delicate shimmer of clean florals and skin-like musk.',
    'conclusion' => 'Soft Shimmer is a gentle light — juicy lychee and white florals settled over warm musk, quiet enough for every day.',
    'accent' => '#c7a9c9',
  ],
  [
    'slug' => 'dawn-lumen', 'collection' => 'eclat',
    'name' => 'DAWN LUMEN', 'expression' => 'First Light',
    'price' => 4190, 'image' => 'assets/images/nc.webp',
    'family' => 'Citrus Aromatic',
    'best_for' => 'Morning wear, Fresh occasions, Active days',
    'top_notes' => 'Mandarin, Grapefruit, Petitgrain',
    'heart_notes' => 'Neroli, Lavender, Sage',
    'base_notes' => 'Musk, Iso E Super, Light Woods',
    'home_description' => 'The clear, active brightness of first morning light.',
    'conclusion' => 'Dawn Lumen opens with the crisp light of early morning — vibrant citrus, calming herbs and a clean airy base that stays bright through the day.',
    'accent' => '#e0b64a',
  ],
  [
    'slug' => 'solar-vow', 'collection' => 'eclat',
    'name' => 'SOLAR VOW', 'expression' => 'Radiant Resolve',
    'price' => 4490, 'image' => 'assets/images/st.webp',
    'family' => 'Amber Woody',
    'best_for' => 'Evening wear, Formal occasions, Confidence',
    'top_notes' => 'Saffron, Pink Pepper, Bergamot',
    'heart_notes' => 'Leather Accord, Cedarwood, Rose',
    'base_notes' => 'Amber, Vetiver, Vanilla, Musk',
    'home_description' => 'A confident warmth that promises to be remembered.',
    'conclusion' => 'Solar Vow is radiance with conviction — saffron and leather warmed by amber and vetiver, a glowing trail of quiet confidence.',
    'accent' => '#b3563a',
  ],

  // ---------------- AURÉOLE (golden warmth) ----------------
  [
    'slug' => 'gilded-embrace', 'collection' => 'aureole',
    'name' => 'GILDED EMBRACE', 'expression' => 'Golden Touch',
    'price' => 4390, 'image' => 'assets/images/eo.webp',
    'family' => 'Amber Saffron',
    'best_for' => 'Evening wear, Special occasions, Warm climates',
    'top_notes' => 'Saffron, Cardamom, Bergamot',
    'heart_notes' => 'Rose, Orris, Amber Accord',
    'base_notes' => 'Amber, Vanilla, Sandalwood, Musk',
    'home_description' => 'A gilded, resinous warmth that wraps the wearer in golden light.',
    'conclusion' => 'Gilded Embrace is a halo of saffron and amber — opulent, warm and soft, like light itself gathered close.',
    'accent' => '#b4832f',
  ],
  [
    'slug' => 'molten-honey', 'collection' => 'aureole',
    'name' => 'MOLTEN HONEY', 'expression' => 'Golden Melt',
    'price' => 4490, 'image' => 'assets/images/ma.webp',
    'family' => 'Honeyed Gourmand',
    'best_for' => 'Cozy evenings, Autumn wear, Sweet lovers',
    'top_notes' => 'Honey, Mandarin, Immortelle',
    'heart_notes' => 'Orange Blossom, Jasmine, Cinnamon',
    'base_notes' => 'Vanilla, Tonka, Amber, White Musk',
    'home_description' => 'Thick, molten honey warmed by spice and amber.',
    'conclusion' => 'Molten Honey pours slow and golden — sweet honey and candied citrus over a warm vanilla amber base that glows for hours.',
    'accent' => '#c08a1e',
  ],
  [
    'slug' => 'amber-wreath', 'collection' => 'aureole',
    'name' => 'AMBER WREATH', 'expression' => 'Circle of Warmth',
    'price' => 4390, 'image' => 'assets/images/st.webp',
    'family' => 'Amber Spice',
    'best_for' => 'Evening wear, Winter occasions, Cozy settings',
    'top_notes' => 'Cinnamon, Nutmeg, Pink Pepper',
    'heart_notes' => 'Clove, Amber Accord, Cistus',
    'base_notes' => 'Benzoin, Vanilla, Tonka, Cedarwood',
    'home_description' => 'A rounded, encircling warmth of resin and spice.',
    'conclusion' => 'Amber Wreath closes around you like a warm ring — cinnamon and resin over benzoin and tonka, comforting and endless.',
    'accent' => '#9c6b2f',
  ],
  [
    'slug' => 'radiant-tonka', 'collection' => 'aureole',
    'name' => 'RADIANT TONKA', 'expression' => 'Burnt Sugar Glow',
    'price' => 4490, 'image' => 'assets/images/pf1.webp',
    'family' => 'Tonka Gourmand',
    'best_for' => 'Date nights, Evening wear, Sweet moments',
    'top_notes' => 'Caramelized Sugar, Bergamot, Raspberry',
    'heart_notes' => 'Tonka Bean, Heliotrope, Vanilla',
    'base_notes' => 'Tonka, Amber, Praline, Musk',
    'home_description' => 'A golden, toasted sweetness with a soft amber burn.',
    'conclusion' => 'Radiant Tonka glows like sugar over flame — juicy top notes melting into creamy tonka, praline and warm amber.',
    'accent' => '#b0783a',
  ],
  [
    'slug' => 'halo-oud', 'collection' => 'aureole',
    'name' => 'HALO OUD', 'expression' => 'Smoke Ring',
    'price' => 4690, 'image' => 'assets/images/sc.webp',
    'family' => 'Woody Oud',
    'best_for' => 'Statement evenings, Special occasions, Oud lovers',
    'top_notes' => 'Saffron, Cardamom, Incense',
    'heart_notes' => 'Oud, Rose, Patchouli',
    'base_notes' => 'Amber, Vetiver, Leather, Musk',
    'home_description' => 'A luminous ring of smoke-warmed oud and incense.',
    'conclusion' => 'Halo Oud is smoke held in a circle of light — saffron and incense opening onto rich oud and rose, grounded in amber and vetiver.',
    'accent' => '#5b4a3a',
  ],

  // ---------------- VESPÈRE (night) ----------------
  [
    'slug' => 'nocturne-petal', 'collection' => 'vespere',
    'name' => 'NOCTURNE PETAL', 'expression' => 'Midnight Bloom',
    'price' => 4590, 'image' => 'assets/images/ma.webp',
    'family' => 'Floral Amber',
    'best_for' => 'Evening wear, Night occasions, Romantic settings',
    'top_notes' => 'Blackcurrant, Bergamot, Pink Pepper',
    'heart_notes' => 'Night Jasmine, Tuberose, Dark Rose',
    'base_notes' => 'Amber, Patchouli, Musk, Vanilla',
    'home_description' => 'A dark bloom that opens only after the sun has gone.',
    'conclusion' => 'Nocturne Petal unfolds in the dark — heady night florals brightened by blackcurrant and weighted with amber and patchouli.',
    'accent' => '#5c2a3e',
  ],
  [
    'slug' => 'embers-at-dusk', 'collection' => 'vespere',
    'name' => 'EMBERS AT DUSK', 'expression' => 'Smouldering Light',
    'price' => 4590, 'image' => 'assets/images/rs.webp',
    'family' => 'Woody Spice',
    'best_for' => 'Autumn evenings, Cooler weather, Cosy nights',
    'top_notes' => 'Embers Accord, Nutmeg, Pepper',
    'heart_notes' => 'Cedarwood, Cinnamon, Labdanum',
    'base_notes' => 'Vetiver, Amber, Tonka, Musk',
    'home_description' => 'The warm, smoky glow of fire as night falls.',
    'conclusion' => 'Embers at Dusk holds the last warmth of a dying fire — pepper and smoke settling into cedar, amber and vetiver under a clear night sky.',
    'accent' => '#a14624',
  ],
  [
    'slug' => 'velvet-midnight', 'collection' => 'vespere',
    'name' => 'VELVET MIDNIGHT', 'expression' => 'Silent Depth',
    'price' => 4690, 'image' => 'assets/images/sc.webp',
    'family' => 'Velvet Woody',
    'best_for' => 'Formal evenings, Special gatherings, Signature wear',
    'top_notes' => 'Black Pepper, Bergamot, Violet Leaf',
    'heart_notes' => 'Iris, Peru Balsam, Cedarwood',
    'base_notes' => 'Leather, Amber, Sandalwood, Musk',
    'home_description' => 'A deep, velvet darkness — smooth, quiet and commanding.',
    'conclusion' => 'Velvet Midnight is the hush before dawn — violet and iris layered over leather, amber and sandalwood in smooth, silent depth.',
    'accent' => '#3b3150',
  ],
  [
    'slug' => 'lune-dargent', 'collection' => 'vespere',
    'name' => 'LUNE D’ARGENT', 'expression' => 'Silver Moon',
    'price' => 4690, 'image' => 'assets/images/nc.webp',
    'family' => 'Aldehydic Musk',
    'best_for' => 'Cool evenings, Minimal occasions, Crisp nights',
    'top_notes' => 'Aldehydes, Bergamot, Silver Accord',
    'heart_notes' => 'White Flowers, Sage, Orris',
    'base_notes' => 'Musk, Cashmeran, Light Woods',
    'home_description' => 'A cool, silvered light that gleams beneath the moon.',
    'conclusion' => 'Lune d’Argent is moonlight made wearable — crisp aldehydes and white flowers over cool musk, sharp yet impossibly smooth.',
    'accent' => '#8b94a8',
  ],
  [
    'slug' => 'obsidian-veil', 'collection' => 'vespere',
    'name' => 'OBSIDIAN VEIL', 'expression' => 'Dark Reserve',
    'price' => 4790, 'image' => 'assets/images/st.webp',
    'family' => 'Dark Woody',
    'best_for' => 'Statement evenings, Night events, Distinctive wear',
    'top_notes' => 'Incense, Black Pepper, Pink Pepper',
    'heart_notes' => 'Oud, Patchouli, Leather',
    'base_notes' => 'Amber, Vetiver, Charred Woods, Musk',
    'home_description' => 'A sharp, glassy darkness with a warm smouldering core.',
    'conclusion' => 'Obsidian Veil is the night sharpened — incense and black pepper over smoky oud, charred woods and warm amber, dark and unforgettable.',
    'accent' => '#2c2c30',
  ],
];

$prodIds = [];
$insProduct = $pdo->prepare(
  'INSERT INTO products
     (slug, collection_id, name, expression, price, image, meta, family, best_for, top_notes, heart_notes, base_notes, home_description, conclusion, accent, featured, sort_order, is_active)
   VALUES
     (:slug, :collection_id, :name, :expression, :price, :image, :meta, :family, :best_for, :top_notes, :heart_notes, :base_notes, :home_description, :conclusion, :accent, 0, :sort_order, 1)'
);

// track per-collection sort order
$sortCounter = [];

foreach ($products as $i => $pr) {
  // skip if product slug already exists
  $chk = $pdo->prepare('SELECT product_id, collection_id FROM products WHERE slug = ? LIMIT 1');
  $chk->execute([$pr['slug']]);
  $existing = $chk->fetch();

  $colKey = $pr['collection'];
  if (!isset($sortCounter[$colKey])) {
    // find current max sort_order in that collection
    $m = $pdo->prepare('SELECT COALESCE(MAX(sort_order),0) FROM products WHERE collection_id = ?');
    $m->execute([$colById[$colKey]]);
    $sortCounter[$colKey] = (int) $m->fetchColumn();
  }

  $sortOrder = $pr['slug'] === 'afterglow' ? 1 : (++$sortCounter[$colKey]);

  if ($existing) {
    echo '  product exists (skip): ' . $pr['name'] . "\n";
    $prodIds[$pr['slug']] = (int) $existing['product_id'];
    continue;
  }

  $insProduct->execute([
    ':slug'          => $pr['slug'],
    ':collection_id' => $colById[$colKey],
    ':name'          => $pr['name'],
    ':expression'    => $pr['expression'],
    ':price'         => $pr['price'],
    ':image'         => $pr['image'],
    ':meta'          => $META,
    ':family'        => $pr['family'],
    ':best_for'      => $pr['best_for'],
    ':top_notes'     => $pr['top_notes'],
    ':heart_notes'   => $pr['heart_notes'],
    ':base_notes'    => $pr['base_notes'],
    ':home_description' => $pr['home_description'],
    ':conclusion'    => $pr['conclusion'],
    ':accent'        => $pr['accent'],
    ':sort_order'    => $sortOrder,
  ]);
  $prodIds[$pr['slug']] = (int) $pdo->lastInsertId();
  echo '  product: ' . $pr['name'] . "\n";
}

/* ------------------------------------------------------------
   TESTER PACKS (database-driven, one per collection)
------------------------------------------------------------ */

$testerSets = [
  [
    'slug'            => 'eclat-set',
    'collection'      => 'eclat',
    'name'            => 'ÉCLAT DISCOVERY SET',
    'subtitle'        => 'Six expressions of light.',
    'card_subtitle'   => 'Six expressions · 6 × 5ml',
    'price'           => 2590,
    'includes'        => '6 × 5ml fragrances',
    'concentration'   => 'Extrait de Parfum',
    'size_label'      => '6 × 5ml',
    'intro'           => 'Experience all six Éclat fragrances and discover which radiant expression feels most like your own.',
    'olfactory_intro' => 'Six radiant scent directions. Compare their luminous character and find the glow that stays with you.',
    'product_order'   => ['afterglow', 'golden-hour', 'prism-glow', 'soft-shimmer', 'dawn-lumen', 'solar-vow'],
    'sort_order'      => 2,
  ],
  [
    'slug'            => 'aureole-set',
    'collection'      => 'aureole',
    'name'            => 'AURÉOLE DISCOVERY SET',
    'subtitle'        => 'Five expressions of golden warmth.',
    'card_subtitle'   => 'Five expressions · 5 × 5ml',
    'price'           => 2490,
    'includes'        => '5 × 5ml fragrances',
    'concentration'   => 'Extrait de Parfum',
    'size_label'      => '5 × 5ml',
    'intro'           => 'Experience all five Auréole fragrances and find the golden warmth that feels most like your own.',
    'olfactory_intro' => 'Five golden scent directions. Compare their amber glow and discover the warmth that stays closest to you.',
    'product_order'   => ['gilded-embrace', 'molten-honey', 'amber-wreath', 'radiant-tonka', 'halo-oud'],
    'sort_order'      => 3,
  ],
  [
    'slug'            => 'vespere-set',
    'collection'      => 'vespere',
    'name'            => 'VESPÈRE DISCOVERY SET',
    'subtitle'        => 'Five expressions of the night.',
    'card_subtitle'   => 'Five expressions · 5 × 5ml',
    'price'           => 2690,
    'includes'        => '5 × 5ml fragrances',
    'concentration'   => 'Extrait de Parfum',
    'size_label'      => '5 × 5ml',
    'intro'           => 'Experience all five Vespère fragrances and find the nocturnal expression that feels most like your own.',
    'olfactory_intro' => 'Five nocturnal scent directions. Compare their darkened depths and discover the one that stays with you.',
    'product_order'   => ['nocturne-petal', 'embers-at-dusk', 'velvet-midnight', 'lune-dargent', 'obsidian-veil'],
    'sort_order'      => 4,
  ],
];

$insSet = $pdo->prepare(
  'INSERT INTO tester_sets (slug, name, subtitle, card_subtitle, price, image, intro, olfactory_intro, includes, collection_id, concentration, size_label, sort_order, is_active)
   VALUES (:slug, :name, :subtitle, :card_subtitle, :price, :image, :intro, :olfactory_intro, :includes, :collection_id, :concentration, :size_label, :sort_order, 1)'
);
$insSetItem = $pdo->prepare(
  'INSERT INTO tester_set_items (set_id, product_id, position) VALUES (?, ?, ?)'
);

foreach ($testerSets as $set) {
  $chk = $pdo->prepare('SELECT set_id FROM tester_sets WHERE slug = ? LIMIT 1');
  $chk->execute([$set['slug']]);
  $existingSet = $chk->fetch();

  $collectionId = $colById[$set['collection']];

  if ($existingSet) {
    $setId = (int) $existingSet['set_id'];
    echo '  tester set exists (skip): ' . $set['name'] . "\n";
  } else {
    $image = $collectionId === $initialeId
      ? 'assets/images/tester_bottles.webp'
      : 'assets/images/testing_tester_pack.webp';
    if (!file_exists(__DIR__ . '/../' . $image)) {
      $image = 'assets/images/tester_bottles.webp';
    }
    $insSet->execute([
      ':slug'            => $set['slug'],
      ':name'            => $set['name'],
      ':subtitle'        => $set['subtitle'],
      ':card_subtitle'   => $set['card_subtitle'],
      ':price'           => $set['price'],
      ':image'           => $image,
      ':intro'           => $set['intro'],
      ':olfactory_intro' => $set['olfactory_intro'],
      ':includes'        => $set['includes'],
      ':collection_id'   => $collectionId,
      ':concentration'   => $set['concentration'],
      ':size_label'      => $set['size_label'],
      ':sort_order'      => $set['sort_order'],
    ]);
    $setId = (int) $pdo->lastInsertId();
    echo '  tester set: ' . $set['name'] . "\n";
  }

  // items (ensure at least present)
  $hasItems = $pdo->prepare('SELECT COUNT(*) FROM tester_set_items WHERE set_id = ?');
  $hasItems->execute([$setId]);
  if ((int) $hasItems->fetchColumn() === 0) {
    $pos = 1;
    foreach ($set['product_order'] as $slug) {
      if (isset($prodIds[$slug])) {
        $insSetItem->execute([$setId, $prodIds[$slug], $pos++]);
      }
    }
    echo '  tester items added: ' . ($pos - 1) . "\n";
  }
}

/* ------------------------------------------------------------
   PRODUCT STORIES (3 chapters each for new products)
------------------------------------------------------------ */

$chapterImages = [
  1 => 'assets/images/nc-opening.webp',
  2 => 'assets/images/nc-heart.webp',
  3 => 'assets/images/nc-base.webp',
];

$stories = [
  'golden-hour' => [
    [1, '01 / The Opening', 'THE WARMTH BEGINS', 'Bergamot and bitter orange open with a bright, almost liquid warmth, while neroli softens the edge. The first impression is of sunlight caught between the last hours of day.'],
    [2, '02 / The Heart', 'HONEYED BLOOM', 'Orange blossom and ylang ylang glow at the center, wrapped in a gentle honey accord. The florals feel golden rather than sharp, soft and luminous.'],
    [3, '03 / The Drydown', 'DUSK, HELD STILL', 'Amber, vanilla and tonka settle into a smooth base that lingers like the last light of day. Musk keeps it close and warm, the hour captured and kept.'],
  ],
  'prism-glow' => [
    [1, '01 / The Opening', 'LIGHT, BROKEN', 'Pink pepper and bergamot snap with brightness as cassis adds a touch of juicy depth. The opening moves quickly, playful and alive.'],
    [2, '02 / The Heart', 'A GLOW OF FLORALS', 'Juicy pear meets soft peony and freesia, turning the brightness into a rounded, shimmering warmth. Light seems to colour the composition here.'],
    [3, '03 / The Drydown', 'THE SOFT AFTERTHOUGHT', 'White musk and powdery amber gather over cedarwood. What began sharp settles into a clean, lingering glow.'],
  ],
  'soft-shimmer' => [
    [1, '01 / The Opening', 'A QUIET LIGHT', 'Lychee and pear open with a delicate, watery sweetness, softened by a whisper of bergamot. The start is gentle, almost translucent.'],
    [2, '02 / The Heart', 'WHITE PETALS', 'Jasmine, white peony and lily of the valley unfold in clean, powdery florals. The center feels hushed and refined.'],
    [3, '03 / The Drydown', 'SKIN-LIKE MUSK', 'Warm musk and sandalwood carry into the finish with a touch of soft amber. The glow becomes intimate, close to the skin.'],
  ],
  'dawn-lumen' => [
    [1, '01 / The Opening', 'THE DAY BEGINS', 'Mandarin, grapefruit and petitgrain open with the crisp, clear energy of first light. The citrus is bright without being sharp.'],
    [2, '02 / The Heart', 'CLEAR COMPOSURE', 'Neroli, lavender and sage shape a calm, aromatic center. The freshness becomes collected and focused.'],
    [3, '03 / The Drydown', 'LIGHT THAT REMAINS', 'Clean woods and a soft musky base carry the brightness forward. What begins as morning settles into steady, active clarity.'],
  ],
  'solar-vow' => [
    [1, '01 / The Opening', 'A BOLD GLOW', 'Saffron and pink pepper open with a warm, confident spark, grounded by bergamot. The first impression radiates.'],
    [2, '02 / The Heart', 'STRENGTH IN WARMTH', 'A smooth leather accord meets cedarwood and rose, carrying the warmth with poise. The center is assured and polished.'],
    [3, '03 / The Drydown', 'THE PROMISE KEPT', 'Amber, vetiver and vanilla melt together into a lasting trail. Musk keeps the vow close, golden and unforgettable.'],
  ],
  'gilded-embrace' => [
    [1, '01 / The Opening', 'A GILDED TOUCH', 'Saffron and cardamom open with a warm, opulent glow, lifted by bergamot. The start feels precious and immediate.'],
    [2, '02 / The Heart', 'WARMTH, WRAPPED', 'Rose and orris fold into amber at the center, softening the richness. The composition becomes an embrace rather than a statement.'],
    [3, '03 / The Drydown', 'GOLD, HELD CLOSE', 'Amber, vanilla and sandalwood settle over musk, gathering into a smooth, radiant warmth that stays near the skin.'],
  ],
  'molten-honey' => [
    [1, '01 / The Opening', 'THE POUR', 'Honey and candied mandarin open thick and golden, warmed by immortelle. The first sense is of something melting slowly.'],
    [2, '02 / The Heart', 'A SWEET GLOW', 'Orange blossom and jasmine meet cinnamon, turning sweetness into warmth. The center hums like a slow flame.'],
    [3, '03 / The Drydown', 'THE LAST EMBER', 'Vanilla, tonka and amber fold into white musk, leaving a smooth, honeyed glow that lingers long.'],
  ],
  'amber-wreath' => [
    [1, '01 / The Opening', 'THE RING BEGINS', 'Cinnamon and nutmeg open with a soft, rounded warmth, lifted by pink pepper. The first movement circles gently.'],
    [2, '02 / The Heart', 'RESIN AND SPICE', 'Clove and cistus deepen into labdanum-soaked amber. The composition closes its circle, warm and enveloping.'],
    [3, '03 / The Drydown', 'ENDLESS WARMTH', 'Benzoin, vanilla and tonka settle over cedarwood, completing the wreath. The warmth is comforting, steady and endless.'],
  ],
  'radiant-tonka' => [
    [1, '01 / The Opening', 'SUGAR, TOASTED', 'Caramelized sugar and bergamot open with a bright, toasted sweetness, edged by raspberry. The start glows.'],
    [2, '02 / The Heart', 'THE CREAMY CENTER', 'Tonka bean and heliotrope meet vanilla, softening the sweetness into cream. The center is smooth and radiant.'],
    [3, '03 / The Drydown', 'A GOLDEN BURN', 'Tonka, praline and amber settle over musk. The finish is warm, toasted and softly sweet — the glow of sugar over flame.'],
  ],
  'halo-oud' => [
    [1, '01 / The Opening', 'SMOKE, IGNITED', 'Saffron and cardamom open with a sharp warmth as incense rises. The start feels sacred and luminous.'],
    [2, '02 / The Heart', 'OUD IN LIGHT', 'Rich oud meets dark rose and patchouli at the center. The smoke gathers, held in a circle of warmth.'],
    [3, '03 / The Drydown', 'THE LINGERING HALO', 'Amber, vetiver, leather and musk settle beneath the oud. The glow remains — smoke-warmed, radiant and deep.'],
  ],
  'nocturne-petal' => [
    [1, '01 / The Opening', 'THE DARK OPENING', 'Blackcurrant and bergamot open with a deep, almost wine-dark richness, edged by pink pepper. The night begins.'],
    [2, '02 / The Heart', 'A BLOOMING DARK', 'Night jasmine, tuberose and dark rose unfurl in the center. Heady and lush, the florals come alive as the light fades.'],
    [3, '03 / The Drydown', 'UNDER THE MOON', 'Amber, patchouli, musk and vanilla settle into a warm, weighted base. The bloom lingers softly into the small hours.'],
  ],
  'embers-at-dusk' => [
    [1, '01 / The Opening', 'THE LAST GLOW', 'An embers accord opens with nutmeg and pepper, recalling a fire settling into ash. The warmth is low and steady.'],
    [2, '02 / The Heart', 'SMOKE AND WOOD', 'Cedarwood and cinnamon meet labdanum, carrying the embers with a resinous depth. The center feels like cooling smoke.'],
    [3, '03 / The Drydown', 'NIGHT SETTLES', 'Vetiver, amber, tonka and musk gather as the light finally leaves. The fire becomes memory, warm and quiet.'],
  ],
  'velvet-midnight' => [
    [1, '01 / The Opening', 'THE DARK UNFOLDS', 'Black pepper and violet leaf open with a crisp, cool sharpness, lifted by bergamot. The start is poised and restrained.'],
    [2, '02 / The Heart', 'SILKEN IRIS', 'Iris and Peru balsam meet cedarwood, smoothing the composition into velvet. The center is quiet and commandingly elegant.'],
    [3, '03 / The Drydown', 'THE DEEP HUSH', 'Leather, amber, sandalwood and musk settle into a smooth, dark base. Real depth is carried in near silence.'],
  ],
  'lune-dargent' => [
    [1, '01 / The Opening', 'SILVERED AIR', 'Aldehydes and bergamot open with a crisp, cool gleam, edged by a silver accord. The start feels almost weightless.'],
    [2, '02 / The Heart', 'A COOL BLOOM', 'White flowers, sage and orris soften the center with a clean, lunar brightness. The composition stays refined and airy.'],
    [3, '03 / The Drydown', 'MOONLIGHT GATHERED', 'Musk, cashmeran and light woods settle into a cool, smooth finish. It gleams softly, sharp yet gently held.'],
  ],
  'obsidian-veil' => [
    [1, '01 / The Opening', 'THE SHARP EDGE', 'Incense and black pepper open with a dark, angular brightness. The start is immediate and commanding.'],
    [2, '02 / The Heart', 'THE SMOKING CORE', 'Oud, patchouli and leather gather at the center, framing the darkness with smoky warmth. The composition sharpens into focus.'],
    [3, '03 / The Drydown', 'THE VEIL HOLDS', 'Amber, vetiver, charred woods and musk settle beneath. A glassy blackness with a warm, smouldering heart — dark and unforgettable.'],
  ],
];

$chkStory = $pdo->prepare('SELECT COUNT(*) FROM product_stories WHERE product_id = ? AND chapter_no = ?');

foreach ($stories as $slug => $chapters) {
  if (!isset($prodIds[$slug])) {
    continue;
  }
  $pid = $prodIds[$slug];
  $added = 0;
  foreach ($chapters as $chapter) {
    $chkStory->execute([$pid, $chapter[0]]);
    if ((int) $chkStory->fetchColumn() > 0) {
      continue;
    }
    $insStory = $pdo->prepare(
      'INSERT INTO product_stories (product_id, chapter_no, kicker, title, copy, image) VALUES (?, ?, ?, ?, ?, ?)'
    );
    $insStory->execute([$pid, $chapter[0], $chapter[1], $chapter[2], $chapter[3], $chapterImages[$chapter[0]]]);
    $added++;
  }
  echo '  story chapters added for ' . $slug . ': ' . $added . "\n";
}

echo "\nDone.\n";
