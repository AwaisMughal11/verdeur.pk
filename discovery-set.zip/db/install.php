<?php

declare(strict_types=1);

/* =========================================
   VERDEUR — DATABASE INSTALLER
   CLI only. Creates verdeur_db tables and
   seeds them from the site's product files.
========================================= */

if (PHP_SAPI !== 'cli') {
  http_response_code(403);
  exit('CLI only');
}

require_once __DIR__ . '/../config.php';

$pdo = new PDO(
  sprintf(
    'mysql:host=%s;charset=%s',
    VERDEUR_DB_HOST,
    VERDEUR_DB_CHARSET
  ),
  VERDEUR_DB_USER,
  VERDEUR_DB_PASS,
  [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

$pdo->exec(sprintf(
  'CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET %s COLLATE %s_unicode_ci',
  VERDEUR_DB_NAME,
  VERDEUR_DB_CHARSET,
  VERDEUR_DB_CHARSET
));

$pdo->exec('USE `' . VERDEUR_DB_NAME . '`');


$pdo->exec('SET FOREIGN_KEY_CHECKS = 0');

foreach ([
  'order_items',
  'orders',
  'tester_set_items',
  'tester_sets',
  'product_stories',
  'testimonials',
  'customer_queries',
  'newsletter_subscribers',
  'products',
  'collections',
  'bank_accounts',
  'legal_pages',
  'site_settings',
] as $table) {
  $pdo->exec('DROP TABLE IF EXISTS `' . $table . '`');
}

$pdo->exec('SET FOREIGN_KEY_CHECKS = 1');


$pdo->exec(<<<SQL
CREATE TABLE `collections` (
  `collection_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug` VARCHAR(60) NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `kicker` VARCHAR(180) NOT NULL DEFAULT '',
  `subtitle` VARCHAR(120) NOT NULL DEFAULT '',
  `description` TEXT NOT NULL,
  `count_label` VARCHAR(120) NOT NULL DEFAULT '',
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`collection_id`),
  UNIQUE KEY `uq_collections_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `products` (
  `product_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug` VARCHAR(80) NOT NULL,
  `collection_id` INT UNSIGNED NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `expression` VARCHAR(120) NOT NULL DEFAULT '',
  `price` INT NOT NULL DEFAULT 0,
  `image` VARCHAR(200) NOT NULL DEFAULT '',
  `meta` VARCHAR(120) NOT NULL DEFAULT '',
  `family` VARCHAR(80) NOT NULL DEFAULT '',
  `best_for` VARCHAR(255) NOT NULL DEFAULT '',
  `top_notes` TEXT NOT NULL,
  `heart_notes` TEXT NOT NULL,
  `base_notes` TEXT NOT NULL,
  `home_description` VARCHAR(255) NOT NULL DEFAULT '',
  `conclusion` TEXT NOT NULL,
  `accent` VARCHAR(12) NOT NULL DEFAULT '#000000',
  `featured` TINYINT(1) NOT NULL DEFAULT 0,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `uq_products_slug` (`slug`),
  KEY `idx_products_collection` (`collection_id`),
  CONSTRAINT `fk_products_collection`
    FOREIGN KEY (`collection_id`) REFERENCES `collections` (`collection_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `product_stories` (
  `story_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL,
  `chapter_no` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `kicker` VARCHAR(60) NOT NULL DEFAULT '',
  `title` VARCHAR(120) NOT NULL DEFAULT '',
  `copy` TEXT NOT NULL,
  `image` VARCHAR(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`story_id`),
  KEY `idx_stories_product` (`product_id`),
  CONSTRAINT `fk_stories_product`
    FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `tester_sets` (
  `set_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug` VARCHAR(80) NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `subtitle` VARCHAR(180) NOT NULL DEFAULT '',
  `card_subtitle` VARCHAR(180) NOT NULL DEFAULT '',
  `price` INT NOT NULL DEFAULT 0,
  `image` VARCHAR(200) NOT NULL DEFAULT '',
  `intro` TEXT NOT NULL,
  `olfactory_intro` TEXT NOT NULL,
  `includes` VARCHAR(120) NOT NULL DEFAULT '',
  `collection_id` INT UNSIGNED NULL,
  `concentration` VARCHAR(80) NOT NULL DEFAULT '',
  `size_label` VARCHAR(60) NOT NULL DEFAULT '',
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`set_id`),
  UNIQUE KEY `uq_tester_sets_slug` (`slug`),
  KEY `idx_tester_sets_collection` (`collection_id`),
  CONSTRAINT `fk_tester_sets_collection`
    FOREIGN KEY (`collection_id`) REFERENCES `collections` (`collection_id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `tester_set_items` (
  `item_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `set_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `position` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `uq_set_product` (`set_id`, `product_id`),
  KEY `idx_set_items_product` (`product_id`),
  CONSTRAINT `fk_set_items_set`
    FOREIGN KEY (`set_id`) REFERENCES `tester_sets` (`set_id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_set_items_product`
    FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `customer_queries` (
  `query_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `subject` VARCHAR(190) NOT NULL DEFAULT '',
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`query_id`),
  KEY `idx_queries_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `testimonials` (
  `testimonial_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NULL,
  `customer_name` VARCHAR(120) NOT NULL,
  `quote` TEXT NOT NULL,
  `label` VARCHAR(120) NOT NULL DEFAULT '',
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`testimonial_id`),
  KEY `idx_testimonials_product` (`product_id`),
  CONSTRAINT `fk_testimonials_product`
    FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `bank_accounts` (
  `account_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(120) NOT NULL,
  `bank_name` VARCHAR(120) NOT NULL,
  `account_title` VARCHAR(190) NOT NULL,
  `account_number` VARCHAR(60) NOT NULL,
  `iban` VARCHAR(60) NOT NULL DEFAULT '',
  `branch` VARCHAR(190) NOT NULL DEFAULT '',
  `qr_image` VARCHAR(200) NOT NULL DEFAULT '',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `site_settings` (
  `setting_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(80) NOT NULL,
  `setting_value` TEXT NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `uq_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `newsletter_subscribers` (
  `subscriber_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(190) NOT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`subscriber_id`),
  UNIQUE KEY `uq_subscribers_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `legal_pages` (
  `page_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slug` VARCHAR(80) NOT NULL,
  `title` VARCHAR(190) NOT NULL,
  `kicker` VARCHAR(190) NOT NULL DEFAULT '',
  `intro` TEXT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `uq_legal_pages_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `orders` (
  `order_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_number` VARCHAR(40) NOT NULL,
  `customer_name` VARCHAR(120) NOT NULL,
  `customer_phone` VARCHAR(40) NOT NULL,
  `customer_email` VARCHAR(190) NOT NULL DEFAULT '',
  `customer_address` VARCHAR(255) NOT NULL,
  `customer_city` VARCHAR(80) NOT NULL,
  `customer_province` VARCHAR(120) NOT NULL,
  `customer_notes` TEXT NULL,
  `subtotal` INT NOT NULL DEFAULT 0,
  `shipping` INT NOT NULL DEFAULT 0,
  `total` INT NOT NULL DEFAULT 0,
  `payment_method` VARCHAR(60) NOT NULL DEFAULT 'Bank Transfer',
  `order_status` VARCHAR(60) NOT NULL DEFAULT 'Pending',
  `payment_status` VARCHAR(60) NOT NULL DEFAULT 'Pending',
  `bank_account_id` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `uq_orders_number` (`order_number`),
  KEY `idx_orders_order_status` (`order_status`),
  KEY `idx_orders_payment_status` (`payment_status`),
  KEY `idx_orders_bank` (`bank_account_id`),
  CONSTRAINT `fk_orders_bank`
    FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`account_id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

$pdo->exec(<<<SQL
CREATE TABLE `order_items` (
  `item_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NULL,
  `item_key` VARCHAR(80) NOT NULL DEFAULT '',
  `item_name` VARCHAR(190) NOT NULL,
  `item_meta` VARCHAR(190) NOT NULL DEFAULT '',
  `unit_price` INT NOT NULL DEFAULT 0,
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `line_total` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_id`),
  KEY `idx_order_items_order` (`order_id`),
  KEY `idx_order_items_product` (`product_id`),
  CONSTRAINT `fk_order_items_order`
    FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_order_items_product`
    FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);


$collections = [
  [
    'slug'         => 'initiale',
    'name'         => 'Initialé',
    'kicker'       => "Verdeur's First Collection",
    'subtitle'     => 'The Beginning of Verdeur',
    'description'  => 'Initialé brings together five fragrances, each shaped around a distinct expression of the human experience.',
    'count_label'  => 'Five fragrances · Five expressions',
    'sort_order'   => 1,
  ],
  [
    'slug'         => 'eclat',
    'name'         => 'Éclat',
    'kicker'       => '',
    'subtitle'     => '',
    'description'  => '',
    'count_label'  => '',
    'sort_order'   => 2,
  ],
];

$collectionIds = [];

$insCollection = $pdo->prepare(
  'INSERT INTO collections (slug, name, kicker, subtitle, description, count_label, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
);

foreach ($collections as $collection) {
  $insCollection->execute([
    $collection['slug'],
    $collection['name'],
    $collection['kicker'],
    $collection['subtitle'],
    $collection['description'],
    $collection['count_label'],
    $collection['sort_order'],
  ]);
  $collectionIds[$collection['slug']] = (int) $pdo->lastInsertId();
}


$products = [
  [
    'slug'            => 'pearls-and-petals',
    'collection'      => 'initiale',
    'name'            => 'PEARLS & PETALS',
    'expression'      => 'Refined Softness',
    'price'           => 3990,
    'image'           => 'assets/images/pp.webp',
    'meta'            => '50ml · Extrait de Parfum',
    'family'          => 'Floral Fruity',
    'best_for'        => 'Daytime, Social occasions, Elegant everyday wear',
    'top_notes'       => 'Pineapple, Bergamot, Lychee, Jasmine, Pink Pepper',
    'heart_notes'     => 'Turkish Rose, Mirabelle Plum, Gardenia, Oakmoss, Freesia',
    'base_notes'      => 'Vanilla, Sandalwood, Amber, Musk',
    'home_description'=> 'A delicate expression shaped around softness, elegance and quiet presence.',
    'conclusion'      => 'A composition where luminous fruit, unfolding florals and a soft warm base come together as an expression of elegance, tenderness and refined softness.',
    'accent'          => '#b44260',
    'featured'        => 1,
    'sort_order'      => 1,
  ],
  [
    'slug'            => 'next-chapter',
    'collection'      => 'initiale',
    'name'            => 'NEXT CHAPTER',
    'expression'      => 'New Beginnings',
    'price'           => 3990,
    'image'           => 'assets/images/nc.webp',
    'meta'            => '50ml · Extrait de Parfum',
    'family'          => 'Fresh Aquatic',
    'best_for'        => 'Daily wear, Office, Meetings, Professional environments',
    'top_notes'       => 'Bergamot, Grapefruit, Mandarin Orange, Marine Accords',
    'heart_notes'     => 'Sage, Lavender, Geranium, Rosemary',
    'base_notes'      => 'Amberwood, Patchouli, Vetiver, Musk',
    'home_description'=> 'A fresh expression of clarity, confidence and moving forward.',
    'conclusion'      => 'Next Chapter moves from brightness to composure and finally into grounded depth — an olfactory expression of transition, clarity and the confidence to move forward.',
    'accent'          => '#173968',
    'featured'        => 1,
    'sort_order'      => 2,
  ],
  [
    'slug'            => 'solitaire',
    'collection'      => 'initiale',
    'name'            => 'SOLITAIRE',
    'expression'      => 'Distinctive Presence',
    'price'           => 3990,
    'image'           => 'assets/images/st.webp',
    'meta'            => '50ml · Extrait de Parfum',
    'family'          => 'Woody Amber',
    'best_for'        => 'Evening wear, Formal occasions, Special gatherings, Signature scent seekers',
    'top_notes'       => 'Lavender, Cardamom, Pepper, Sweet Accords, Saffron',
    'heart_notes'     => 'Cinnamon, Smoky Accords, Soft Florals, Patchouli, Nutmeg',
    'base_notes'      => 'Vanilla, Amber, Musk, Tonka Bean, Fir Resin, Cedarwood',
    'home_description'=> 'An expression of individuality, character and presence without excess.',
    'conclusion'      => 'Solitaire expresses distinctive presence through a rich, warm composition where spices, woods, amber and sweetness create depth, individuality and a memorable olfactory signature.',
    'accent'          => '#b18a4d',
    'featured'        => 1,
    'sort_order'      => 3,
  ],
  [
    'slug'            => 'musc-affair',
    'collection'      => 'initiale',
    'name'            => 'MUSC AFFAIR',
    'expression'      => 'Intimacy',
    'price'           => 3990,
    'image'           => 'assets/images/ma.webp',
    'meta'            => '50ml · Extrait de Parfum',
    'family'          => 'Musk Floral',
    'best_for'        => 'Close encounters, Evening wear, Personal signature scent',
    'top_notes'       => 'Lily of the Valley, White Flowers, Creamy Accents',
    'heart_notes'     => 'Powdery Vanilla, Musk',
    'base_notes'      => 'Sandalwood, Amber',
    'home_description'=> 'A close and enveloping expression shaped around warmth and intimacy.',
    'conclusion'      => 'Musc Affair expresses intimacy through a soft musk composition where clean florals, powdery warmth and smooth woods create a fragrance that feels close, comforting and personal.',
    'accent'          => '#9d9fa5',
    'featured'        => 1,
    'sort_order'      => 4,
  ],
  [
    'slug'            => 'rhythm-of-sandal',
    'collection'      => 'initiale',
    'name'            => 'RHYTHM OF SANDAL',
    'expression'      => 'Stillness',
    'price'           => 3990,
    'image'           => 'assets/images/rs.webp',
    'meta'            => '50ml · Extrait de Parfum',
    'family'          => 'Woody',
    'best_for'        => 'Relaxed moments, Evening wear, Sandalwood lovers',
    'top_notes'       => 'Subtle Spice, Fresh Woods',
    'heart_notes'     => 'Creamy Sandalwood, Soft Floral Nuances',
    'base_notes'      => 'Amber, Dry Woods, Musk',
    'home_description'=> 'A calm expression built around warmth, balance and quiet stillness.',
    'conclusion'      => 'Rhythm of Sandal expresses stillness through the timeless character of sandalwood. Its creamy warmth and smooth woody depth create a sense of balance, comfort and quiet reflection.',
    'accent'          => '#725b45',
    'featured'        => 1,
    'sort_order'      => 5,
  ],
  [
    'slug'            => 'afterglow',
    'collection'      => 'eclat',
    'name'            => 'AFTERGLOW',
    'expression'      => 'Quiet Radiance',
    'price'           => 4290,
    'image'           => 'assets/images/nc.webp',
    'meta'            => '50ml · Extrait de Parfum',
    'family'          => 'Amber Floral',
    'best_for'        => 'Cooler evenings, Dinner occasions, Special gatherings',
    'top_notes'       => 'Saffron, Bergamot, Pink Pepper',
    'heart_notes'     => 'Rose, Orris, Cashmere Musk',
    'base_notes'      => 'Amber, Vanilla Bean, Tonka Bean, Cedarwood',
    'home_description'=> '',
    'conclusion'      => 'Afterglow expresses quiet radiance through a warm amber glow — saffron-laced florals settling into velvet woods and a soft, lingering trail.',
    'accent'          => '#c0693f',
    'featured'        => 0,
    'sort_order'      => 1,
  ],
];

$productIds = [];

$insProduct = $pdo->prepare(
  'INSERT INTO products (slug, collection_id, name, expression, price, image, meta, family, best_for, top_notes, heart_notes, base_notes, home_description, conclusion, accent, featured, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)'
);

foreach ($products as $product) {
  $insProduct->execute([
    $product['slug'],
    $collectionIds[$product['collection']],
    $product['name'],
    $product['expression'],
    $product['price'],
    $product['image'],
    $product['meta'],
    $product['family'],
    $product['best_for'],
    $product['top_notes'],
    $product['heart_notes'],
    $product['base_notes'],
    $product['home_description'],
    $product['conclusion'],
    $product['accent'],
    $product['featured'],
    $product['sort_order'],
  ]);
  $productIds[$product['slug']] = (int) $pdo->lastInsertId();
}


$stories = [
  'pearls-and-petals' => [
    [1, '01 / The Opening', 'A BRIGHT SOFTNESS', 'Pineapple, bergamot and lychee bring a luminous fruitiness to the opening, while jasmine and pink pepper introduce a delicate floral lift and subtle contrast.'],
    [2, '02 / The Heart', 'PETALS IN BLOOM', 'Turkish rose, gardenia and freesia unfold through the heart, softened by the delicate fruitiness of Mirabelle plum. Oakmoss adds quiet depth beneath the floral composition.'],
    [3, '03 / The Drydown', 'SOFTLY GROUNDED', 'Vanilla and sandalwood soften the composition as it settles, while amber and musk create a smooth, warm foundation that keeps the fragrance refined and close.'],
  ],
  'next-chapter' => [
    [1, '01 / The Opening', 'CLARITY IN MOTION', 'Bergamot, grapefruit and mandarin open the fragrance with brightness and energy. Marine accords move through the citrus, bringing an airy freshness that feels clear, open and immediately alive.'],
    [2, '02 / The Heart', 'AROMATIC COMPOSURE', 'Sage, lavender, geranium and rosemary shape the heart with a clean aromatic structure. The freshness becomes more composed here — confident and polished without becoming rigid.'],
    [3, '03 / The Drydown', 'GROUNDED FORWARD', 'Amberwood, patchouli and vetiver give the fragrance depth and direction, while musk smooths the composition. What begins with movement settles into a grounded, confident presence.'],
  ],
  'solitaire' => [
    [1, '01 / The Opening', 'SPICED CERTAINTY', 'Lavender introduces an aromatic freshness before cardamom, pepper and saffron begin to build warmth and character. Sweet accords soften the edges, creating an opening that feels confident without needing to be loud.'],
    [2, '02 / The Heart', 'WARMTH WITH DEPTH', 'Cinnamon and nutmeg deepen the spice as smoky accords move through soft florals and patchouli. The fragrance becomes warmer, richer and more distinctive, carrying a composed sense of presence.'],
    [3, '03 / The Drydown', 'A LASTING SIGNATURE', 'Vanilla, amber and tonka bean bring smooth sweetness into the drydown, while cedarwood, fir resin and musk create a warm woody foundation. What remains is rich, velvety and quietly memorable.'],
  ],
  'musc-affair' => [
    [1, '01 / The Opening', 'QUIET CLOSENESS', 'Lily of the valley and white flowers open with a clean, delicate softness. Creamy accents begin to round the composition, creating an immediate sense of warmth and familiarity.'],
    [2, '02 / The Heart', 'SOFTLY PERSONAL', 'Powdery vanilla blends into musk at the heart, giving the fragrance its velvety and intimate character. The composition stays soft and personal, drawing closer rather than projecting outward.'],
    [3, '03 / The Drydown', 'WARMTH THAT LINGERS', 'Sandalwood and amber settle beneath the musk, adding creamy warmth and smooth depth. The drydown remains comforting, understated and close to the skin.'],
  ],
  'rhythm-of-sandal' => [
    [1, '01 / The Opening', 'A QUIET BEGINNING', 'Subtle spice meets fresh woods in an opening that feels restrained and composed. Rather than demanding attention, the fragrance begins with a soft sense of space and calm.'],
    [2, '02 / The Heart', 'CREAMY STILLNESS', 'Creamy sandalwood becomes the center of the composition, softened by delicate floral nuances. The texture turns smooth and comforting, creating a warm sense of balance and quiet presence.'],
    [3, '03 / The Drydown', 'GROUNDED CALM', 'Amber, dry woods and musk settle beneath the sandalwood, giving the fragrance a warm and grounded finish. The drydown remains soft, woody and quietly reflective.'],
  ],
  'afterglow' => [
    [1, '01 / The Opening', 'A WARM IGNITION', 'Saffron threads open with a golden glow while bergamot adds a bright, translucent edge. Pink pepper sparks softly against the warmth — an opening that radiates rather than announces.'],
    [2, '02 / The Heart', 'RADIANT SOFTNESS', 'Rose and orris soften the center as cashmere musk wraps the florals in a smooth luminous haze. The heart glows gently, intimate and unhurried.'],
    [3, '03 / The Drydown', 'THE LINGERING GLOW', 'Amber, vanilla bean and tonka melt into cedarwood, leaving a warm resinous trail. The drydown stays close to the skin — soft, familiar and quietly memorable.'],
  ],
];

$chapterImages = [
  1 => 'assets/images/nc-opening.webp',
  2 => 'assets/images/nc-heart.webp',
  3 => 'assets/images/nc-base.webp',
];

$insStory = $pdo->prepare(
  'INSERT INTO product_stories (product_id, chapter_no, kicker, title, copy, image) VALUES (?, ?, ?, ?, ?, ?)'
);

foreach ($stories as $productSlug => $chapters) {
  foreach ($chapters as $chapter) {
    $insStory->execute([
      $productIds[$productSlug],
      $chapter[0],
      $chapter[1],
      $chapter[2],
      $chapter[3],
      $chapterImages[$chapter[0]],
    ]);
  }
}


$testerSets = [
  [
    'slug'            => 'discovery-set',
    'name'            => 'DISCOVERY SET',
    'subtitle'        => 'Five expressions. One introduction.',
    'card_subtitle'   => 'Five expressions · 5 × 5ml',
    'price'           => 1990,
    'image'           => 'assets/images/tester_bottles.webp',
    'intro'           => 'Experience all five fragrances from Initialé before choosing the expression that feels most like your own.',
    'olfactory_intro' => 'Five distinct scent directions. Compare their olfactory character and discover which expression feels closest to you.',
    'includes'        => '5 × 5ml fragrances',
    'collection'      => 'initiale',
    'concentration'   => 'Extrait de Parfum',
    'size_label'      => '5 × 5ml',
    'sort_order'      => 1,
  ],
];

$setIds = [];

$insSet = $pdo->prepare(
  'INSERT INTO tester_sets (slug, name, subtitle, card_subtitle, price, image, intro, olfactory_intro, includes, collection_id, concentration, size_label, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)'
);

foreach ($testerSets as $set) {
  $insSet->execute([
    $set['slug'],
    $set['name'],
    $set['subtitle'],
    $set['card_subtitle'],
    $set['price'],
    $set['image'],
    $set['intro'],
    $set['olfactory_intro'],
    $set['includes'],
    $collectionIds[$set['collection']] ?? null,
    $set['concentration'],
    $set['size_label'],
    $set['sort_order'],
  ]);
  $setIds[$set['slug']] = (int) $pdo->lastInsertId();
}

$insSetItem = $pdo->prepare(
  'INSERT INTO tester_set_items (set_id, product_id, position) VALUES (?, ?, ?)'
);

$initialProducts = [
  'pearls-and-petals',
  'next-chapter',
  'solitaire',
  'musc-affair',
  'rhythm-of-sandal',
];

foreach ($initialProducts as $position => $productSlug) {
  $insSetItem->execute([
    $setIds['discovery-set'],
    $productIds[$productSlug],
    $position + 1,
  ]);
}


$testimonials = [
  ['next-chapter',        'Ahmed R.',  'Fresh, clean and very easy to wear. I especially liked how it stayed noticeable without becoming too heavy.', ''],
  ['pearls-and-petals',   'Ayesha K.', 'It feels soft and polished rather than overly sweet. Very feminine, but still elegant and easy to wear.', ''],
  ['solitaire',           'Hamza M.',  'Different from the usual fresh perfumes I wear. It has a strong personality and feels more mature on skin.', ''],
  ['musc-affair',         'Sana A.',   'Warm, smooth and close to the skin in a very comforting way. It feels intimate without becoming too dense.', ''],
  ['rhythm-of-sandal',    'Ali H.',    'The sandalwood feels creamy and calm. I liked how soft and balanced it became after settling on the skin.', ''],
  [null,                  'Mariam S.', 'The Discovery Set made choosing much easier. Testing all five properly helped me understand which one suited me best.', 'Initialé Discovery Set'],
  ['next-chapter',        'Usman F.',  'Received Next Chapter as a gift first and ended up looking for it again when the bottle was almost finished.', ''],
  ['pearls-and-petals',   'Hira N.',   'Very smooth floral fragrance. It feels refined and wearable, especially when I want something soft but noticeable.', ''],
  ['solitaire',           'Bilal A.',  'It develops really well after the opening. The drydown has a distinctive character that stays with you.', ''],
  ['musc-affair',         'Zainab R.', 'It has a clean musky warmth that feels very personal. One of those fragrances you keep noticing throughout the day.', ''],
  ['rhythm-of-sandal',    'Farhan K.', 'Comforting and understated. The sandalwood gives it warmth without making it feel old-fashioned or too heavy.', ''],
  [null,                  'Noor M.',   'What stood out for me was that the fragrances felt different from each other rather than like variations of the same scent.', 'Verdeur'],
];

$insTestimonial = $pdo->prepare(
  'INSERT INTO testimonials (product_id, customer_name, quote, label, sort_order) VALUES (?, ?, ?, ?, ?)'
);

foreach ($testimonials as $position => $testimonial) {
  $insTestimonial->execute([
    $testimonial[0] !== null ? $productIds[$testimonial[0]] : null,
    $testimonial[1],
    $testimonial[2],
    $testimonial[3],
    $position + 1,
  ]);
}


$bankAccounts = [
  [
    'name'           => 'HBL — Verdeur',
    'bank_name'      => 'HBL',
    'account_title'  => 'Verdeur Fragran',
    'account_number' => '50037000682403',
    'iban'           => 'PK94HABB0050037000682403',
    'branch'         => 'IBB KASHMIR ROAD SIA',
    'qr_image'       => 'assets/images/qr.webp',
    'sort_order'     => 1,
  ],
];

$insBank = $pdo->prepare(
  'INSERT INTO bank_accounts (name, bank_name, account_title, account_number, iban, branch, qr_image, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)'
);

foreach ($bankAccounts as $bank) {
  $insBank->execute([
    $bank['name'],
    $bank['bank_name'],
    $bank['account_title'],
    $bank['account_number'],
    $bank['iban'],
    $bank['branch'],
    $bank['qr_image'],
    $bank['sort_order'],
  ]);
}


$siteSettings = [
  'site_name'            => 'Verdeur',
  'site_tagline'         => 'Scent, expressed as something more.',
  'shipping_charge'      => '250',
  'free_shipping_above'  => '0',
  'contact_email'        => 'hello@verdeur.com',
  'contact_phone'        => '+92 304 1461111',
  'whatsapp_number'      => '923041461111',
  'whatsapp_message'     => 'Hi Verdeur%2C%20I%20would%20like%20to%20know%20more%20about%20your%20fragrances.',
  'social_facebook'      => 'https://www.facebook.com/verdeurofficial',
  'social_instagram'     => 'https://www.instagram.com/verdeurofficial',
  'social_tiktok'        => 'https://www.tiktok.com/@verdeurofficial',
  'copyright_text'       => '© 2026 Verdeur. All rights reserved.',
  'footer_brand_copy'    => 'Independent fragrance house. Scent, expressed as something more.',
];

$insSetting = $pdo->prepare(
  'INSERT INTO site_settings (setting_key, setting_value, is_active) VALUES (?, ?, 1)'
);

foreach ($siteSettings as $key => $value) {
  $insSetting->execute([$key, $value]);
}


$legalPages = [
  [
    'slug'    => 'shipping-returns',
    'title'   => 'SHIPPING & RETURNS',
    'kicker'  => 'Verdeur',
    'intro'   => 'Information about order processing, delivery and returns for purchases made through Verdeur.',
    'content' =>
      '<div class="policy-section"><h2>Shipping</h2><p>Verdeur delivers orders across Pakistan. A flat delivery charge of Rs. ' . $siteSettings['shipping_charge'] . ' applies to all orders.</p><p>Orders are prepared and dispatched after payment has been received and confirmed.</p></div>' .
      '<div class="policy-section"><h2>Order Processing</h2><p>Once your order is confirmed, we begin preparing it for dispatch. Processing and delivery times may vary depending on your location, courier operations and public holidays.</p><p>You may be contacted if any additional information is required before your order can be dispatched.</p></div>' .
      '<div class="policy-section"><h2>Payment</h2><p>Orders are confirmed upon advance payment. Cash on Delivery is currently unavailable.</p></div>' .
      '<div class="policy-section"><h2>Delivery</h2><p>Please make sure the name, phone number and delivery address provided with your order are complete and accurate.</p><p>Once an order has been handed over to the courier, delivery may be affected by circumstances outside Verdeur\'s direct control.</p></div>' .
      '<div class="policy-section"><h2>Returns &amp; Exchanges</h2><p>Due to the personal nature of fragrance products, opened or used products cannot normally be returned or exchanged.</p><p>If you receive an incorrect item, or your order arrives damaged, please contact Verdeur as soon as possible after receiving your package so that we can review the issue.</p><p>We may request photographs or other details relating to the product and packaging before arranging a replacement or other appropriate resolution.</p></div>' .
      '<div class="policy-section"><h2>Order Changes</h2><p>If you need to make a change to your order, please contact us before it has been dispatched. Once an order has entered the shipping process, changes may no longer be possible.</p></div>' .
      '<div class="policy-section"><h2>Need Help?</h2><p>If you have a question about an order, delivery or product received, please get in touch through our Contact page.</p></div>',
  ],
  [
    'slug'    => 'privacy-policy',
    'title'   => 'PRIVACY POLICY',
    'kicker'  => 'Verdeur',
    'intro'   => 'This policy explains how Verdeur collects and uses information when you browse our website, contact us or place an order.',
    'content' =>
      '<div class="policy-section"><h2>Information We Collect</h2><p>When you place an order, contact us or submit information through our website, we may collect details such as your name, phone number, email address, delivery address and information relating to your order.</p><p>We may also receive information that you voluntarily provide when communicating with us regarding an enquiry, payment or customer support request.</p></div>' .
      '<div class="policy-section"><h2>How We Use Your Information</h2><p>We use the information provided to process and fulfil orders, arrange delivery, communicate with customers, provide support and improve our services.</p><p>We may also use contact information to send updates relating specifically to an order or enquiry.</p></div>' .
      '<div class="policy-section"><h2>Payment Information</h2><p>Information provided for payment confirmation is used only for processing and verifying the relevant order and for necessary business records.</p></div>' .
      '<div class="policy-section"><h2>Sharing of Information</h2><p>We do not sell or rent your personal information.</p><p>Certain information may be shared with service providers where necessary to fulfil your order, such as delivery and courier services, or where required for website operations and payment processing.</p></div>' .
      '<div class="policy-section"><h2>Cookies &amp; Website Data</h2><p>Our website may use cookies or similar technologies to help the website function correctly, understand how it is used and improve the browsing experience.</p></div>' .
      '<div class="policy-section"><h2>Data Security</h2><p>We take reasonable steps to protect the personal information provided to us. However, no online system or method of electronic storage can be guaranteed to be completely secure.</p></div>' .
      '<div class="policy-section"><h2>Data Retention</h2><p>Personal information may be retained for as long as reasonably necessary to fulfil orders, provide customer support, maintain business records and meet applicable legal or operational requirements.</p></div>' .
      '<div class="policy-section"><h2>Your Information</h2><p>If you would like to ask about personal information you have provided to Verdeur, or request that information be corrected, please contact us through our Contact page.</p></div>' .
      '<div class="policy-section"><h2>Changes to This Policy</h2><p>This Privacy Policy may be updated from time to time to reflect changes to our website, services or business practices.</p></div>' .
      '<div class="policy-section"><h2>Contact</h2><p>For any questions relating to this Privacy Policy, please contact Verdeur through our Contact page.</p></div>',
  ],
];

$insLegal = $pdo->prepare(
  'INSERT INTO legal_pages (slug, title, kicker, intro, content, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)'
);

foreach ($legalPages as $position => $page) {
  $insLegal->execute([
    $page['slug'],
    $page['title'],
    $page['kicker'],
    $page['intro'],
    $page['content'],
    $position + 1,
  ]);
}


echo 'verdeur_db installed with:' . PHP_EOL;
echo '  collections      : ' . count($collections) . PHP_EOL;
echo '  products         : ' . count($products) . PHP_EOL;
echo '  product_stories  : ' . array_sum(array_map('count', $stories)) . PHP_EOL;
echo '  tester_sets      : ' . count($testerSets) . PHP_EOL;
echo '  tester_set_items : ' . count($initialProducts) . PHP_EOL;
echo '  testimonials     : ' . count($testimonials) . PHP_EOL;
echo '  bank_accounts    : ' . count($bankAccounts) . PHP_EOL;
echo '  site_settings    : ' . count($siteSettings) . PHP_EOL;
echo '  legal_pages      : ' . count($legalPages) . PHP_EOL;
echo '  newsletter       : 0 (filled via newsletter API)' . PHP_EOL;
echo '  orders/order_items: 0 (filled via order API)' . PHP_EOL;

$check = $pdo->query('SELECT p.product_id, p.slug, c.name AS collection FROM products p JOIN collections c ON c.collection_id = p.collection_id ORDER BY c.sort_order, p.sort_order')->fetchAll();

foreach ($check as $row) {
  printf(
    "  [%d] %-20s (%s)\n",
    (int) $row['product_id'],
    $row['slug'],
    $row['collection']
  );
}