<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

try {
  $pdo = verdeur_db();

  // Get product IDs for order items
  $products = $pdo->query('SELECT product_id, slug, name, price FROM products LIMIT 5')->fetchAll();
  if (empty($products)) {
    exit('No products found to seed orders.');
  }

  // Get bank account ID
  $bank = $pdo->query('SELECT account_id FROM bank_accounts LIMIT 1')->fetch();
  $bankId = $bank ? (int) $bank['account_id'] : null;

  $dummyOrders = [
    [
      'number' => 'VRD-260302-A1B2',
      'name' => 'Hamza Ali',
      'phone' => '+92 300 1234567',
      'email' => 'hamza.ali@example.com',
      'address' => 'House 42, Block C, Gulberg III',
      'city' => 'Lahore',
      'province' => 'Punjab',
      'notes' => 'Please deliver in evening time.',
      'status' => 'Confirmed',
      'payment_status' => 'Paid',
      'method' => 'Bank Transfer',
      'items' => [
        ['product' => $products[0], 'qty' => 1],
        ['product' => $products[1] ?? $products[0], 'qty' => 1]
      ]
    ],
    [
      'number' => 'VRD-260302-C3D4',
      'name' => 'Sana Mir',
      'phone' => '+92 321 9876543',
      'email' => 'sana.mir@example.com',
      'address' => 'Apartment 12B, Clifton Block 4',
      'city' => 'Karachi',
      'province' => 'Sindh',
      'notes' => '',
      'status' => 'Shipped',
      'payment_status' => 'Paid',
      'method' => 'Bank Transfer',
      'items' => [
        ['product' => $products[2] ?? $products[0], 'qty' => 1]
      ]
    ],
    [
      'number' => 'VRD-260302-E5F6',
      'name' => 'Ahmed Khan',
      'phone' => '+92 333 5554433',
      'email' => 'ahmed.khan@example.com',
      'address' => 'Street 10, F-7/2',
      'city' => 'Islamabad',
      'province' => 'Federal',
      'notes' => 'Call before delivery.',
      'status' => 'Pending',
      'payment_status' => 'Pending',
      'method' => 'Bank Transfer',
      'items' => [
        ['product' => $products[0], 'qty' => 2]
      ]
    ],
    [
      'number' => 'VRD-260302-G7H8',
      'name' => 'Fatima Noor',
      'phone' => '+92 312 4443322',
      'email' => 'fatima.noor@example.com',
      'address' => 'Near Clock Tower, Susan Road',
      'city' => 'Faisalabad',
      'province' => 'Punjab',
      'notes' => '',
      'status' => 'Delivered',
      'payment_status' => 'Paid',
      'method' => 'Bank Transfer',
      'items' => [
        ['product' => $products[1] ?? $products[0], 'qty' => 1]
      ]
    ]
  ];

  $insOrder = $pdo->prepare(
    'INSERT IGNORE INTO orders 
     (order_number, customer_name, customer_phone, customer_email, customer_address, customer_city, customer_province, customer_notes, subtotal, shipping, total, payment_method, order_status, payment_status, bank_account_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );

  $insItem = $pdo->prepare(
    'INSERT INTO order_items (order_id, product_id, item_key, item_name, item_meta, unit_price, quantity, line_total)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  );

  foreach ($dummyOrders as $ord) {
    $subtotal = 0;
    foreach ($ord['items'] as $it) {
      $subtotal += (int) $it['product']['price'] * $it['qty'];
    }
    $shipping = 250;
    $total = $subtotal + $shipping;

    $insOrder->execute([
      $ord['number'],
      $ord['name'],
      $ord['phone'],
      $ord['email'],
      $ord['address'],
      $ord['city'],
      $ord['province'],
      $ord['notes'],
      $subtotal,
      $shipping,
      $total,
      $ord['method'],
      $ord['status'],
      $ord['payment_status'],
      $bankId
    ]);

    $orderId = (int) $pdo->lastInsertId();
    if ($orderId > 0) {
      foreach ($ord['items'] as $it) {
        $p = $it['product'];
        $lineTotal = (int) $p['price'] * $it['qty'];
        $insItem->execute([
          $orderId,
          (int) $p['product_id'],
          $p['slug'],
          $p['name'],
          'Standard Bottle · EDP',
          (int) $p['price'],
          $it['qty'],
          $lineTotal
        ]);
      }
    }
  }

  // Seed customer queries if empty
  $queryCount = (int) $pdo->query('SELECT COUNT(*) FROM customer_queries')->fetchColumn();
  if ($queryCount === 0) {
    $insQuery = $pdo->prepare('INSERT INTO customer_queries (name, email, subject, message, is_read) VALUES (?, ?, ?, ?, ?)');
    $insQuery->execute(['Zainab Malik', 'zainab@example.com', 'Custom fragrance inquiry', 'Do you offer custom blending for weddings?', 0]);
    $insQuery->execute(['Usman Tariq', 'usman@example.com', 'Discovery Set delivery time', 'How many days does delivery take to Multan?', 1]);
  }

  // Seed newsletter subscribers if empty
  $subCount = (int) $pdo->query('SELECT COUNT(*) FROM newsletter_subscribers')->fetchColumn();
  if ($subCount === 0) {
    $insSub = $pdo->prepare('INSERT IGNORE INTO newsletter_subscribers (email, is_active) VALUES (?, 1)');
    $insSub->execute(['subscriber1@example.com']);
    $insSub->execute(['subscriber2@example.com']);
    $insSub->execute(['luxury.lover@example.com']);
  }

  echo "Dummy data seeded successfully!\n";

} catch (Throwable $e) {
  echo "Error seeding dummy data: " . $e->getMessage() . "\n";
}
