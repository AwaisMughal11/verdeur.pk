<?php
/**
 * VERDEUR — Dummy Orders Seeder
 *
 * Inserts ~100 realistic demo orders (and their order_items) spread over
 * the past 90 days so the admin dashboard analytics/insights are meaningful.
 *
 * RERUNNABLE: demo orders are tagged with a customer-email marker domain
 * (`@demo.verdeur.local`). Running this script first deletes any previously
 * seeded demo orders, then inserts a fresh set.
 *
 * Usage:  php db/seed_orders.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

$MARKER_EMAIL_DOMAIN = 'demo.verdeur.local';
$NUM_ORDERS          = 100;
$SHIPPING_FLAT       = 250;
$DAYS_SPAN           = 90;

/* ------------------------------------------------------------------
   Live product catalogue (id => [name, price])
------------------------------------------------------------------ */
$products = [];
$schP = verdeur_db()->query('SELECT product_id, name, price FROM products WHERE is_active = 1');
foreach ($schP as $row) {
  $products[(int) $row['product_id']] = [
    'name'  => (string) $row['name'],
    'price' => (int) $row['price'],
  ];
}

if (count($products) === 0) {
  fwrite(STDERR, "No active products found. Run db/seed_collections.php first?\n");
  exit(1);
}

$pdo = verdeur_db();

/* ------------------------------------------------------------------
   Idempotency: remove previously seeded demo orders (order_items cascade)
------------------------------------------------------------------ */
$del = $pdo->prepare('DELETE FROM orders WHERE customer_email LIKE ?');
$del->execute(['%@' . $MARKER_EMAIL_DOMAIN]);

/* ------------------------------------------------------------------
   Realistic reference data
------------------------------------------------------------------ */
$cities = [
  ['Lahore', 'Punjab'], ['Karachi', 'Sindh'], ['Islamabad', 'Islamabad Capital Territory'],
  ['Rawalpindi', 'Punjab'], ['Faisalabad', 'Punjab'], ['Multan', 'Punjab'],
  ['Peshawar', 'Khyber Pakhtunkhwa'], ['Quetta', 'Balochistan'], ['Gujranwala', 'Punjab'],
  ['Sialkot', 'Punjab'], ['Hyderabad', 'Sindh'], ['Sargodha', 'Punjab'],
];

$firstNames = ['Ayesha', 'Bilal', 'Fatima', 'Haris', 'Zainab', 'Omar', 'Sana', 'Usman', 'Mahnoor', 'Ali', 'Areeba', 'Hamza', 'Rabia', 'Imran', 'Noor', 'Salman', 'Hira', 'Kamran', 'Yusra', 'Faisal'];
$lastNames  = ['Khan', 'Ahmed', 'Malik', 'Sheikh', 'Butt', 'Chaudhry', 'Ali', 'Hussain', 'Raza', 'Qureshi', 'Siddiqui', 'Baig', 'Shah', 'Mirza', 'Iqbal', 'Farooq'];

$streetPart = ['House 12, Block C', 'Flat 3B, Hira Tower', 'Plot 45, Street 9', 'Suite 7, Gulberg', 'Bungalow 21, Phase 5', 'Shop 4, Main Bazaar', 'Apt 12, Clifton', 'House 8, Model Town'];

$paymentMethodsByStatus = [
  'Pending'    => 'Bank Transfer',
  'Confirmed'  => 'Bank Transfer',
  'Shipped'    => 'Bank Transfer',
  'Delivered'  => 'Bank Transfer',
  'Cancelled'  => 'Bank Transfer',
];

/* Payment method mix (mostly bank transfer as the site's primary gateway) */
$paymentMethods = ['Bank Transfer', 'Bank Transfer', 'Bank Transfer', 'JazzCash', 'Cash on Delivery', 'Easypaisa'];

$orderStatuses = ['Pending', 'Pending', 'Confirmed', 'Shipped', 'Delivered', 'Delivered', 'Delivered', 'Cancelled'];

$notesPool = [
  '',
  '',
  '',
  'Please call before delivery.',
  'Leave with the gate guard if not available.',
  'Prefer delivery in the evening.',
  'Gift wrapping requested.',
  '',
  'Neighbourhood landmark: near Al-Falah market.',
];

/* Weighted product picks -> makes "top products" analytics meaningful */
$weightedProductIds = [];
foreach ($products as $id => $_) {
  $weight = 10; // base weight for every product
  if (in_array($id, [7, 13, 21, 19, 16, 2], true)) { // GOLDEN HOUR, MOLTEN HONEY, OBSIDIAN VEIL, VELVET MIDNIGHT, HALO OUD, NEXT CHAPTER
    $weight = 26;
  } elseif (in_array($id, [6, 12, 18, 20], true)) { // AFTERGLOW, GILDED EMBRACE, EMBERS AT DUSK, LUNE D'ARGENT
    $weight = 18;
  }
  for ($i = 0; $i < $weight; $i++) {
    $weightedProductIds[] = $id;
  }
}
shuffle($weightedProductIds);

$mobilePrefixes = ['0300', '0301', '0321', '0333', '0345', '0304', '0332', '0307'];

/* Seed RNG deterministically-ish but still varied */
mt_srand(20260903);

$insOrder = $pdo->prepare(
  'INSERT INTO orders
     (order_number, customer_name, customer_phone, customer_email,
      customer_address, customer_city, customer_province, customer_notes,
      subtotal, shipping, total, payment_method,
      order_status, payment_status, bank_account_id, created_at)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
);

$insItem = $pdo->prepare(
  'INSERT INTO order_items
     (order_id, product_id, item_key, item_name, item_meta, unit_price, quantity, line_total)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
);

$pdo->beginTransaction();
$inserted = 0;

for ($i = 0; $i < $NUM_ORDERS; $i++) {

  /* Spread across the past N days, with more recent days weighted higher */
  $bias = pow(mt_rand() / mt_getrandmax(), 1.4) * $DAYS_SPAN;
  $daysAgo = (int) round($bias);
  $created = (new DateTime('now'))
    ->modify('-' . $daysAgo . ' days')
    ->modify('-' . mt_rand(0, 12) . ' hours')
    ->modify('-' . mt_rand(0, 59) . ' minutes');

  $orderStatus = $orderStatuses[array_rand($orderStatuses)];

  /* Payment status aligned with order status */
  if ($orderStatus === 'Cancelled') {
    $paymentStatus = 'Refunded';
  } elseif (in_array($orderStatus, ['Shipped', 'Delivered'], true)) {
    $paymentStatus = 'Paid';
  } elseif (mt_rand(0, 100) < 70) {
    $paymentStatus = 'Paid';
  } else {
    $paymentStatus = 'Pending';
  }

  /* 1-2 items, occasionally 3 */
  $itemCount = mt_rand(1, 10) <= 7 ? 1 : (mt_rand(1, 10) <= 8 ? 2 : 3);
  $subtotal = 0;
  $items = [];
  $used = [];
  for ($j = 0; $j < $itemCount; $j++) {
    $pid = $weightedProductIds[mt_rand(0, count($weightedProductIds) - 1)];
    // avoid duplicate identical items in one order
    if (isset($used[$pid])) { $used[$pid]++; } else { $used[$pid] = 1; }
    $qty = $used[$pid] > 1 ? 1 : mt_rand(1, 2);
    $p   = $products[$pid];
    $line = $p['price'] * $qty;
    $subtotal += $line;
    $items[] = [$pid, $p['name'], $p['price'], $qty, $line];
  }

  $shipping = $SHIPPING_FLAT;
  $total    = $subtotal + $shipping;

  $name     = $firstNames[array_rand($firstNames)] . ' ' . $lastNames[array_rand($lastNames)];
  $phone    = $mobilePrefixes[array_rand($mobilePrefixes)] . str_pad((string) mt_rand(0, 9999999), 7, '0', STR_PAD_LEFT);
  $cityRow  = $cities[array_rand($cities)];
  $address  = $streetPart[array_rand($streetPart)] . ', ' . $cityRow[0];
  $notes    = $notesPool[array_rand($notesPool)];
  $email    = strtolower($name) . mt_rand(10, 999) . '@' . $MARKER_EMAIL_DOMAIN;

  /* Unique order number: VRD-<ymd>-<XXXX> using the order's own date */
  do {
    $orderNumber = 'VRD-' . $created->format('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));
    $exists = $pdo->prepare('SELECT order_id FROM orders WHERE order_number = ?');
    $exists->execute([$orderNumber]);
    $dup = $exists->fetch();
  } while ($dup);

  $insOrder->execute([
    $orderNumber,
    mb_substr($name, 0, 120),
    $phone,
    mb_substr($email, 0, 190),
    mb_substr($address, 0, 255),
    $cityRow[0],
    $cityRow[1],
    $notes === '' ? null : $notes,
    $subtotal,
    $shipping,
    $total,
    $paymentMethods[array_rand($paymentMethods)],
    $orderStatus,
    $paymentStatus,
    1, // HBL bank account
    $created->format('Y-m-d H:i:s'),
  ]);

  $orderId = (int) $pdo->lastInsertId();

  foreach ($items as $it) {
    $insItem->execute([
      $orderId,
      $it[0],
      'product-' . $it[0],
      mb_substr($it[1], 0, 190),
      '50ml EDP',
      $it[2],
      $it[3],
      $it[4],
    ]);
  }

  $inserted++;
}

$pdo->commit();

echo "Seeded $inserted demo orders (" . count($products) . " products referenced).\n";
echo "Marker domain: @" . $MARKER_EMAIL_DOMAIN . " (used for idempotent reruns)\n";
