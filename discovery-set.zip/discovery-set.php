﻿<?php

require_once __DIR__ . '/config.php';

$set = null;
$setItems = [];

try {

  $pdo = verdeur_db();

  $setSlug = trim((string) ($_GET['set'] ?? ''));

  if ($setSlug !== '') {

    $stmt = $pdo->prepare(
      'SELECT t.*, c.name AS collection_name, c.slug AS collection_slug
       FROM tester_sets t
       LEFT JOIN collections c ON c.collection_id = t.collection_id
       WHERE t.is_active = 1 AND t.slug = ? LIMIT 1'
    );
    $stmt->execute([$setSlug]);
    $set = $stmt->fetch();

  }

  if (!$set) {

    $stmt = $pdo->prepare(
      'SELECT t.*, c.name AS collection_name, c.slug AS collection_slug
       FROM tester_sets t
       LEFT JOIN collections c ON c.collection_id = t.collection_id
       WHERE t.is_active = 1 ORDER BY t.sort_order LIMIT 1'
    );
    $stmt->execute();
    $set = $stmt->fetch();

  }

  if ($set) {

    $stmt = $pdo->prepare(
      'SELECT p.*, tsi.position
       FROM tester_set_items tsi
       INNER JOIN products p ON p.product_id = tsi.product_id
       WHERE tsi.set_id = ? AND p.is_active = 1
       ORDER BY tsi.position'
    );
    $stmt->execute([$set['set_id']]);
    $setItems = $stmt->fetchAll();

  }

} catch (Throwable $e) {
  $set = null;
  $setItems = [];
}

$setTitle = $set ? trim((string) ($set['name'] ?? '')) : '';
$pageTitle = $setTitle !== '' ? ($setTitle . ' — Verdeur') : 'Discovery Sets — Verdeur';
$setDesc = $set ? trim((string) ($set['intro'] ?? '')) : '';
$pageDescription = $setDesc !== ''
  ? $setDesc
  : 'Explore Verdeur discovery sets — curated sample collections of signature fragrances from an independent fragrance house.';
if ($set && !empty($set['image'])) {
  $pageImage = (string) $set['image'];
}
if ($set && !empty($set['slug'])) {
  $canonicalUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/discovery-set/' . urlencode((string) $set['slug']);
}

include('includes/header.php');
?>




  <main>


 <!-- =========================================
     DISCOVERY SET â€” HERO
========================================== -->

<section class="ds-hero">

  <div class="ds-hero-inner">

<?php if ($set): ?>


    <div class="ds-hero-visual">

      <img
        src="<?php echo v_esc($set['image']); ?>"
        alt="Verdeur InitialÃ© Discovery Set"
        class="ds-hero-image"
        fetchpriority="high"
      >

    </div>


    <div class="ds-hero-content">

      <div class="ds-hero-heading">

        <p class="ds-kicker">
          <?php echo v_esc($set['collection_name'] ?: ($set['collection'] ?? 'Verdeur')); ?>
        </p>

        <h1 class="ds-title">
          <?php echo v_esc($set['name']); ?>
        </h1>

        <p class="ds-subtitle">
          <?php echo v_esc($set['subtitle']); ?>
        </p>

        <p class="ds-price">
          <?php echo v_price($set['price']); ?>
        </p>

      </div>


      <p class="ds-intro">
        <?php echo v_esc($set['intro']); ?>
      </p>


      <div class="ds-details">

        <div class="ds-detail-row">

          <span class="ds-detail-label">
            Includes
          </span>

          <span class="ds-detail-value">
            <?php echo v_esc($set['includes']); ?>
          </span>

        </div>


        <div class="ds-detail-row">

          <span class="ds-detail-label">
            Collection
          </span>

          <span class="ds-detail-value">
            <?php echo v_esc($set['collection_name'] ?: ($set['collection'] ?? '')); ?>
          </span>

        </div>


        <div class="ds-detail-row">

          <span class="ds-detail-label">
            Concentration
          </span>

          <span class="ds-detail-value">
            <?php echo v_esc($set['concentration']); ?>
          </span>

        </div>

      </div>


      <button
        type="button"
        class="ds-add-cart"
        data-product="<?php echo v_esc($set['slug']); ?>"
      >
        Add to Cart
      </button>

    </div>

<?php else: ?>

    <div class="ds-hero-content">

      <div class="ds-hero-heading">

        <p class="ds-kicker">
          InitialÃ©
        </p>

        <h1 class="ds-title">
          DISCOVERY SET
        </h1>

        <p class="ds-subtitle">
          Five expressions. One introduction.
        </p>

        <p class="ds-price">
          Rs. 1,990
        </p>

      </div>

    </div>

<?php endif; ?>

  </div>

</section>



<!-- =========================================
     INITIALÃ‰ â€” OLFACTORY OVERVIEW
========================================== -->

<section class="ds-olfactory">

  <div class="ds-olfactory-inner">


    <!-- SECTION HEADING -->
    <div class="ds-section-header">

      <p class="ds-section-kicker">
        <?php echo v_esc($set ? ($set['collection_name'] ?: ($set['collection'] ?? 'Initialé')) : 'Initialé'); ?>
      </p>

      <h2 class="ds-section-title">
        MEET THE <?php echo count($setItems) > 0 ? v_esc(\ucwords((string) count($setItems)) . ' ') : ''; ?>EXPRESSIONS
      </h2>

      <p class="ds-section-intro">
        <?php echo v_esc($set ? $set['olfactory_intro'] : 'Five distinct scent directions. Compare their olfactory character and discover which expression feels closest to you.'); ?>
      </p>

    </div>



    <!-- OLFACTORY GRID -->
<div class="ds-olfactory-slider">

<button
  type="button"
  class="ds-olfactory-arrow ds-olfactory-prev"
  aria-label="Previous fragrance"
>
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M15 5L8 12L15 19"></path>
  </svg>
</button>

  <div class="ds-olfactory-viewport">

    <div class="ds-olfactory-track">
<?php if (count($setItems) > 0): ?>

<?php foreach ($setItems as $setIndex => $setItem): ?>

      <article
        class="ds-olfactory-item"
        style="--scent-accent: <?php echo v_esc($setItem['accent']); ?>;"
      >

        <a href="fragrance/<?php echo v_esc($setItem['slug']); ?>" class="ds-olfactory-link" aria-label="Explore <?php echo v_esc($setItem['name']); ?>"></a>

          <div class="ds-olfactory-heading">

            <div class="ds-accent-line"></div>

            <h3>
              <?php echo v_esc($setItem['name']); ?>
            </h3>

            <p>
              <?php echo v_esc($setItem['expression']); ?>
            </p>

          </div>


          <div class="ds-olfactory-detail">

            <div class="ds-detail-number">
              (01)
            </div>

            <div>

              <h4>
                Fragrance Family
              </h4>

              <p>
                <?php echo v_esc($setItem['family']); ?>
              </p>

            </div>

          </div>


          <div class="ds-olfactory-detail">

            <div class="ds-detail-number">
              (02)
            </div>

            <div>

              <h4>
                Top Notes
              </h4>

              <p>
                <?php echo v_esc($setItem['top_notes']); ?>
              </p>

            </div>

          </div>


          <div class="ds-olfactory-detail">

            <div class="ds-detail-number">
              (03)
            </div>

            <div>

              <h4>
                Heart Notes
              </h4>

              <p>
                <?php echo v_esc($setItem['heart_notes']); ?>
              </p>

            </div>

          </div>


          <div class="ds-olfactory-detail">

            <div class="ds-detail-number">
              (04)
            </div>

            <div>

              <h4>
                Base Notes
              </h4>

              <p>
                <?php echo v_esc($setItem['base_notes']); ?>
              </p>

            </div>

          </div>


          <div class="ds-olfactory-detail ds-best-for">

            <div class="ds-detail-number">
              (05)
            </div>

            <div>

              <h4>
                Best For
              </h4>

              <p>
                <?php echo v_esc($setItem['best_for']); ?>
              </p>

            </div>

          </div>

      </article>

<?php endforeach; ?>

<?php endif; ?>
          </div>

  </div>

<button
  type="button"
  class="ds-olfactory-arrow ds-olfactory-next"
  aria-label="Next fragrance"
>
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M9 5L16 12L9 19"></path>
  </svg>
</button>

</div>

<div class="ds-olfactory-dots"></div>


    </div>

  </div>

</section>



<!-- =========================================
     THE DISCOVERY EXPERIENCE
========================================== -->

<section class="ds-experience">

  <div class="ds-experience-inner">


    <!-- SECTION INTRO -->
    <div class="ds-section-header ds-experience-header">

      <p class="ds-section-kicker">
        The Discovery Experience
      </p>

      <h2 class="ds-section-title">
        DISCOVER AT YOUR OWN PACE
      </h2>

      <p class="ds-section-intro">
        Fragrance changes on skin and over time.
        Give each expression the space to reveal itself
        before deciding which one feels most like your own.
      </p>

    </div>



    <!-- =====================================
         HOW TO DISCOVER
    ====================================== -->

    <div class="ds-how">

      <h3 class="ds-how-heading">
        HOW TO DISCOVER
      </h3>


      <div class="ds-how-grid">


        <!-- STEP 01 -->
        <article class="ds-how-step">


          <!-- ILLUSTRATION -->
          <div class="ds-how-icon">

            <svg
              viewBox="0 0 160 160"
              aria-hidden="true"
            >

              <!-- arm -->
              <path
                d="M35 112
                   C58 104 74 96 89 84
                   C101 75 111 69 124 66"
              ></path>

              <path
                d="M37 122
                   C64 115 84 105 100 92"
              ></path>

              <!-- bottle -->
              <rect
                x="39"
                y="38"
                width="26"
                height="42"
                rx="3"
              ></rect>

              <rect
                x="45"
                y="27"
                width="14"
                height="11"
              ></rect>

              <!-- spray -->
              <path d="M65 45 L82 41"></path>
              <path d="M69 51 L87 51"></path>
              <path d="M66 57 L82 62"></path>

              <!-- wrist mark -->
              <circle
                cx="105"
                cy="80"
                r="3"
              ></circle>

            </svg>

          </div>


          <p class="ds-step-label">
            01
          </p>

          <h4>
            Wear on skin
          </h4>

          <p>
            Apply each fragrance to your skin rather than
            judging it only from the bottle or opening spray.
          </p>

        </article>



        <!-- STEP 02 -->
        <article class="ds-how-step">


          <div class="ds-how-icon">

            <svg
              viewBox="0 0 160 160"
              aria-hidden="true"
            >

              <!-- wrist / skin -->
              <path
                d="M27 107
                   C52 99 70 91 89 77
                   C101 68 114 63 132 62"
              ></path>

              <path
                d="M30 118
                   C59 111 83 100 101 86"
              ></path>

              <!-- scent evolution -->
              <path
                d="M72 75
                   C62 63 66 51 78 47
                   C90 43 94 33 88 24"
              ></path>

              <path
                d="M91 68
                   C85 58 90 49 100 45
                   C111 41 114 32 109 24"
              ></path>

              <!-- clock -->
              <circle
                cx="121"
                cy="98"
                r="19"
              ></circle>

              <path d="M121 87 V99 L130 105"></path>

            </svg>

          </div>


          <p class="ds-step-label">
            02
          </p>

          <h4>
            Let it develop
          </h4>

          <p>
            Give the fragrance time to move through its
            opening, heart and drydown. Notice how it changes.
          </p>

        </article>



        <!-- STEP 03 -->
        <article class="ds-how-step">


          <div class="ds-how-icon">

            <svg
              viewBox="0 0 160 160"
              aria-hidden="true"
            >

              <!-- three testers -->
              <rect
                x="34"
                y="49"
                width="22"
                height="66"
                rx="5"
              ></rect>

              <rect
                x="69"
                y="39"
                width="22"
                height="76"
                rx="5"
              ></rect>

              <rect
                x="104"
                y="49"
                width="22"
                height="66"
                rx="5"
              ></rect>

              <!-- caps -->
              <rect
                x="38"
                y="39"
                width="14"
                height="10"
              ></rect>

              <rect
                x="73"
                y="29"
                width="14"
                height="10"
              ></rect>

              <rect
                x="108"
                y="39"
                width="14"
                height="10"
              ></rect>

              <!-- chosen -->
              <circle
                cx="80"
                cy="129"
                r="12"
              ></circle>

              <path
                d="M74 129
                   L78 133
                   L87 124"
              ></path>

            </svg>

          </div>


          <p class="ds-step-label">
            03
          </p>

          <h4>
            Find your expression
          </h4>

          <p>
            Return to the fragrances that stay with you
            and choose the expression that feels most your own.
          </p>

        </article>


      </div>

    </div>



    <!-- =====================================
         FRAGRANCE EXPERIENCE CARD
    ====================================== -->

    <div class="ds-experience-card">


      <div class="ds-card-visual">

        <img
          src="assets/images/fragrance-experience-card.webp"
          alt="Verdeur Fragrance Experience Card"
          loading="lazy"
          decoding="async"
        >

      </div>


      <div class="ds-card-content">

        <p class="ds-card-kicker">
          Included With Your Set
        </p>

        <h3 class="ds-card-title">
          YOUR FRAGRANCE<br>
          EXPERIENCE CARD
        </h3>

        <p class="ds-card-copy">
          A simple companion created to help you observe,
          compare and remember how each fragrance develops
          on your skin.
        </p>

        <p class="ds-card-note">
          Take your time. Notice what stays with you.
        </p>

      </div>


    </div>


  </div>

</section>

  </main>

  <!-- =========================================
     10 â€” FOOTER
========================================== -->

<?php include('includes/footer.php'); ?>
