<?php

/* =========================================
   VERDEUR — ORDER API
   AJAX endpoint. Creates an order (and its
   items) in the database from the checkout.
   Returns JSON only.
========================================= */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode([
    'ok'    => false,
    'error' => 'Method not allowed.',
  ]);
  exit;
}

/* Same-origin guard: reject cross-site requests to prevent order spam/CSRF */
function verdeur_origin_matches(string $host, string $url): bool {
  $parsed = parse_url($url);
  $uhost  = isset($parsed['host']) ? strtolower((string) $parsed['host']) : '';
  return $uhost === strtolower($host);
}

$origin  = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
$referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
$host    = (string) ($_SERVER['HTTP_HOST'] ?? '');
$isSameOrigin = ($origin !== '' && verdeur_origin_matches($host, $origin))
  || ($referer !== '' && verdeur_origin_matches($host, $referer))
  || ($origin === '' && $referer === '');

if (!$isSameOrigin) {
  http_response_code(403);
  echo json_encode([
    'ok'    => false,
    'error' => 'Request rejected.',
  ]);
  exit;
}

/* =========================================
   Rate limiting — throttle abusive/automated order submissions.

   Production values (real store, CPanel):
   - Layer 1 (session): 10 submissions / 10 min per browser.
   - Layer 2 (IP):      50 submissions / hour per IP+user-agent.
   - Layer 3 (speed):   reject if submitted < 5s after page load.

   These are deliberately generous for genuine customers (incl.
   shared/office IPs and checkout retries) while still blocking
   rapid automated abuse.
========================================= */
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

$subKey   = 'verdeur_order_attempts';
$subUntil = 'verdeur_order_until';
$now      = time();

$sessionMax   = 10;           // max order attempts per session window
$sessionWindow= 600;          // 10 minutes
$ipMax        = 50;           // max submissions per IP window
$ipWindow     = 3600;         // 1 hour
$minHumanTime = 5;            // seconds a human needs to fill the checkout

// Session limiter: N attempts per window.
$windowUntil = (int) ($_SESSION[$subUntil] ?? 0);
if ($now < $windowUntil && (int) ($_SESSION[$subKey] ?? 0) >= $sessionMax) {
  http_response_code(429);
  echo json_encode([
    'ok'    => false,
    'error' => 'Too many orders from this session. Please wait a moment and try again.',
    'retry_after' => max(1, $windowUntil - $now),
  ]);
  exit;
}
if ($now >= $windowUntil) {
  $_SESSION[$subKey]   = 0;
  $_SESSION[$subUntil] = time() + $sessionWindow; // refresh session window
}

// IP limiter: N submissions per window across sessions.
try {
  $pdo = verdeur_db();
  $pdo->exec(<<<SQL
    CREATE TABLE IF NOT EXISTS `order_rate_limits` (
      `rl_key` VARCHAR(64) NOT NULL,
      `window_start` INT UNSIGNED NOT NULL,
      `hits` INT UNSIGNED NOT NULL DEFAULT 0,
      PRIMARY KEY (`rl_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  SQL);
  $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
  $ip = $ip !== '' ? $ip : 'unknown';
  $key = 'ip:' . md5($ip . '|' . (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
  $perHour = $ipWindow;
  $maxIP   = $ipMax;

  $stmt = $pdo->prepare('SELECT window_start, hits FROM order_rate_limits WHERE rl_key = ?');
  $stmt->execute([$key]);
  $rl = $stmt->fetch();

  if (!$rl || (int) $rl['window_start'] < $now - $perHour) {
    $upsert = $pdo->prepare('INSERT INTO order_rate_limits (rl_key, window_start, hits) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE window_start = VALUES(window_start), hits = 1');
    $upsert->execute([$key, $now]);
  } else {
    if ((int) $rl['hits'] >= $maxIP) {
      http_response_code(429);
      echo json_encode([
        'ok'    => false,
        'error' => 'Too many requests. Please try again later.',
      ]);
      exit;
    }
    $inc = $pdo->prepare('UPDATE order_rate_limits SET hits = hits + 1 WHERE rl_key = ?');
    $inc->execute([$key]);
  }
} catch (Throwable $e) {
  // rate limiting is best-effort; never block a legitimate order on DB failure
}

$raw     = file_get_contents('php://input');
$payload = json_decode($raw, true);

if (!is_array($payload)) {
  $payload = $_POST;
}

$customer      = is_array($payload['customer'] ?? null) ? $payload['customer'] : [];
$items         = is_array($payload['items'] ?? null) ? $payload['items'] : [];
$paymentMethod = trim((string) ($payload['payment_method'] ?? 'Bank Transfer'));

$name     = trim((string) ($customer['name'] ?? ''));
$phone    = trim((string) ($customer['phone'] ?? ''));
$email    = trim((string) ($customer['email'] ?? ''));
$address  = trim((string) ($customer['address'] ?? ''));
$city     = trim((string) ($customer['city'] ?? ''));
$province = trim((string) ($customer['province'] ?? ''));
$notes    = trim((string) ($customer['notes'] ?? ''));

$errors = [];

if ($name === '') {
  $errors['name'] = 'Please enter your full name.';
}

if ($phone === '') {
  $errors['phone'] = 'Please enter your phone number.';
}

if ($address === '') {
  $errors['address'] = 'Please enter your delivery address.';
}

if ($city === '') {
  $errors['city'] = 'Please enter your city.';
}

if ($province === '') {
  $errors['province'] = 'Please select your province.';
}

if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $errors['email'] = 'Please enter a valid email address.';
}

if (!is_array($items) || count($items) === 0) {
  $errors['items'] = 'Your cart is empty.';
}

if ($errors) {
  http_response_code(422);
  echo json_encode([
    'ok'     => false,
    'errors' => $errors,
  ]);
  exit;
}

// Count this submission against the session rate-limit window.
$_SESSION[$subKey] = (int) ($_SESSION[$subKey] ?? 0) + 1;

// --- Honeypot + speed-rejection ---
$honeypot = trim((string) ($payload['customer']['honeypot'] ?? ''));
$formStarted = (int) trim((string) ($payload['customer']['form_started'] ?? '0'));
$now = time();
$submittedTooFast = ($now - $formStarted) < $minHumanTime; // too fast = likely bot

if ($honeypot !== '' || $submittedTooFast) {
  http_response_code(429);
  echo json_encode([
    'ok'    => false,
    'error' => 'Request rejected.',
  ]);
  exit;
}

// --- Build order in database ---
$pdo = verdeur_db();

$findProduct = $pdo->prepare(
  'SELECT product_id FROM products WHERE slug = ?'
);

$cleanItems = [];
$subtotal   = 0;

foreach ($items as $item) {
  if (!is_array($item)) {
    continue;
  }

  $key       = trim((string) ($item['id'] ?? ''));
  $itemName  = trim((string) ($item['name'] ?? ''));
  $itemMeta  = trim((string) ($item['meta'] ?? ''));
  $quantity  = max(1, (int) ($item['quantity'] ?? 1));
  $unitPrice = (int) ($item['price'] ?? 0);

  if ($key === '' || $quantity < 1 || $unitPrice < 1) {
    continue;
  }

  $findProduct->execute([$key]);
  $productRow = $findProduct->fetch();

  $lineTotal = $unitPrice * $quantity;
  $subtotal += $lineTotal;

  $cleanItems[] = [
    'product_id' => $productRow ? (int) $productRow['product_id'] : null,
    'item_key'   => mb_substr($key, 0, 80),
    'item_name'  => mb_substr($itemName, 0, 190),
    'item_meta'  => mb_substr($itemMeta, 0, 190),
    'unit_price' => $unitPrice,
    'quantity'   => $quantity,
    'line_total' => $lineTotal,
  ];
}

if (!$cleanItems) {
  http_response_code(422);
  echo json_encode([
    'ok'     => false,
    'errors' => ['items' => 'Your cart is empty.'],
  ]);
  exit;
}

$shipping = $subtotal > 0
  ? (int) verdeur_setting('shipping_charge', '250')
  : 0;

$total    = $subtotal + $shipping;

$bankRow = $pdo->query(
  'SELECT account_id FROM bank_accounts
   WHERE is_active = 1
   ORDER BY sort_order ASC
   LIMIT 1'
)->fetch();

$bankAccountId = $bankRow ? (int) $bankRow['account_id'] : null;

$checkNumber = $pdo->prepare(
  'SELECT order_id FROM orders WHERE order_number = ?'
);

$orderNumber = '';
$attempts    = 0;

do {
  $orderNumber = 'VRD-'
    . date('ymd')
    . '-'
    . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));

  $checkNumber->execute([$orderNumber]);
  $exists = $checkNumber->fetch();
  $attempts++;
} while ($exists && $attempts < 10);

$pdo->beginTransaction();

try {

  $insOrder = $pdo->prepare(
    'INSERT INTO orders
       (order_number, customer_name, customer_phone, customer_email,
        customer_address, customer_city, customer_province, customer_notes,
        subtotal, shipping, total, payment_method,
        order_status, payment_status, bank_account_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );

  $insOrder->execute([
    $orderNumber,
    mb_substr($name, 0, 120),
    mb_substr($phone, 0, 40),
    mb_substr($email, 0, 190),
    mb_substr($address, 0, 255),
    mb_substr($city, 0, 80),
    mb_substr($province, 0, 120),
    $notes !== '' ? $notes : null,
    $subtotal,
    $shipping,
    $total,
    $paymentMethod !== '' ? $paymentMethod : 'Bank Transfer',
    'Pending',
    'Pending',
    $bankAccountId,
  ]);

  $orderId = (int) $pdo->lastInsertId();

  $insItem = $pdo->prepare(
    'INSERT INTO order_items
       (order_id, product_id, item_key, item_name, item_meta,
        unit_price, quantity, line_total)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  );

  foreach ($cleanItems as $item) {
    $insItem->execute([
      $orderId,
      $item['product_id'],
      $item['item_key'],
      $item['item_name'],
      $item['item_meta'],
      $item['unit_price'],
      $item['quantity'],
      $item['line_total'],
    ]);
  }

  $pdo->commit();

} catch (Throwable $e) {
  $pdo->rollBack();

  // Return a real error so the customer isn't told the order succeeded
  // when it was never saved (e.g. a DB schema mismatch on the server).
  http_response_code(500);
  echo json_encode([
    'ok'    => false,
    'error' => 'We could not save your order right now. Please try again or contact us.',
  ]);
  error_log("Order DB Error: " . $e->getMessage());
  exit;
}

// --- Order emails (ASYNCHRONOUS) ---
// Build the two emails (customer + admin), enqueue them, then spawn a
// detached background worker so the order response returns instantly
// without waiting on the SMTP round-trip.

function vr_queue_order_emails(
  int $orderId,
  string $orderNumber,
  int $total,
  array $items,
  string $customerEmail,
  string $customerName,
  string $customerPhone,
  string $customerAddress,
  string $customerCity,
  string $customerProvince,
  string $paymentMethod
): void {

  $pdo = verdeur_db();

  // Make sure the email queue table exists.
  $pdo->exec(<<<SQL
    CREATE TABLE IF NOT EXISTS `pending_emails` (
      `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
      `order_id` INT UNSIGNED NOT NULL,
      `to_email` VARCHAR(190) NOT NULL,
      `to_name` VARCHAR(120) NOT NULL DEFAULT '',
      `subject` VARCHAR(255) NOT NULL,
      `body_html` MEDIUMTEXT NOT NULL,
      `body_text` TEXT NOT NULL,
      `status` ENUM('pending','processing','sent','failed') NOT NULL DEFAULT 'pending',
      `attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
      `error` VARCHAR(500) NOT NULL DEFAULT '',
      `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `sent_at` DATETIME NULL,
      PRIMARY KEY (`id`),
      KEY `idx_status` (`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  SQL);

  $totalFmt = 'Rs. ' . number_format($total);

  // Shared order summary HTML.
  $itemRows = '';
  foreach ($items as $it) {
    $itemName = htmlspecialchars((string) ($it['item_name'] ?? ''));
    $meta     = htmlspecialchars((string) ($it['item_meta'] ?? ''));
    $qty      = (int) ($it['quantity'] ?? 1);
    $line     = (int) ($it['line_total'] ?? 0);
    $metaTxt  = $meta !== '' ? '<br><span style="font-size:12px;color:#777;">' . $meta . '</span>' : '';
    $itemRows .= '<tr>'
      . '<td style="padding:8px 10px;border-bottom:1px solid #eee;">' . $itemName . $metaTxt . '</td>'
      . '<td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:center;">x' . $qty . '</td>'
      . '<td style="padding:8px 10px;border-bottom:1px solid #eee;text-align:right;">Rs. ' . number_format($line) . '</td>'
      . '</tr>';
  }
  $summaryHtml = '<table style="width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:14px;">'
    . '<thead><tr><th style="text-align:left;padding:8px 10px;background:#f7f7f7;">Item</th>'
    . '<th style="padding:8px 10px;background:#f7f7f7;text-align:center;">Qty</th>'
    . '<th style="padding:8px 10px;background:#f7f7f7;text-align:right;">Amount</th></tr></thead>'
    . '<tbody>' . $itemRows . '</tbody></table>'
    . '<p style="text-align:right;font-weight:bold;font-size:15px;">Total: ' . $totalFmt . '</p>';

  // Payment-specific closing note + question.
  $isCOD = (stripos($paymentMethod, 'Cash') !== false) || (stripos($paymentMethod, 'COD') !== false);
  if ($isCOD) {
    $closingNote = "You have chosen <strong>Cash on Delivery</strong>. Please keep the total amount ready at the time of delivery.";
    $closingQuestion = "Please confirm: should we proceed with delivering your order to the address you provided?";
  } else {
    $closingNote = "You have chosen <strong>Bank Transfer</strong>. Please complete your payment to the bank account shown on our website.";
    $closingQuestion = "Please confirm: have you completed your bank transfer? Kindly share your payment proof so we can process your order.";
  }

  // 1) Customer email ("Order Placed")
  $jobs = [];
  if (!empty($customerEmail)) {
    $jobs[] = [
      'to_email' => mb_substr($customerEmail, 0, 190),
      'to_name'  => mb_substr($customerName, 0, 120),
      'subject'  => "Order Placed — #{$orderNumber} — Verdeur.pk",
      'body_html'=> "
        <div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
          <h2 style='color:#111;'>Thank you for your order, {$customerName}!</h2>
          <p>Your order <strong>#{$orderNumber}</strong> has been placed and is being processed. You will be contacted shortly regarding delivery.</p>
          <div style='background:#f9f9f9;border:1px solid #eee;border-radius:6px;padding:16px;margin:16px 0;'>{$summaryHtml}</div>
          <p>{$closingNote}</p>
          <p style='font-weight:bold;margin-top:18px;'>{$closingQuestion}</p>
          <p style='color:#777;font-size:13px;'>If you have any other questions, reply to this email or contact us.</p>
          <p style='color:#777;font-size:13px;'>Best regards,<br>Verdeur.pk Team</p>
        </div>",
      'body_text'=> "Your order #{$orderNumber} has been placed. Total: {$totalFmt}. {$closingQuestion}",
    ];
  }

  // 2) Admin notification
  $jobs[] = [
    'to_email' => VERDEUR_ADMIN_EMAIL,
    'to_name'  => 'Verdeur Admin',
    'subject'  => "New Order #{$orderNumber} — Verdeur.pk",
    'body_html'=> "
      <div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
        <h2 style='color:#111;'>New Order #{$orderNumber}</h2>
        <table style='width:100%;font-size:14px;border-collapse:collapse;margin-bottom:16px;'>
          <tr><td style='padding:6px 8px;'><strong>Customer:</strong></td><td style='padding:6px 8px;'>{$customerName}</td></tr>
          <tr><td style='padding:6px 8px;'><strong>Phone:</strong></td><td style='padding:6px 8px;'>{$customerPhone}</td></tr>
          <tr><td style='padding:6px 8px;'><strong>Email:</strong></td><td style='padding:6px 8px;'>{$customerEmail}</td></tr>
          <tr><td style='padding:6px 8px;'><strong>Address:</strong></td><td style='padding:6px 8px;'>{$customerAddress}, {$customerCity}, {$customerProvince}</td></tr>
          <tr><td style='padding:6px 8px;'><strong>Payment:</strong></td><td style='padding:6px 8px;'>{$paymentMethod}</td></tr>
        </table>
        {$summaryHtml}
      </div>",
    'body_text'=> "New order #{$orderNumber} from {$customerName} ({$customerPhone}) - {$totalFmt}",
  ];

  $ins = $pdo->prepare(
    'INSERT INTO pending_emails (order_id, to_email, to_name, subject, body_html, body_text)
     VALUES (?, ?, ?, ?, ?, ?)'
  );
  foreach ($jobs as $job) {
    $ins->execute([
      $orderId,
      $job['to_email'],
      $job['to_name'],
      $job['subject'],
      $job['body_html'],
      $job['body_text'],
    ]);
  }
}

function vr_spawn_email_worker(): void {
  $worker = __DIR__ . '/email-worker.php';
  if (!is_file($worker)) { return; }

  if (stripos(PHP_OS, 'WIN') === 0) {
    // Windows (local dev) — fire and forget.
    @pclose(@popen('start /B php ' . escapeshellarg($worker) . ' > NUL 2>&1', 'r'));
  } else {
    // Linux / CPanel — detached background process.
    $cmd = 'nohup ' . escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($worker) . ' > /dev/null 2>&1 &';
    @pclose(@popen($cmd, 'r'));
  }
}

try {
  vr_queue_order_emails(
    $orderId, $orderNumber, $total, $cleanItems,
    $email, $name, $phone, $address, $city, $province, $paymentMethod
  );
  vr_spawn_email_worker();
} catch (Throwable $e) {
  // Enqueue/spawn is best-effort — never block the order.
  error_log("Email queue Exception: " . $e->getMessage());
}

// ------------------------------------------------

echo json_encode([
    'ok'           => true,
    'order_id'     => $orderId,
    'order_number' => $orderNumber,
    'subtotal'     => $subtotal,
    'shipping'     => $shipping,
    'total'        => $total,
    'order_status' => 'Pending',
    'payment_status' => 'Pending',
]);