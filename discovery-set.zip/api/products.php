<?php

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');

try {

  $products = verdeur_db()->query(
    'SELECT p.slug, p.name, c.name AS collection, p.meta, p.price, p.image
       FROM products p
       JOIN collections c ON c.collection_id = p.collection_id
      WHERE p.is_active = 1 AND c.is_active = 1
      ORDER BY c.sort_order, p.sort_order, p.product_id'
  )->fetchAll();

  $testerSets = verdeur_db()->query(
    'SELECT t.slug, t.name,
            COALESCE(c.name, "Verdeur") AS collection,
            t.size_label, t.concentration, t.price, t.image, t.slug AS page_slug
       FROM tester_sets t
       LEFT JOIN collections c ON c.collection_id = t.collection_id
      WHERE t.is_active = 1
      ORDER BY t.sort_order, t.set_id'
  )->fetchAll();

  $catalog = [];

  foreach ($products as $product) {
    $catalog[$product['slug']] = [
      'id'         => $product['slug'],
      'name'       => $product['name'],
      'collection' => $product['collection'],
      'meta'       => $product['meta'],
      'price'      => (int) $product['price'],
      'image'      => $product['image'],
      'url'        => 'fragrance/' . $product['slug'],
    ];
  }

  foreach ($testerSets as $set) {
    $catalog[$set['slug']] = [
      'id'         => $set['slug'],
      'name'       => $set['name'],
      'collection' => $set['collection'],
      'meta'       => trim(($set['size_label'] ?: $set['includes'] ) . ' · ' . $set['concentration'], ' ·'),
      'price'      => (int) $set['price'],
      'image'      => $set['image'],
      'url'        => $set['slug'] === 'discovery-set' ? 'discovery-set' : $set['slug'],
    ];
  }

  echo json_encode([
    'products' => $catalog,
    'shipping' => (int) verdeur_setting('shipping_charge', '250'),
  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

} catch (Throwable $e) {

  http_response_code(500);

  echo json_encode([
    'error' => 'Catalog unavailable',
    'products' => [],
    'shipping' => (int) verdeur_setting('shipping_charge', '250'),
  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

}