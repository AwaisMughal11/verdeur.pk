<?php

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

  http_response_code(405);

  echo json_encode([
    'success' => false,
    'message' => 'Method not allowed',
  ], JSON_UNESCAPED_UNICODE);

  exit;

}

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';

if (stripos($contentType, 'application/json') !== false) {

  $body = json_decode(
    file_get_contents('php://input'),
    true
  );

  $email = is_array($body) ? trim((string) ($body['email'] ?? '')) : '';

} else {

  $email = trim((string) ($_POST['email'] ?? ''));

}

try {

  if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {

    http_response_code(422);

    echo json_encode([
      'success' => false,
      'errors' => [
        'email' => 'Please enter a valid email address.',
      ],
    ], JSON_UNESCAPED_UNICODE);

    exit;

  }

  $email = mb_strtolower($email, 'UTF-8');

  $pdo = verdeur_db();

  $check = $pdo->prepare('SELECT subscriber_id FROM newsletter_subscribers WHERE email = ? LIMIT 1');

  $check->execute([$email]);

  $existing = $check->fetch();

  if ($existing) {

    echo json_encode([
      'success' => true,
      'already' => true,
      'message' => 'You are already on our list. Thank you for staying with Verdeur.',
    ], JSON_UNESCAPED_UNICODE);

    exit;

  }

  $pdo->prepare(
    'INSERT INTO newsletter_subscribers (email, is_active) VALUES (?, 1)'
  )->execute([$email]);

  echo json_encode([
    'success' => true,
    'already' => false,
    'message' => 'Welcome to Verdeur. You are now on the list.',
  ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

  http_response_code(500);

  echo json_encode([
    'success' => false,
    'message' => 'Something went wrong. Please try again.',
  ], JSON_UNESCAPED_UNICODE);

}