<?php

/* =========================================
   VERDEUR — CONTACT API
   AJAX endpoint. Receives the contact form
   and stores it into customer_queries.
   Returns JSON only.
========================================= */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode([
    'ok'    => false,
    'error' => 'Method not allowed.',
  ]);
  exit;
}

$name    = trim((string) ($_POST['name'] ?? ''));
$email   = trim((string) ($_POST['email'] ?? ''));
$subject = trim((string) ($_POST['subject'] ?? ''));
$message = trim((string) ($_POST['message'] ?? ''));

$errors = [];

if ($name === '') {
  $errors['name'] = 'Please enter your name.';
}

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $errors['email'] = 'Please enter a valid email address.';
}

if ($message === '') {
  $errors['message'] = 'Please enter your message.';
}

if ($errors) {
  http_response_code(422);
  echo json_encode([
    'ok'     => false,
    'errors' => $errors,
  ]);
  exit;
}

try {
  $pdo = verdeur_db();

  $stmt = $pdo->prepare(
    'INSERT INTO customer_queries (name, email, subject, message)
     VALUES (?, ?, ?, ?)'
  );

  $stmt->execute([
    mb_substr($name, 0, 120),
    mb_substr($email, 0, 190),
    mb_substr($subject, 0, 190),
    $message,
  ]);

  echo json_encode([
    'ok'      => true,
    'message' => 'Thank you! Your message has been received.',
  ]);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode([
    'ok'    => false,
    'error' => 'Something went wrong. Please try again.',
  ]);
}