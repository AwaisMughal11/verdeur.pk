<?php

/* =========================================
   VERDEUR — ASYNC EMAIL WORKER
   Sends queued emails (pending_emails) in the
   background so order placement does not wait
   on the SMTP round-trip.

   Runs either as a detached background process
   (spawned by api/orders.php) or as a CPanel
   cron job (safety net, every minute).

   Usage:  php api/email-worker.php [batch=N]
========================================= */

declare(strict_types=1);

require_once __DIR__ . '/../config.php';

// Never let this worker kill the parent's request.
ignore_user_abort(true);
set_time_limit(120);

// Lock so two concurrent workers don't claim the same rows.
$lockFile = sys_get_temp_dir() . '/verdeur_email_worker.lock';
$fp = @fopen($lockFile, 'c');
if ($fp && !flock($fp, LOCK_EX | LOCK_NB)) {
  // Another worker is already running; exit quietly.
  exit(0);
}

$batch = 20;
// optional CLI arg: batch=N
if (PHP_SAPI === 'cli' && isset($argv[1])) {
  $n = (int) str_replace('batch=', '', $argv[1]);
  if ($n > 0) { $batch = min($n, 50); }
}

try {
  $pdo = verdeur_db();
} catch (Throwable $e) {
  if ($fp) { flock($fp, LOCK_UN); fclose($fp); }
  exit(0);
}

// Ensure the queue table exists (safety for first run).
$pdo->exec(<<<SQL
  CREATE TABLE IF NOT EXISTS `pending_emails` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_id` INT UNSIGNED NOT NULL,
    `to_email` VARCHAR(190) NOT NULL,
    `to_name` VARCHAR(120) NOT NULL DEFAULT '',
    `subject` VARCHAR(255) NOT NULL,
    `body_html` MEDIUMTEXT NOT NULL,
    `body_text` TEXT NOT NULL,
    `status` ENUM('pending','processing','sent','failed') NOT NULL DEFAULT 'pending',
    `attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `error` VARCHAR(500) NOT NULL DEFAULT '',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `sent_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_status` (`status`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL);

// Claim a batch of pending rows.
$pdo->beginTransaction();
try {
  $ids = $pdo->query(
    "SELECT id FROM pending_emails
     WHERE status = 'pending'
     ORDER BY id ASC
     LIMIT {$batch}"
  )->fetchAll(PDO::FETCH_COLUMN);
  if ($ids) {
    $in = implode(',', array_map('intval', $ids));
    $pdo->exec("UPDATE pending_emails SET status='processing', attempts=attempts+1 WHERE id IN ({$in})");
  }
  $pdo->commit();
} catch (Throwable $e) {
  $pdo->rollBack();
  if ($fp) { flock($fp, LOCK_UN); fclose($fp); }
  exit(0);
}

if (!$ids) {
  if ($fp) { flock($fp, LOCK_UN); fclose($fp); }
  exit(0);
}

$rows = $pdo->query(
  "SELECT * FROM pending_emails WHERE id IN (" . implode(',', $ids) . ")"
)->fetchAll();

$mail = new \PHPMailer\PHPMailer\PHPMailer(true);

foreach ($rows as $row) {
  $rowId = (int) $row['id'];
  $ok = false;
  $err = '';

  try {
    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = VERDEUR_SMTP_HOST;
    $mail->Port       = VERDEUR_SMTP_PORT;
    $mail->SMTPAuth   = true;
    $mail->Username   = VERDEUR_SMTP_USER;
    $mail->Password   = VERDEUR_SMTP_PASS;
    $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
    $mail->CharSet    = 'UTF-8';
    $mail->isHTML(true);

    $mail->setFrom(VERDEUR_MAIL_FROM, VERDEUR_MAIL_FROM_NAME);
    $mail->clearAllRecipients();
    $mail->addAddress((string) $row['to_email'], (string) $row['to_name']);
    $mail->Subject = (string) $row['subject'];
    $mail->Body    = (string) $row['body_html'];
    $mail->AltBody = (string) $row['body_text'];

    $mail->send();
    $ok = true;
  } catch (Throwable $e) {
    $ok  = false;
    $err = mb_substr($e->getMessage(), 0, 480);
  }

  if ($ok) {
    $upd = $pdo->prepare('UPDATE pending_emails SET status = "sent", sent_at = NOW(), error = "" WHERE id = ?');
    $upd->execute([$rowId]);
  } else {
    // Retry up to 3 times, then mark failed (kept in table for inspection).
    $status = (int) $row['attempts'] >= 3 ? 'failed' : 'pending';
    $upd = $pdo->prepare('UPDATE pending_emails SET status = ?, error = ? WHERE id = ?');
    $upd->execute([$status, $err, $rowId]);
    error_log("Verdeur Email Worker #{$rowId} failed: " . $err);
  }
}

if ($fp) { flock($fp, LOCK_UN); fclose($fp); }
exit(0);
