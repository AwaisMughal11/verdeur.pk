﻿<?php

require_once __DIR__ . '/config.php';

$bankAccounts = [];
$activeBankIndex = -1;

try {
  $bankAccounts = verdeur_db()->query(
    'SELECT * FROM bank_accounts
     ORDER BY sort_order ASC'
  )->fetchAll();

  foreach ($bankAccounts as $idx => $bank) {
    if ($activeBankIndex === -1 && !empty($bank['is_active'])) {
      $activeBankIndex = $idx;
    }
  }
} catch (Throwable $e) {
  $bankAccounts = [];
}

if (empty($bankAccounts)) {
  $bankAccounts = [[
    'name'           => 'HBL — Verdeur',
    'bank_name'      => 'HBL',
    'account_title'  => 'Verdeur Fragran',
    'account_number' => '50037000682403',
    'iban'           => 'PK94HABB0050037000682403',
    'branch'         => 'IBB KASHMIR ROAD SIA',
    'qr_image'       => 'assets/images/qr.webp',
    'is_active'      => 1,
  ]];
  $activeBankIndex = 0;
}

$pageTitle = 'Order Received — Verdeur';
include('includes/header.php');
?>


<main class="vos-page">

  <section class="vos-section">

    <div class="vos-inner">


      <!-- =====================================
           ORDER RECEIVED HEADER
      ====================================== -->

      <header class="vos-header">

        <p class="vos-kicker">
          Order Received
        </p>

        <h1 class="vos-title">
          THANK YOU.
        </h1>

        <p class="vos-intro">
          <span id="vos-intro-bank">
            Your order has been received and is currently awaiting payment.
            Complete the payment below and send your payment proof for verification.
          </span>
          <span id="vos-intro-cod" hidden>
            Your order has been received and confirmed. It will be delivered
            to your address with Cash on Delivery — no advance payment is required.
          </span>
        </p>

      </header>


      <!-- =====================================
           ORDER STATUS STRIP
      ====================================== -->

      <div
        class="vos-order-strip"
        id="vos-order-strip"
      >

        <div class="vos-order-strip-item">

          <span>
            Order
          </span>

          <strong id="vos-order-number">
            —
          </strong>

        </div>


        <div class="vos-order-strip-item vos-order-strip-statuses">

          <span>
            Status
          </span>

          <div class="vos-status-list">

            <div class="vos-status-row">

              <span class="vos-status-key">
                Order
              </span>

              <strong
                class="vos-status-badge"
                id="vos-order-status"
              >
                Pending
              </strong>

            </div>

          </div>

        </div>


        <div class="vos-order-strip-item">

          <span>
            Amount Due
          </span>

          <strong id="vos-amount-due">
            Rs. 0
          </strong>

        </div>

      </div>


      <!-- =====================================
           STATUS TIMELINE
      ====================================== -->

      <div class="vos-progress">

        <div class="vos-progress-step complete">

          <span class="vos-progress-dot"></span>

          <div>

            <strong>
              Order Received
            </strong>

            <p>
              Your order has been created.
            </p>

          </div>

        </div>


        <div class="vos-progress-step active vos-progress-bankonly">

          <span class="vos-progress-dot"></span>

          <div>

            <strong>
              Pending Payment
            </strong>

            <p>
              Complete payment using the details below.
            </p>

          </div>

        </div>


        <div class="vos-progress-step vos-progress-bankonly">

          <span class="vos-progress-dot"></span>

          <div>

            <strong>
              Verification
            </strong>

            <p>
              Payment proof will be reviewed.
            </p>

          </div>

        </div>


        <div class="vos-progress-step vos-progress-cod" hidden>

          <span class="vos-progress-dot"></span>

          <div>

            <strong>
              Awaiting Delivery
            </strong>

            <p>
              Pay in cash when your order arrives at your doorstep.
            </p>

          </div>

        </div>


        <div class="vos-progress-step">

          <span class="vos-progress-dot"></span>

          <div>

            <strong>
              Confirmed
            </strong>

            <p>
              Your order will move to fulfilment.
            </p>

          </div>

        </div>

      </div>


      <!-- =====================================
           MAIN ORDER LAYOUT
      ====================================== -->

      <div
        class="vos-layout"
        id="vos-order-content"
      >


        <!-- =================================
             LEFT — PAYMENT
        ================================== -->

        <div class="vos-payment-column">


          <section class="vos-block vos-bankonly">

            <div class="vos-block-heading">

              <p>
                01
              </p>

              <h2>
                Complete Payment
              </h2>

            </div>


            <div class="vos-payment-box">

              <div class="vos-payment-intro">

                <div>

                  <span class="vos-payment-label">
                    Bank Transfer
                  </span>

                  <h3>
                    Pay the amount due
                  </h3>

                  <p>
                    Transfer the total amount using the bank details below.
                    Use your order number as the payment reference where possible.
                  </p>

                </div>


                <strong
                  class="vos-payment-amount"
                  id="vos-payment-amount"
                >
                  Rs. 0
                </strong>

              </div>


              <div class="vos-bank-layout">

                <!-- BANK TABS -->
                <div class="vcheckout-payment-tabs">

                  <div class="vcheckout-tab-list" role="tablist">
                    <?php foreach ($bankAccounts as $idx => $bank): ?>
                      <?php $isBankActive = !empty($bank['is_active']); ?>
                      <button
                        type="button"
                        class="vcheckout-tab <?php echo $idx === $activeBankIndex ? 'active' : ''; ?> <?php echo $isBankActive ? '' : 'inactive'; ?>"
                        role="tab"
                        id="vos-tab-<?php echo $bank['account_id']; ?>"
                        aria-selected="<?php echo $idx === $activeBankIndex ? 'true' : 'false'; ?>"
                        aria-controls="vos-panel-<?php echo $bank['account_id']; ?>"
                        data-bank-name="<?php echo v_esc($bank['bank_name'] ?: 'Bank ' . ($idx + 1)); ?>"
                        <?php echo $isBankActive ? '' : 'aria-disabled="true"'; ?>
                      >
                        <?php echo v_esc($bank['bank_name'] ?: 'Bank ' . ($idx + 1)); ?>
                      </button>
                    <?php endforeach; ?>
                  </div>

                  <?php foreach ($bankAccounts as $idx => $bank): ?>
                    <?php $isBankActive = !empty($bank['is_active']); ?>
                    <div
                      class="vcheckout-payment-panel <?php echo $idx === $activeBankIndex ? 'active' : ''; ?>"
                      role="tabpanel"
                      id="vos-panel-<?php echo $bank['account_id']; ?>"
                      aria-labelledby="vos-tab-<?php echo $bank['account_id']; ?>"
                      <?php echo $idx === $activeBankIndex ? '' : 'hidden'; ?>
                    >

                      <div class="vcheckout-bank-content">

                        <!-- BANK DETAILS -->
                        <div class="vcheckout-bank-details">

                          <div class="vcheckout-bank-row">
                            <span>Bank</span>
                            <strong><?php echo v_esc($bank['bank_name']); ?></strong>
                          </div>

                          <div class="vcheckout-bank-row">
                            <span>Account Title</span>
                            <strong><?php echo v_esc($bank['account_title']); ?></strong>
                          </div>

                          <div class="vcheckout-bank-row">
                            <span>Account Number</span>
                            <strong><?php echo v_esc($bank['account_number']); ?></strong>
                          </div>

                          <?php if (!empty($bank['iban'])): ?>
                            <div class="vcheckout-bank-row">
                              <span>IBAN</span>
                              <strong><?php echo v_esc($bank['iban']); ?></strong>
                            </div>
                          <?php endif; ?>

                          <?php if (!empty($bank['branch'])): ?>
                            <div class="vcheckout-bank-row">
                              <span>Branch</span>
                              <strong><?php echo v_esc($bank['branch']); ?></strong>
                            </div>
                          <?php endif; ?>

                          <div class="vcheckout-bank-row">
                            <span>Payment Reference</span>
                            <strong id="vos-payment-reference">—</strong>
                          </div>

                        </div>

                        <!-- QR -->
                        <?php if (!empty($bank['qr_image'])): ?>
                          <div class="vos-qr">
                            <div class="vos-qr-image">
                              <img
                                src="<?php echo v_esc($bank['qr_image']); ?>"
                                alt="Verdeur bank transfer QR code"
                                loading="lazy"
                                decoding="async"
                              >
                            </div>
                            <p>Scan to pay</p>
                          </div>
                        <?php endif; ?>

                      </div>

                    </div>
                  <?php endforeach; ?>

                </div>

              </div>

            </div>

          </section>


          <!-- =================================
               PAYMENT PROOF
          ================================== -->

          <section class="vos-block vos-proof-block vos-bankonly">

            <div class="vos-block-heading">

              <p>
                02
              </p>

              <h2>
                Send Payment Proof
              </h2>

            </div>


            <div class="vos-proof">

              <p>
                Once your transfer is complete, send a screenshot of the
                payment through WhatsApp. Your order number will already be
                included in the message for easier verification.
              </p>


              <a
                href="#"
                class="vos-whatsapp-button"
                id="vos-whatsapp-button"
                target="_blank"
                rel="noopener noreferrer"
              >
                Send Payment Proof on WhatsApp
              </a>


              <p class="vos-proof-note">
                Attach your payment screenshot in WhatsApp before sending.
              </p>
              <p class="vos-whatsapp-fallback">

  Or send your payment proof manually to WhatsApp:

  <a
    href="https://wa.me/<?= v_esc(verdeur_setting('whatsapp_number', '923041461111')) ?>"
    target="_blank"
    rel="noopener noreferrer"
  >
    <?= v_esc(verdeur_setting('contact_phone', '+92 304 1461111')) ?>
  </a>

  and mention your order number:

  <strong id="vos-manual-order-number">—</strong>

</p>

            </div>

          </section>


          <!-- =================================
               COD — CONFIRMATION (IF COD ORDER)
          ================================== -->

          <section
            class="vos-block vos-cod-block"
            id="vos-cod-block"
            hidden
          >

            <div class="vos-block-heading">

              <p>
                01
              </p>

              <h2>
                Cash on Delivery
              </h2>

            </div>


            <div class="vos-cod-confirm">

              <strong
                class="vos-cod-amount"
                id="vos-cod-amount"
              >
                Rs. 0
              </strong>

              <p>
                Your order has been confirmed and will be dispatched for
                delivery. Please keep the exact cash amount ready to pay when
                your order arrives at your doorstep.
              </p>

              <p>
                No advance payment or payment proof is required for this order.
              </p>

            </div>

          </section>

        </div>



        <!-- =================================
             RIGHT — ORDER SUMMARY
        ================================== -->

        <aside class="vos-summary">

          <h2 class="vos-summary-title">
            Order Summary
          </h2>


          <div
            class="vos-products"
            id="vos-products"
          ></div>


          <div class="vos-totals">

            <div class="vos-total-row">

              <span>
                Subtotal
              </span>

              <span id="vos-subtotal">
                Rs. 0
              </span>

            </div>


            <div class="vos-total-row">

              <span>
                Shipping
              </span>

              <span id="vos-shipping">
                Rs. 0
              </span>

            </div>


            <div class="vos-total-final">

              <span>
                Total
              </span>

              <strong id="vos-total">
                Rs. 0
              </strong>

            </div>

          </div>


          <div class="vos-delivery">

            <p class="vos-summary-subtitle">
              Delivery Details
            </p>

            <div id="vos-delivery-details">

              <p>
                —
              </p>

            </div>

          </div>


          <a
            href="fragrances.php"
            class="vos-continue"
          >
            Continue Shopping
          </a>

        </aside>

      </div>



      <!-- =====================================
           NO ORDER FOUND
      ====================================== -->

      <div
        class="vos-empty"
        id="vos-empty"
        hidden
      >

        <p class="vos-kicker">
          Order Not Found
        </p>

        <h2>
          We couldn’t find a recent order on this device.
        </h2>

        <p>
          If you have not placed an order yet, return to the fragrance
          collection and begin again.
        </p>

        <a href="fragrances.php">
          Explore Fragrances
        </a>

      </div>


    </div>

  </section>

</main>
 
  <!-- =========================================
     10 — FOOTER
========================================== -->

<script>
/* =========================================
   VERDEUR — ORDER RECEIVED
   Frontend testing only
========================================= */

(function () {

  const page =
    document.querySelector(".vos-page");

  if (!page) {
    return;
  }


  const content =
    document.querySelector("#vos-order-content");

  const strip =
    document.querySelector("#vos-order-strip");

  const progress =
    document.querySelector(".vos-progress");

  const emptyState =
    document.querySelector("#vos-empty");


  let order = null;


  try {

    const stored =
      localStorage.getItem(
        "verdeur-last-order"
      );

    if (stored) {
      order = JSON.parse(stored);
    }

  }

  catch (error) {

    console.error(
      "Could not read Verdeur order:",
      error
    );

  }


  if (
    !order ||
    !order.orderNumber ||
    !Array.isArray(order.items)
  ) {

    if (content) {
      content.hidden = true;
    }

    if (strip) {
      strip.hidden = true;
    }

    if (progress) {
      progress.hidden = true;
    }

    if (emptyState) {
      emptyState.hidden = false;
    }

    return;

  }


  if (emptyState) {
    emptyState.hidden = true;
  }


  const formatPrice = (amount) => {

    return (
      "Rs. " +
      Number(amount || 0)
        .toLocaleString("en-PK")
    );

  };


  /* =====================================
     ORDER META
  ====================================== */

  const orderNumberElement =
    document.querySelector(
      "#vos-order-number"
    );

  const amountDueElement =
    document.querySelector(
      "#vos-amount-due"
    );

  const paymentAmountElement =
    document.querySelector(
      "#vos-payment-amount"
    );

  const paymentReferenceElement =
    document.querySelector(
      "#vos-payment-reference"
    );

  const orderStatusElement =
    document.querySelector(
      "#vos-order-status"
    );


  function statusCategory(status) {

    const value =
      String(status || "")
        .toLowerCase();

    if (
      ["pending", "awaiting", "on-hold"].includes(value)
    ) {
      return "pending";
    }

    if (
      ["processing", "shipped", "verifying"].includes(value)
    ) {
      return "progress";
    }

    if (
      ["delivered", "paid", "verified", "completed", "complete", "confirmed"].includes(value)
    ) {
      return "done";
    }

    if (
      ["cancelled", "canceled", "refunded", "failed", "denied", "rejected"].includes(value)
    ) {
      return "danger";
    }

    return "neutral";

  }


  function renderStatusBadge(element, status) {

    if (!element) {
      return;
    }

    element.textContent =
      status || "Pending";

    element.classList.remove(
      "state-pending",
      "state-progress",
      "state-done",
      "state-danger",
      "state-neutral"
    );

    element.classList.add(
      "state-" +
      statusCategory(status)
    );

  }


  if (orderNumberElement) {
    orderNumberElement.textContent =
      order.orderNumber;
  }


  renderStatusBadge(
    orderStatusElement,
    order.orderStatus || "Pending"
  );


  const manualOrderNumberElement =
    document.querySelector(
      "#vos-manual-order-number"
    );


  if (manualOrderNumberElement) {
    manualOrderNumberElement.textContent =
      order.orderNumber;
  }


  if (amountDueElement) {
    amountDueElement.textContent =
      formatPrice(order.total);
  }


  if (paymentAmountElement) {
    paymentAmountElement.textContent =
      formatPrice(order.total);
  }


  if (paymentReferenceElement) {
    paymentReferenceElement.textContent =
      order.orderNumber;
  }



  /* =====================================
     CASH ON DELIVERY HANDLING
     When the order was placed using COD,
     hide bank/payment-proof details and
     show COD confirmation instead.
  ====================================== */

  const paymentMethodValue =
    String(order.paymentMethod || "")
      .toLowerCase();

  const isCodOrder =
    paymentMethodValue.includes("cash")
    || paymentMethodValue.includes("cod");

  const codBlock =
    document.querySelector(
      "#vos-cod-block"
    );

  const codAmountElement =
    document.querySelector(
      "#vos-cod-amount"
    );

  const introBank =
    document.querySelector(
      "#vos-intro-bank"
    );

  const introCod =
    document.querySelector(
      "#vos-intro-cod"
    );

  const bankOnlyElements =
    Array.from(
      document.querySelectorAll(
        ".vos-bankonly"
      )
    );

  const bankOnlyProgress =
    Array.from(
      document.querySelectorAll(
        ".vos-progress-bankonly"
      )
    );

  const codProgress =
    Array.from(
      document.querySelectorAll(
        ".vos-progress-cod"
      )
    );


  if (isCodOrder) {

    bankOnlyElements.forEach(el => {
      el.hidden = true;
    });

    bankOnlyProgress.forEach(el => {
      el.hidden = true;
    });

    codProgress.forEach(el => {
      el.hidden = false;
    });

    if (introBank) {
      introBank.hidden = true;
    }

    if (introCod) {
      introCod.hidden = false;
    }

    if (codBlock) {
      codBlock.hidden = false;
    }

    if (codAmountElement) {
      codAmountElement.textContent =
        formatPrice(order.total);
    }

  } else {

    if (codBlock) {
      codBlock.hidden = true;
    }

    if (introBank) {
      introBank.hidden = false;
    }

    if (introCod) {
      introCod.hidden = true;
    }

  }



  /* =====================================
     PRODUCTS
  ====================================== */

  const productsContainer =
    document.querySelector(
      "#vos-products"
    );


  if (productsContainer) {

    productsContainer.innerHTML = "";


    order.items.forEach(item => {

      const product =
        document.createElement(
          "div"
        );

      product.className =
        "vos-product";


      product.innerHTML = `

        <div class="vos-product-image">

          <img
            src="${item.image || ""}"
            alt="${item.name || "Verdeur fragrance"}"
            loading="lazy"
            decoding="async"
          >

        </div>


        <div class="vos-product-info">

          <p class="vos-product-name">
            ${item.name || ""}
          </p>

          <p class="vos-product-meta">
            ${item.meta || ""}<br>
            Qty ${Number(item.quantity || 1)}
          </p>

        </div>


        <div class="vos-product-price">
          ${formatPrice(
            item.lineTotal ??
            (
              Number(item.price || 0) *
              Number(item.quantity || 1)
            )
          )}
        </div>

      `;


      productsContainer.appendChild(
        product
      );

    });

  }



  /* =====================================
     TOTALS
  ====================================== */

  const subtotalElement =
    document.querySelector(
      "#vos-subtotal"
    );

  const shippingElement =
    document.querySelector(
      "#vos-shipping"
    );

  const totalElement =
    document.querySelector(
      "#vos-total"
    );


  if (subtotalElement) {
    subtotalElement.textContent =
      formatPrice(order.subtotal);
  }


  if (shippingElement) {
    shippingElement.textContent =
      formatPrice(order.shipping);
  }


  if (totalElement) {
    totalElement.textContent =
      formatPrice(order.total);
  }



  /* =====================================
     DELIVERY DETAILS
  ====================================== */

  const deliveryElement =
    document.querySelector(
      "#vos-delivery-details"
    );


  if (
    deliveryElement &&
    order.customer
  ) {

    const customer =
      order.customer;


    const location =
      [
        customer.address,
        customer.city,
        customer.province
      ]
      .filter(Boolean)
      .join(", ");


    const optionalEmail =
      customer.email
        ? `<p>${customer.email}</p>`
        : "";


    const optionalNotes =
      customer.notes
        ? `
          <div class="vos-delivery-note">
            <span>Order Note</span>
            <p>${customer.notes}</p>
          </div>
        `
        : "";


    deliveryElement.innerHTML = `

      <strong>
        ${customer.name || ""}
      </strong>

      <p>
        ${customer.phone || ""}
      </p>

      ${optionalEmail}

      <p>
        ${location}
      </p>

      ${optionalNotes}

    `;

  }



  /* =====================================
     WHATSAPP PAYMENT PROOF
  ====================================== */

  const whatsappButton =
    document.querySelector(
      "#vos-whatsapp-button"
    );


  if (whatsappButton) {

    const message =
      [
        "Hi Verdeur,",
        "",
        `I have completed payment for Order ${order.orderNumber}.`,
        `Amount: ${formatPrice(order.total)}.`,
        "",
        "I am sending the payment proof for verification."
      ]
      .join("\n");


    whatsappButton.href =
      "https://wa.me/<?= v_esc(verdeur_setting('whatsapp_number', '923041461111')) ?>?text=" +
      encodeURIComponent(message);

  }
})();


/* =========================================
   BANK TAB SWITCHER
========================================= */

document.querySelectorAll('.vcheckout-tab').forEach(tab => {
  if (tab.getAttribute('aria-disabled') === 'true') return;

  tab.addEventListener('click', () => {
    document.querySelectorAll('.vcheckout-tab').forEach(t => {
      t.classList.remove('active');
      t.setAttribute('aria-selected', 'false');
    });
    document.querySelectorAll('.vcheckout-payment-panel').forEach(p => {
      p.hidden = true;
      p.classList.remove('active');
    });

    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');

    const panelId = tab.getAttribute('aria-controls');
    const panel = document.getElementById(panelId);
    if (panel) {
      panel.hidden = false;
      panel.classList.add('active');
    }
  });
});

</script>
<?php include('includes/footer.php'); ?>
