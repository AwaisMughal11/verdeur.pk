﻿<?php

require_once __DIR__ . '/config.php';

$bankAccounts = [];
try {
  $bankAccounts = verdeur_db()->query(
    'SELECT * FROM bank_accounts
     ORDER BY sort_order ASC, account_id ASC'
  )->fetchAll();
} catch (Throwable $e) {
  $bankAccounts = [];
}

if (empty($bankAccounts)) {
  $bankAccounts = [[
    'account_id'     => 1,
    'name'           => 'HBL — Verdeur',
    'bank_name'      => 'HBL',
    'account_title'  => 'Verdeur Fragran',
    'account_number' => '50037000682403',
    'iban'           => 'PK94HABB0050037000682403',
    'branch'         => 'IBB KASHMIR ROAD SIA',
    'qr_image'       => 'assets/images/qr.webp',
    'is_active'      => 1,
  ]];
}

$allowCod = verdeur_setting('allow_cod', '0') === '1';

$activeBankIndex = -1;
foreach ($bankAccounts as $index => $bank) {
  if (!empty($bank['is_active']) && $activeBankIndex === -1) {
    $activeBankIndex = $index;
  }
}

$pageTitle = 'Checkout — Verdeur';
include('includes/header.php');
?>


<main class="vcheckout-page">

  <section class="vcheckout-section">

    <div class="vcheckout-inner">


      <!-- =====================================
           PAGE HEADER
      ====================================== -->

      <header class="vcheckout-header">

        <p class="vcheckout-kicker">
          Verdeur
        </p>

        <h1 class="vcheckout-title">
          CHECKOUT
        </h1>

        <p class="vcheckout-intro">
          Complete your delivery details and review your order
          before proceeding with payment.
        </p>

      </header>



      <!-- =====================================
           CHECKOUT LAYOUT
      ====================================== -->

      <div
        class="vcheckout-layout"
        id="vcheckout-layout"
      >


        <!-- =================================
             LEFT
        ================================== -->

        <form
          class="vcheckout-form"
          id="vcheckout-form"
        >

          <!-- Honeypot field: humans leave it empty; bots tend to fill it -->
          <input
            type="text"
            name="company_website"
            value=""
            tabindex="-1"
            autocomplete="off"
            aria-hidden="true"
            style="position:absolute; left:-9999px; top:-9999px; height:0; width:0; opacity:0;"
          >

          <!-- Form-start timestamp for human speed-check (populated by JS) -->
          <input
            type="hidden"
            name="form_started"
            id="vcheckout-form-started"
            value=""
          >


          <!-- SHIPPING DETAILS -->

          <div class="vcheckout-block vcheckout-shipping">

            <div class="vcheckout-block-heading">

              <p>01</p>

              <h2>
                Shipping Details
              </h2>

            </div>


            <div class="vcheckout-form-row">

              <div class="vcheckout-field">

                <label for="checkout-name">
                  Full Name
                </label>

                <input
                  type="text"
                  id="checkout-name"
                  name="name"
                  autocomplete="name"
                  required
                >

              </div>


              <div class="vcheckout-field">

                <label for="checkout-phone">
                  Phone Number
                </label>

                <input
                  type="tel"
                  id="checkout-phone"
                  name="phone"
                  autocomplete="tel"
                  required
                >

              </div>

            </div>


            <div class="vcheckout-field">

              <label for="checkout-email">
                Email
                <span>Optional</span>
              </label>

              <input
                type="email"
                id="checkout-email"
                name="email"
                autocomplete="email"
              >

            </div>


            <div class="vcheckout-field">

              <label for="checkout-address">
                Delivery Address
              </label>

              <input
                type="text"
                id="checkout-address"
                name="address"
                autocomplete="street-address"
                required
              >

            </div>


            <div class="vcheckout-form-row">

              <div class="vcheckout-field">

                <label for="checkout-city">
                  City
                </label>

                <input
                  type="text"
                  id="checkout-city"
                  name="city"
                  autocomplete="address-level2"
                  required
                >

              </div>


              <div class="vcheckout-field">

                <label for="checkout-province">
                  Province
                </label>

                <select
                  id="checkout-province"
                  name="province"
                  required
                >
                  <option value="">Select Province</option>
                  <option value="Punjab">Punjab</option>
                  <option value="Sindh">Sindh</option>
                  <option value="KPK">Khyber Pakhtunkhwa</option>
                  <option value="Balochistan">Balochistan</option>
                  <option value="Islamabad">Islamabad Capital Territory</option>
                  <option value="AJ&K">Azad Jammu & Kashmir</option>
                  <option value="Gilgit-Baltistan">Gilgit-Baltistan</option>
                </select>

              </div>

            </div>


            <div class="vcheckout-field">

              <label for="checkout-notes">
                Delivery Notes
                <span>Optional</span>
              </label>

              <textarea
                id="checkout-notes"
                name="notes"
                placeholder="Special instructions for delivery"
              ></textarea>

            </div>

          </div>



          <!-- =================================
               02 — PAYMENT
          ================================== -->

          <div class="vcheckout-block vcheckout-payment">

            <div class="vcheckout-block-heading">

              <p>02</p>

              <h2>
                Payment
              </h2>

            </div>


            <!-- =================================
                 PAYMENT METHODS
            ================================== -->

            <?php
              $isBankTransferSelected = !$allowCod;
            ?>

            <!-- =================================
                 COD — SELECTABLE / UNAVAILABLE
                 Always shown at the top; selected
                 by default when available.
            ================================== -->
            <?php if ($allowCod): ?>
              <div
                class="vcheckout-cod-selectable active"
                id="vcheckout-cod-selectable"
                data-payment-option="cod"
                role="radio"
                aria-checked="true"
                tabindex="0"
                style="margin-top: 0; margin-bottom: 13px;"
              >
                <div class="vcheckout-cod-radio" aria-hidden="true"></div>
                <div class="vcheckout-cod-content">
                  <div class="vcheckout-cod-title">
                    <strong>Cash on Delivery</strong>
                    <span>Available</span>
                  </div>
                  <p>
                    Pay in cash when your order arrives at your doorstep.
                  </p>
                </div>
              </div>
            <?php else: ?>
              <div
                class="vcheckout-cod-disabled"
                aria-disabled="true"
                style="margin-top: 0; margin-bottom: 13px;"
              >
                <div class="vcheckout-disabled-radio"></div>
                <div class="vcheckout-cod-content">
                  <div class="vcheckout-cod-title">
                    <strong>Cash on Delivery</strong>
                    <span>Unavailable</span>
                  </div>
                  <p>
                    Cash on Delivery is currently unavailable.
                    Orders are confirmed after advance payment.
                  </p>
                </div>
              </div>
            <?php endif; ?>

            <!-- =================================
                 BANK TRANSFER — SELECTABLE
                 Single block; inside it are bank
                 tabs and the active bank's details.
            ================================== -->
            <div
              class="vcheckout-cod-selectable <?php echo $isBankTransferSelected ? 'active' : ''; ?>"
              id="vcheckout-bank-transfer"
              data-payment-option="bank-transfer"
              role="radio"
              aria-checked="<?php echo $isBankTransferSelected ? 'true' : 'false'; ?>"
              tabindex="0"
            >
              <div class="vcheckout-cod-radio" aria-hidden="true"></div>
              <div class="vcheckout-cod-content">
                <div class="vcheckout-cod-title">
                  <strong>Bank Transfer</strong>
                </div>
                <p>
                  Pay directly through your bank using the account details below.
                </p>
              </div>
            </div>

            <!-- BANK TRANSFER — TABS + PANELS -->
            <div class="vcheckout-payment-tabs" id="vcheckout-payment-tabs" <?php echo $isBankTransferSelected ? '' : 'hidden'; ?>>

              <div class="vcheckout-tab-list" role="tablist">
                <?php foreach ($bankAccounts as $index => $bank): ?>
                  <?php
                    $isBankActive = !empty($bank['is_active']);
                    $isTabSelected = $isBankTransferSelected && $isBankActive && $index === $activeBankIndex;
                  ?>
                  <button
                    type="button"
                    class="vcheckout-tab <?php echo $isTabSelected ? 'active' : ''; ?> <?php echo $isBankActive ? '' : 'inactive'; ?>"
                    role="tab"
                    id="vcheckout-tab-<?php echo $bank['account_id']; ?>"
                    aria-selected="<?php echo $isTabSelected ? 'true' : 'false'; ?>"
                    aria-controls="vcheckout-panel-<?php echo $bank['account_id']; ?>"
                    data-bank-active="<?php echo $isBankActive ? '1' : '0'; ?>"
                    data-bank-name="<?php echo v_esc($bank['bank_name'] ?: 'Bank ' . ($index + 1)); ?>"
                    <?php echo $isBankActive ? '' : 'aria-disabled="true"'; ?>
                  >
                    <?php echo v_esc($bank['bank_name'] ?: 'Bank ' . ($index + 1)); ?>
                  </button>
                <?php endforeach; ?>
              </div>

              <?php foreach ($bankAccounts as $index => $bank): ?>
                <?php
                  $isBankActive = !empty($bank['is_active']);
                  $isTabSelected = $isBankTransferSelected && $isBankActive && $index === $activeBankIndex;
                ?>
                <div
                  class="vcheckout-payment-panel <?php echo $isTabSelected ? 'active' : ''; ?>"
                  role="tabpanel"
                  id="vcheckout-panel-<?php echo $bank['account_id']; ?>"
                  data-payment-panel="bank-<?php echo $bank['account_id']; ?>"
                  aria-labelledby="vcheckout-tab-<?php echo $bank['account_id']; ?>"
                  <?php echo $isTabSelected ? '' : 'hidden'; ?>
                >

                  <div class="vcheckout-payment-panel-intro">
                    <div>
                      <h3>
                        Bank Transfer — <?php echo v_esc($bank['bank_name']); ?>
                      </h3>
                      <p>
                        Transfer the order total using the account details
                        below. Your order will remain pending until payment
                        has been verified.
                      </p>
                    </div>
                  </div>

                  <div class="vcheckout-bank-content">

                    <!-- BANK DETAILS -->
                    <div class="vcheckout-bank-details">

                      <div class="vcheckout-bank-row">
                        <span>Bank</span>
                        <strong><?php echo v_esc($bank['bank_name']); ?></strong>
                      </div>

                      <div class="vcheckout-bank-row">
                        <span>Account Title</span>
                        <strong><?php echo v_esc($bank['account_title']); ?></strong>
                      </div>

                      <div class="vcheckout-bank-row">
                        <span>Account Number</span>
                        <strong><?php echo v_esc($bank['account_number']); ?></strong>
                      </div>

                      <?php if (!empty($bank['iban'])): ?>
                        <div class="vcheckout-bank-row">
                          <span>IBAN</span>
                          <strong><?php echo v_esc($bank['iban']); ?></strong>
                        </div>
                      <?php endif; ?>

                      <?php if (!empty($bank['branch'])): ?>
                        <div class="vcheckout-bank-row">
                          <span>Branch</span>
                          <strong><?php echo v_esc($bank['branch']); ?></strong>
                        </div>
                      <?php endif; ?>

                    </div>

                    <!-- QR -->
                    <?php if (!empty($bank['qr_image'])): ?>
                      <div class="vcheckout-qr">
                        <div class="vcheckout-qr-image">
                          <img
                            src="<?php echo v_esc($bank['qr_image']); ?>"
                            alt="Bank transfer QR code"
                            loading="lazy"
                            decoding="async"
                          >
                        </div>
                        <p>Scan to pay</p>
                      </div>
                    <?php endif; ?>

                  </div>

                  <p class="vcheckout-payment-proof-note">
                    After completing the transfer, you'll be able to send
                    your payment proof through WhatsApp using your order number.
                  </p>

                </div>
              <?php endforeach; ?>

            </div>

          </div>

        </form>


        <!-- =================================
             RIGHT — ORDER SUMMARY
        ================================== -->

        <aside class="vcheckout-summary">

          <h2 class="vcheckout-summary-title">
            Order Summary
          </h2>


          <!-- ITEMS LIST -->

          <div
            class="vcheckout-items"
            id="vcheckout-items"
          ></div>


          <div class="vcheckout-summary-row">

            <span>
              Subtotal
            </span>

            <span id="vcheckout-subtotal">
              Rs. 0
            </span>

          </div>


          <div class="vcheckout-summary-row">

            <span>
              Shipping
            </span>

            <span id="vcheckout-shipping">
              Rs. 0
            </span>

          </div>


          <div class="vcheckout-total">

            <span>
              Total
            </span>

            <strong id="vcheckout-total">
              Rs. 0
            </strong>

          </div>


          <button
            type="submit"
            form="vcheckout-form"
            class="vcheckout-place-order vcheckout-submit-btn"
            id="vcheckout-submit"
          >
            Place Order
          </button>

          <p class="vcheckout-submit-note">
            By placing your order, you confirm that the delivery
            information provided is correct.
          </p>

          <a
            href="cart.php"
            class="vcheckout-back"
          >
            Return to cart
          </a>

        </aside>


        <!-- =================================
             MOBILE FINAL ACTION
        ================================== -->

        <div class="vcheckout-mobile-action">

          <button
            type="submit"
            form="vcheckout-form"
            class="vcheckout-place-order"
            id="vcheckout-submit-mobile"
          >
            Place Order
          </button>

          <p class="vcheckout-submit-note">
            By placing your order, you confirm that the delivery
            information provided is correct.
          </p>

          <a
            href="cart.php"
            class="vcheckout-back"
          >
            Return to cart
          </a>

        </div>


      </div>


    </div>

  </section>

</main>


<!-- =========================================
     ORDER SUCCESS POPUP
========================================== -->

<div
  class="vcheckout-success"
  id="vcheckout-success"
  role="dialog"
  aria-modal="true"
  aria-labelledby="vcheckout-success-title"
  hidden
>

  <div class="vcheckout-success-backdrop"></div>

  <div class="vcheckout-success-card">

    <span class="vcheckout-success-icon" aria-hidden="true">✓</span>

    <p class="vcheckout-success-kicker">
      Order Confirmed
    </p>

    <h2 class="vcheckout-success-title" id="vcheckout-success-title">
      Thank you for choosing Verdeur
    </h2>

    <p class="vcheckout-success-number" id="vcheckout-success-number">
      Order #VRD-000000-0000
    </p>

    <p class="vcheckout-success-copy" id="vcheckout-success-copy">
      We have received your order details. Please send your payment proof via WhatsApp to expedite processing.
    </p>

    <div class="vcheckout-success-actions">

      <a
        href="#"
        class="vcheckout-whatsapp-btn"
        id="vcheckout-whatsapp-btn"
        target="_blank"
        rel="noopener noreferrer"
      >
        Send Payment Proof on WhatsApp
      </a>

      <a
        href="index.php"
        class="vcheckout-home-link"
      >
        Return to Homepage
      </a>

    </div>

  </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const startedField = document.getElementById('vcheckout-form-started');
  if (startedField) {
    startedField.value = String(Math.floor(Date.now() / 1000));
  }

  const bankTransfer  = document.getElementById('vcheckout-bank-transfer');
  const tabsContainer = document.getElementById('vcheckout-payment-tabs');
  const codSelectable = document.getElementById('vcheckout-cod-selectable');
  const tabs          = document.querySelectorAll('.vcheckout-tab');
  const panels        = document.querySelectorAll('.vcheckout-payment-panel');

  /* --- Bank Transfer block --- */
  const selectBankTransfer = () => {
    if (bankTransfer) {
      bankTransfer.classList.add('active');
      bankTransfer.setAttribute('aria-checked', 'true');
    }
    if (tabsContainer) tabsContainer.hidden = false;

    if (codSelectable) {
      codSelectable.classList.remove('active');
      codSelectable.setAttribute('aria-checked', 'false');
    }

    let activeTab = document.querySelector('.vcheckout-tab.active:not(.inactive)');
    if (!activeTab) activeTab = document.querySelector('.vcheckout-tab:not(.inactive)');
    if (activeTab) activeTab.click();
  };

  if (bankTransfer) {
    bankTransfer.addEventListener('click', selectBankTransfer);
    bankTransfer.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        selectBankTransfer();
      }
    });
  }

  /* --- Tab switching --- */
  tabs.forEach(tab => {
    if (tab.getAttribute('data-bank-active') !== '1') return;

    tab.addEventListener('click', () => {
      tabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      panels.forEach(p => { p.hidden = true; p.classList.remove('active'); });

      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');

      const panelId = tab.getAttribute('aria-controls');
      const panel   = document.getElementById(panelId);
      if (panel) {
        panel.hidden = false;
        panel.classList.add('active');
      }
    });

    tab.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        tab.click();
      }
    });
  });

  /* --- COD block --- */
  const selectCod = () => {
    if (codSelectable) {
      codSelectable.classList.add('active');
      codSelectable.setAttribute('aria-checked', 'true');
    }
    if (bankTransfer) {
      bankTransfer.classList.remove('active');
      bankTransfer.setAttribute('aria-checked', 'false');
    }
    if (tabsContainer) tabsContainer.hidden = true;
  };

  if (codSelectable) {
    codSelectable.addEventListener('click', selectCod);
    codSelectable.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        selectCod();
      }
    });
  }
});
</script>

<?php include('includes/footer.php'); ?>
