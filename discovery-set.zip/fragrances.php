﻿<?php

require_once __DIR__ . '/config.php';

$collections = [];
$products = [];
$testerSets = [];
$collectionSlugMap = [];

try {

  $pdo = verdeur_db();

  $collections = $pdo->query(
    'SELECT slug, name FROM collections WHERE is_active = 1 ORDER BY sort_order'
  )->fetchAll();

  foreach ($collections as $col) {
    $collectionSlugMap[mb_strtolower($col['name'], 'UTF-8')] = [
      'slug' => $col['slug'],
      'name' => $col['name']
    ];
  }

  $stmt = $pdo->query(
    'SELECT p.slug, p.name, p.expression, p.image, p.price, c.slug AS collection_slug, c.name AS collection_name
     FROM products p
     INNER JOIN collections c ON c.collection_id = p.collection_id
     WHERE p.is_active = 1 AND c.is_active = 1
     ORDER BY c.sort_order, p.sort_order'
  );

  $products = $stmt->fetchAll();

  $testerSets = $pdo->query(
    'SELECT t.slug, t.name, t.card_subtitle AS expression, t.image, t.price,
            COALESCE(c.slug, "initiale") AS collection_slug,
            COALESCE(c.name, "Initialé") AS collection_name
     FROM tester_sets t
     LEFT JOIN collections c ON c.collection_id = t.collection_id
     WHERE t.is_active = 1
     ORDER BY t.sort_order'
  )->fetchAll();

} catch (Throwable $e) {
  $collections = [];
  $products = [];
  $testerSets = [];
  $collectionSlugMap = [];
}

$pageTitle = 'Fragrances — Verdeur';
$pageDescription = 'Browse the full Verdeur fragrance collection across Initialé, Éclat, Auréole and Vespère — plus discovery sets, from an independent fragrance house.';

include('includes/header.php');
?>




  <main>


 <!-- =========================================
     FRAGRANCES — CATALOGUE
========================================== -->

<section class="fr-catalogue">

  <div class="fr-catalogue-inner">


    <!-- PAGE INTRO -->
    <header class="fr-page-header">

      <p class="fr-page-kicker">
        Verdeur
      </p>

      <h1 class="fr-page-title">
        FRAGRANCES
      </h1>

      <p class="fr-page-intro">
        Explore every expression from Verdeur.
      </p>

    </header>


    <!-- =====================================
         COLLECTION FILTERS
    ====================================== -->

    <div class="fr-filter-bar">

      <div
        class="fr-filters"
        role="group"
        aria-label="Filter fragrances by collection"
      >

        <button
          type="button"
          class="fr-filter active"
          data-filter="all"
        >
          All
        </button>

<?php foreach ($collections as $collection): ?>

        <button
  type="button"
  class="fr-filter"
  data-filter="<?php echo v_esc($collection['slug']); ?>"
>
  <?php echo v_esc($collection['name']); ?>
</button>

<?php endforeach; ?>

      </div>


      <p class="fr-product-count">
        <span id="fr-count"><?php echo count($products) + count($testerSets); ?></span> fragrances
      </p>

    </div>


    <!-- =====================================
         PRODUCT GRID
    ====================================== -->

    <div class="fr-grid">

<?php foreach ($products as $product): ?>

      <article
        class="fr-product"
        data-collection="<?php echo v_esc($product['collection_slug']); ?>"
      >

        <div class="fr-product-visual">

          <div class="fr-bottle-wrap">

            <a
              href="fragrance/<?php echo v_esc($product['slug']); ?>"
              class="fr-image-link"
            >
              <img
                src="<?php echo v_esc($product['image']); ?>"
                alt="<?php echo v_esc($product['name'] . ' by Verdeur'); ?>"
                loading="lazy"
                decoding="async"
              >
            </a>


            <button
              type="button"
              class="fr-cart-button"
              data-product="<?php echo v_esc($product['slug']); ?>"
              aria-label="Add <?php echo v_esc($product['name']); ?> to cart"
            >

              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 8h14l-1 12H6L5 8Z"></path>
                <path d="M9 8V6a3 3 0 0 1 6 0v2"></path>
                <path d="M12 11v5"></path>
                <path d="M9.5 13.5h5"></path>
              </svg>

            </button>

          </div>

        </div>


        <a
          href="fragrance/<?php echo v_esc($product['slug']); ?>"
          class="fr-product-info"
        >

          <p class="fr-collection-name">
            <?php echo v_esc($product['collection_name']); ?>
          </p>

          <h2 class="fr-product-name">
            <?php echo v_esc($product['name']); ?>
          </h2>

          <p class="fr-expression">
            <?php echo v_esc($product['expression']); ?>
          </p>

          <p class="fr-price">
            <?php echo v_price($product['price']); ?>
          </p>

        </a>

      </article>

<?php endforeach; ?>

<?php foreach ($testerSets as $set): ?>

      <article
        class="fr-product"
        data-collection="<?php echo v_esc($set['collection_slug'] ?: 'initiale'); ?>"
      >

        <div class="fr-product-visual">

          <div class="fr-bottle-wrap">

            <a
              href="discovery-set/<?php echo v_esc($set['slug']); ?>"
              class="fr-image-link"
            >
              <img
                src="<?php echo v_esc($set['image']); ?>"
                alt="<?php echo v_esc($set['name'] . ' by Verdeur'); ?>"
              >
            </a>


            <button
              type="button"
              class="fr-cart-button"
              data-product="<?php echo v_esc($set['slug']); ?>"
              aria-label="Add <?php echo v_esc($set['name']); ?> to cart"
            >

              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 8h14l-1 12H6L5 8Z"></path>
                <path d="M9 8V6a3 3 0 0 1 6 0v2"></path>
                <path d="M12 11v5"></path>
                <path d="M9.5 13.5h5"></path>
              </svg>

            </button>

          </div>

        </div>


        <a
          href="discovery-set/<?php echo v_esc($set['slug']); ?>"
          class="fr-product-info"
        >

          <p class="fr-collection-name">
            <?php echo v_esc($set['collection_name'] ?: 'Initialé'); ?>
          </p>

          <h2 class="fr-product-name">
            <?php echo v_esc($set['name']); ?>
          </h2>

          <p class="fr-expression">
            <?php echo v_esc($set['expression']); ?>
          </p>

          <p class="fr-price">
            <?php echo v_price($set['price']); ?>
          </p>

        </a>

      </article>

<?php endforeach; ?>

    </div>

  </div>

</section>

  </main>

  <!-- =========================================
     10 — FOOTER
========================================== -->

<?php include('includes/footer.php'); ?>
